"""Check the 3C time mixture and plot pre-run rationale; no optimizer."""
import importlib.util
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch
from deepreach import Siren, sample, residual, target, load_checkpoint
from diagnostics import ROOT, RUNS, dump, sha, write_csv
from validate import mechanical_checks


def run():
    c=json.loads((ROOT/'configs/experiment3c_time_sampling.json').read_text())
    base_c=json.loads((ROOT/'configs/experiment3a_constraints.json').read_text())
    folder=ROOT/'experiments/experiment_3_c';folder.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(2)
    torch.manual_seed(7);base=Siren(base_c)
    torch.manual_seed(7);model=Siren(c)
    assert all(torch.equal(x,y) for x,y in zip(base.state_dict().values(),model.state_dict().values()))
    nf=(c['samples']-c['terminal_samples'])//2
    for tmax in [.00005,.1,.25,.5]:
        torch.manual_seed(901);q0=sample(base_c,2048,tmax,256,'cpu');rng0=torch.get_rng_state()
        torch.manual_seed(901);q=sample(c,2048,tmax,256,'cpu')
        assert torch.equal(torch.get_rng_state(),rng0)
        assert torch.equal(q[:,1:],q0[:,1:]) and torch.equal(q[nf:],q0[nf:])
        torch.testing.assert_close(q[:nf,0]*(tmax/c['horizon']),q0[:nf,0],atol=1e-7,rtol=1e-6)
        assert torch.all(q[-256:,0]==0) and q[:,0].max()<=c['horizon']
        if tmax==.5:assert torch.equal(q,q0)
    torch.manual_seed(12);pre=sample(c,2048,0,2048,'cpu')
    assert torch.all(pre[:,0]==0)
    r,v,_=residual(model,q,c,True)
    grads=torch.autograd.grad(r.abs().mean(),tuple(model.parameters()))
    assert all(torch.isfinite(g).all() and g.norm()>0 for g in grads)
    assert torch.all(v<=target(q[:,1:],c))
    mechanical=mechanical_checks(model,c)
    legacy={};protected={}
    runs=[(slug,d) for _,slug,d in RUNS]+[('3a','experiment_3_a_constraints'),('3b','experiment_3_b_periodic')]
    probe=q[:128]
    for slug,d in runs:
        path=ROOT/'runs'/d/'checkpoint.pt';protected[str(path.relative_to(ROOT))]=sha(path)
        current,ck=load_checkpoint(path)
        archive=ROOT/'runs'/('air3d_cpu_20261022' if slug in ['baseline','a','b','c'] else d)/'source/deepreach.py'
        spec=importlib.util.spec_from_file_location('before_time_'+slug,archive)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        original=module.Siren(ck['config']);original.load_state_dict(ck['model'])
        with torch.no_grad():assert torch.equal(current(probe),original(probe))
        legacy[slug]=True
    # Only random time scaling changes; replay all sampler calls against 3A RNG.
    _,ck=load_checkpoint(ROOT/'runs/experiment_3_a_constraints/checkpoint.pt')
    # Loading consumes initialization RNG; reseed immediately before replay.
    torch.manual_seed(7);Siren(c)
    for j in range(1,10001):sample(c,2048,c['horizon']*j/10000,256,'cpu')
    assert torch.equal(torch.get_rng_state(),ck['torch_rng'].cpu())
    maxima=.5*np.arange(1,10001)/10000
    bins=np.linspace(0,.5,21);rows=[]
    for lo,hi in zip(bins[:-1],bins[1:]):
        original=float(np.mean(np.maximum(0,np.minimum(hi,maxima)-lo)/maxima))
        mixture=.5*original+.5*(hi-lo)/.5
        rows.append(dict(lower=float(lo),upper=float(hi),original_fraction=original,mixed_fraction=mixture))
    write_csv(folder/'expected_time_distribution.csv',rows)
    old=json.loads((ROOT/'experiments/experiment_3_a/comparison.json').read_text())
    old=[r for r in old if r['slug']=='constraints']
    eq=json.loads((ROOT/'experiments/experiment_3_a/equation_checks.json').read_text())
    fig,axes=plt.subplots(1,3,figsize=(14,4),layout='constrained')
    axes[0].plot([r['tau'] for r in old],[r['mae'] for r in old],'o-');axes[0].set(title='3A value error',ylabel='MAE [m]',xlabel='Look-ahead τ [s]')
    axes[1].plot([r['tau'] for r in eq],[r['vi_mae'] for r in eq],'o-');axes[1].set(title='3A equation residual',ylabel='VI MAE [training convention]',xlabel='Look-ahead τ [s]')
    centers=(bins[:-1]+bins[1:])/2
    axes[2].bar(centers-.004,[100*r['original_fraction'] for r in rows],width=.008,label='3A curriculum')
    axes[2].bar(centers+.004,[100*r['mixed_fraction'] for r in rows],width=.008,label='3C mixture')
    axes[2].set(title='Expected nonterminal draws over all updates',ylabel='Draws in time bin [%]',xlabel='Look-ahead bin [s]');axes[2].legend(fontsize=8)
    for ax in axes:ax.grid(alpha=.25)
    fig.savefig(folder/'pre_run_rationale.png',dpi=170);plt.close(fig)
    result=dict(optimizer_steps=0,initial_weights_identical_to_3a=True,
        spatial_heading_terminal_samples_identical=True,remaining_curriculum_times_identical=True,
        same_uniform_draws_and_rng_consumption=True,sampler_replay_matches_3a=True,
        full_horizon_nonterminal_per_batch=nf,curriculum_nonterminal_per_batch=nf,terminal_per_batch=256,
        mechanical=mechanical,finite_nonzero_physics_gradients=True,legacy_predictions_bitwise_identical=legacy,
        protected_inputs=protected,parameters=sum(p.numel() for p in model.parameters()),
        sources={n:sha(ROOT/n) for n in ['deepreach.py','validate.py','check_time_sampling.py']},
        config_sha256=sha(ROOT/'configs/experiment3c_time_sampling.json'),
        expected_late_fraction_original=sum(r['original_fraction'] for r in rows if r['lower']>=.4),
        expected_late_fraction_mixture=sum(r['mixed_fraction'] for r in rows if r['lower']>=.4))
    for rel,h in protected.items():assert sha(ROOT/rel)==h
    dump(folder/'implementation_checks.json',result);print(json.dumps(result,indent=2))


if __name__=='__main__':run()

"""Physics/reduction checks only. Does not initialize or train a network."""
import json
import numpy as np
import torch
from joint6d import relative_state,lift_relative,dynamics,target,hamiltonian,optimal_inputs,lift_covector
from deepreach import dynamics as relative_dynamics, target as relative_target, hamiltonian as relative_hamiltonian
from deepreach import optimal_control,optimal_disturbance
from diagnostics import ROOT,dump,sha


def run():
    out=ROOT/'experiments/experiment_4_joint6d';out.mkdir(parents=True,exist_ok=True)
    protected={str(p.relative_to(ROOT)):sha(p) for p in ROOT.glob('**/checkpoint*.pt')}
    final=ROOT/'evaluation/reserved_final_states/states.npz';protected[str(final.relative_to(ROOT))]=sha(final)
    torch.set_num_threads(2);torch.manual_seed(991744)
    c=dict(speed=.75,turn=3.,radius=.25,horizon=.5)
    z=torch.rand(257,6,dtype=torch.float64)*2-1
    z[:,[2,5]]*=torch.pi;z.requires_grad_(True)
    u=torch.linspace(-3,3,len(z),dtype=torch.float64);d=u.flip(0)
    r=relative_state(z);flow=dynamics(z,u,d,c)
    chain=torch.stack([(torch.autograd.grad(r[:,i].sum(),z,retain_graph=True)[0]*flow).sum(-1) for i in range(3)],dim=-1)
    motion_error=float((chain-relative_dynamics(r,u,d,c)).abs().max())
    boundary_error=float((target(z,c)-relative_target(r,c)).abs().max())
    # Analytic invariant test function, unrelated to any saved neural model.
    value=.3*r[:,0]**2+.2*r[:,1]**2+r[:,2].sin()+.1*r[:,0]*r[:,2].cos()
    gp=torch.autograd.grad(value.sum(),r,retain_graph=True)[0]
    automatic=torch.autograd.grad(value.sum(),z)[0];lifted=lift_covector(z,gp.detach())
    covector_error=float((automatic-lifted).abs().max())
    h_reduction_error=float((hamiltonian(z,lifted,c)-relative_hamiltonian(r,gp,c)).abs().max())
    ug,dg=optimal_inputs(lifted,c)
    control_error=float((ug-optimal_control(r,gp,c)).abs().max())
    disturbance_error=float((dg-optimal_disturbance(gp,c)).abs().max())
    # Independent max_u min_d over a 9x9 input grid for arbitrary 6D covectors.
    p=torch.randn(z.shape,dtype=torch.float64);turns=torch.linspace(-3,3,9,dtype=torch.float64)
    brute=(dynamics(z[:,None,None,:],turns[None,:,None],turns[None,None,:],c)*p[:,None,None,:]).sum(-1).min(-1).values.max(-1).values
    brute_error=float((brute-hamiltonian(z,p,c)).abs().max())
    selected_u,selected_d=optimal_inputs(p,c)
    selected_error=float(((dynamics(z,selected_u,selected_d,c)*p).sum(-1)-hamiltonian(z,p,c)).abs().max())
    # Translation/rotation symmetry of reduction and target.
    translated=z.detach().clone();translated[:,0:2]+=torch.tensor([.31,-.22]);translated[:,3:5]+=torch.tensor([.31,-.22])
    translation_error=float((relative_state(translated)-r.detach()).abs().max())
    alpha=.63;rotated=z.detach().clone()
    rot=torch.tensor([[np.cos(alpha),-np.sin(alpha)],[np.sin(alpha),np.cos(alpha)]],dtype=torch.float64)
    rotated[:,0:2]=rotated[:,0:2]@rot.T;rotated[:,3:5]=rotated[:,3:5]@rot.T;rotated[:,[2,5]]+=alpha
    rotation_error=float((relative_state(rotated)-r.detach()).abs().max())
    wraps=z.detach().clone();wraps[:,2]+=2*torch.pi;wraps[:,5]-=2*torch.pi
    wrap_error=float((relative_state(wraps,True)-relative_state(z.detach(),True)).abs().max())
    # New synthetic evaluation lift; no existing final/development states read.
    rs=torch.rand(257,3,dtype=torch.float64)*torch.tensor([1.2,1.2,2*torch.pi])-torch.tensor([.6,.6,torch.pi])
    midpoint=torch.rand(257,2,dtype=torch.float64)-.5;heading=(torch.rand(257,dtype=torch.float64)*2-1)*torch.pi
    joint=lift_relative(rs,midpoint,heading)
    lift_error=float((relative_state(joint,True)-rs).abs().max())
    pose_bound=.5+np.sqrt(2)*.6/2
    assert max(motion_error,boundary_error,covector_error,h_reduction_error,control_error,disturbance_error,
        brute_error,selected_error,translation_error,rotation_error,wrap_error,lift_error)<1e-12
    assert float(joint[:,[0,1,3,4]].abs().max())<=pose_bound and pose_bound+c['speed']*c['horizon']<2
    assert all(sha(ROOT/f)==h for f,h in protected.items())
    result=dict(status='passed',training=False,network_initialized=False,optimizer_created=False,parameter_updates=0,
        samples=257,seed=991744,joint_state_order=['xp','yp','heading_p','xe','ye','heading_e'],
        physical_config=c,relative_motion_chain_max_abs=motion_error,target_equivalence_max_abs=boundary_error,
        covector_chain_max_abs=covector_error,hamiltonian_reduction_max_abs=h_reduction_error,
        control_equivalence_max_abs=control_error,disturbance_equivalence_max_abs=disturbance_error,
        arbitrary_covector_brute_maxmin_max_abs=brute_error,selected_hamiltonian_max_abs=selected_error,
        translation_max_abs=translation_error,rotation_max_abs=rotation_error,heading_wrap_max_abs=wrap_error,
        lift_roundtrip_max_abs=lift_error,evaluation_pose_coordinate_bound=pose_bound,
        evaluation_pose_plus_motion_bound=pose_bound+c['speed']*c['horizon'],
        final_states_used=False,all_existing_checkpoints_and_final_states_unchanged=True,protected_inputs=protected,
        sources={n:sha(ROOT/n) for n in ['joint6d.py','check_joint6d.py','deepreach.py']},threads=2)
    dump(out/'physics_checks.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['protected_inputs','sources']},indent=2))


if __name__=='__main__':run()

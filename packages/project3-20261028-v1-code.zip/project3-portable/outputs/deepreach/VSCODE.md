# Training in VS Code

## Fixed final evaluation — completed without training

The [final evaluation record](evaluation/final_evaluation_20261028/README.md) compares only original 3A, Adam +200 and Long22000 on the 24,000 reserved states. It ran through a managed process using the project interpreter and two CPU threads, separately from VS Code training. No models were changed or tuned. The reservation is now marked consumed. Long22000's final MAE is 12.61% lower than Adam +200's. The completed output is protected from overwrite; inspect the report and saved arrays rather than launching another run. The prepare/evaluate commands and interrupted-run recovery policy are documented in the report.

## Experiment 3E — duration versus capacity completed in VS Code

**Air3D: Experiment 3E - Capacity versus duration** ran the [fixed comparison](experiments/experiment_3_e_capacity_budget/README.md) through Run and Debug, using the main repo interpreter/output from the Homework window. Long64 extended original 3A to 22,000 total steps; Wide96 trained a matched-sampling curriculum for 10,000 steps. Both completed. [Results](experiments/experiment_3_e_capacity_budget/RESULTS.md) favor Long64 for overall value accuracy. Its continuation took 197.40 s; the wider run took 604.37 s. Evaluation ran separately. Results/models are copied into Homework after completion.

The separate **Resume capacity comparison** option requires an interrupted, incomplete experiment. Completed runs are protected from overwrite. Original checkpoints and reserved final inputs remain unchanged. The launch paths are specific to this laptop; command-line reproduction is documented in the method report.

## Optimizer-history diagnostic — no training

`python outputs/deepreach/probe_optimizer_history.py` reproduces the [frozen optimizer-history check](experiments/experiment_3_d_refinement/optimizer_history_probe/README.md). It ran through a managed process with two CPU threads, without creating an optimizer, changing a checkpoint or using reserved final states. No optimizer-restart training launch was added because the probes do not improve Adam +200's final-time value accuracy.

## Geometry/horizon weighting probe — no training

`python outputs/deepreach/probe_geometry_horizon.py` reproduces the [frozen weighting probe](experiments/experiment_3_d_refinement/geometry_horizon_probe/README.md). It ran through a managed process with two CPU threads, without a new training run or checkpoint changes. Verification uses disposable optimizer copies only. The weighted candidates did not improve Adam +200, so no weighted training launch was added.

## Experiment 3D follow-up — no training

`python outputs/deepreach/diagnose_refinement.py` reproduces the [location, horizon and boundary/value diagnostics](experiments/experiment_3_d_refinement/followup_diagnostics/README.md) from saved checkpoints. The completed diagnostic ran through a managed process with two CPU threads, separately from the earlier VS Code training run. It leaves all checkpoints and reserved final-evaluation inputs unchanged.

## Experiment 3D — completed in VS Code Run and Debug

**Air3D: Experiment 3D - Short optimizer refinement** launched the fixed [refinement trial](experiments/experiment_3_d_refinement/README.md). It uses absolute paths to this laptop's main repo/interpreter from the Homework window. All four endpoints completed and the Debug Console confirmed completion. Re-launching training refuses to overwrite the experiment folder. Results/checkpoints are copied into Homework afterward; evaluation is a separate managed process. [Results](experiments/experiment_3_d_refinement/RESULTS.md) favor Adam +200 for development value accuracy, while controlled steps give lower physics loss. Reserved final states remain unused.

## Frozen 3A direction/step-size diagnostic

`python outputs/deepreach/probe_step_directions.py` reproduces the [finite-step probes](experiments/experiment_3_a/step_direction_probe/README.md) using the project interpreter. It evaluates temporary independent parameter overrides without training or checkpoint writes. The completed diagnostic ran through a managed process with two CPU threads. It uses existing development references and leaves reserved final-evaluation states unused. Results, CSVs and the figure are saved alongside the report.

## Experiment 3C — completed through a managed process

The prepared **Air3D: Experiment 3C - Train mixed time sampling** launch option is available. During the attempted UI launch, the computer-use API reported concurrent user input and unavailable geometry, so the authorized run instead used a managed process with the same selected interpreter. It completed 10,000 physics steps in 203.98 seconds, CPU/two threads. Do not describe it as a debugger run. Logs, checkpoint, source snapshots and comparisons are saved in the project and Homework copy for inspection in VS Code. See [results](experiments/experiment_3_c/RESULTS.md); this mixture did not outperform 3A. A fresh launch over the completed run is refused.

## Experiment 3B — completed

**Air3D: Experiment 3B - Train periodic heading** completed 10,000 physics steps through VS Code Run and Debug in the Homework workspace on 27 October 2026. Time: 339.46 seconds, two CPU threads. The subsequent managed-process evaluation did not train or recompute the reference. See [the mixed results](experiments/experiment_3_b/RESULTS.md): the old outlier cohort improves, but 3A retains better overall accuracy. A fresh run over the completed checkpoint is refused; use a separate folder for a future test.

## Experiment 3A — completed

Use **Air3D: Constraint candidate checks - no training** to verify the exact terminal/obstacle output, derivatives and compatibility with old checkpoints. This creates no optimizer and makes no weight updates. After user authorization, **Air3D: Experiment 3A - Train constraints (starts training)** completed 10,000 physics steps through VS Code Run and Debug on 27 October 2026, in 220.28 seconds. The 21-point comparison and original validation then ran through a managed process without training. See the [results](experiments/experiment_3_a/RESULTS.md) and [candidate record](experiments/experiment_3_a/README.md). A fresh launch over the completed run is refused; use a new run folder for another experiment.

## Diagnostics without training

Run `python outputs/deepreach/diagnose_learning_signals.py` with the selected environment for the [3A learning-signal diagnosis](experiments/experiment_3_a/learning_signals/README.md). It creates no optimizer, applies no parameter updates and never uses reference gradients for training. Saved Adam moments are inspected only to calculate hypothetical directions. A separate unused final-evaluation input set is reserved. The initial diagnostic executed in a managed process.

Choose **Air3D: Inspect 3A outliers - no training** to regenerate the [outlier diagnostic](experiments/experiment_3_a/outliers/README.md). It checks geometry, equivalent headings, reflection, equation residuals and local reference-grid sensitivity. A matching coarse query cache is reused; an initial run computes one reference solve. It never changes model weights.

Choose **Air3D: Failure analysis - no training** to regenerate the [failure breakdown](failure_analysis_20261027/README.md): equation residuals, exact collision/obstacle checks, temporal monotonicity, heading periodicity and conditional error statistics. It reads the saved 21-point sweep and never updates weights. The interpretation document is maintained separately from the generated measurements.

For the denser difficulty knob, choose **Air3D: 21-point look-ahead diagnostic - no training**. This computes 21 numerical-reference snapshots from 0 to .5 s, then evaluates all four unchanged networks. Results are saved in [lookahead_21points_20261027](lookahead_21points_20261027/README.md). The initial run used a managed process, not the debugger. It leaves the original three-point diagnostics intact.

Choose **Air3D: Diagnostics only - no training** in Run and Debug and press F5. This evaluates the four saved checkpoints and writes the [diagnostic report](diagnostics_20261027/README.md), raw comparisons, Fourier spectra and timings. It never updates network weights. A matching reference-build timing is reused; inference is timed again on each run. The initial 27 October diagnostic run was executed through a managed process with this environment, not the VS Code debugger.

## Experiment 2

Choose **Air3D: Experiment 2 - Run all three variants** in Run and Debug, then press F5. This launches experiment2.py directly through the VS Code Python debugger and displays progress in the Debug Console. The sequence verifies the original baseline, runs A (loss weight), B (focused sampling), and C (additional full-horizon training), then compares all four models using the saved numerical reference. The first two start fresh; C forks the original checkpoint with its optimizer and random state.

Each candidate has its own folder under outputs/deepreach/runs/experiment_2_*. The aggregate report, comparison data and progress status are under outputs/deepreach/experiments/experiment_2. The script can resume an interrupted sequence from its saved checkpoints and reuses already completed candidates. It refuses configurations that disagree with an existing checkpoint. No paper-scale run or GitHub upload is included.

## Experiment 1

On 22 October 2026 the smoke and reduced CPU runs completed. The VS Code window was receiving user input, so the runs were launched through a managed process using the same selected interpreter and their history file was opened in VS Code. They were not launched by the VS Code debugger. The configurations below are available for future runs and resuming; a fresh run over an existing checkpoint is refused.

The project root contains Run and Debug configurations in .vscode/launch.json. The current laptop's Python environment is selected explicitly; there is no need to install PyTorch again. This interpreter path is specific to this computer. On another computer, create an environment using requirements.txt and update the Python path in launch.json and settings.json.

1. Open the project folder in VS Code (the folder containing .vscode and outputs).
2. Open **Run and Debug** with Ctrl+Shift+D.
3. Choose **Air3D: 1 - Smoke training**, then press F5. Output appears in the Debug Console.
4. Once it finishes, choose **Air3D: 2 - CPU training** and press F5.
5. After CPU training finishes, choose **Air3D: 3 - Compare CPU model**. This computes the numerical reference and plots without further training. The optional optimizer restart check was already performed for the saved 22 October run.

The configurations use two CPU threads, the existing reduced budgets, and dated output directories. The full paper-scale experiment is not selected automatically. Starting a fresh run over an existing checkpoint is rejected; use the separate **Resume CPU training** configuration to continue an interrupted run.

Progress is written to outputs/deepreach/runs/air3d_cpu_20261022/history.csv. A checkpoint is saved every 1000 iterations and at completion. A checkpoint includes weights, optimizer, config, random state and curriculum progress. A normal stop between checkpoints can lose the most recent unsaved iterations. Interruptions are resumed from the last saved checkpoint.

Training starts with fitting the zero-time collision-distance function, then expands time while enforcing the HJI variational inequality. Falling losses do not establish accurate reachable sets. The comparison stage checks an independent numerical reference and writes metrics and plots. Hardware details are recorded in checks/hardware_20261022.json.

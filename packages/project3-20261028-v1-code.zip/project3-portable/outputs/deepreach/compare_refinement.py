"""Evaluate fixed 3D refinement endpoints; never trains or uses reserved states."""
import csv
import json
import time
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from deepreach import load_checkpoint
from diagnostics import ROOT, dump, sha, write_csv
from probe_step_directions import physics
from deepreach import sample
from validate import predict, classification, error


def run():
    started=time.perf_counter();torch.set_num_threads(2)
    folder=ROOT/'experiments/experiment_3_d_refinement'
    manifest=json.loads((folder/'training_manifest.json').read_text())
    assert manifest['status']=='completed' and manifest['reference_labels_loaded'] is False
    protected=dict(manifest['protected_inputs'])
    for e in manifest['endpoints']:protected[e['checkpoint']]=e['sha256']
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    with np.load(ROOT/'lookahead_21points_20261027/heldout_values.npz') as f:
        states=f['states'].copy();times=f['times'].copy();refs=f['reference'].copy()
    with (ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv').open() as stream:
        top=np.array([int(r['state_index']) for r in csv.DictReader(stream)])
    base_model,base_ck=load_checkpoint(ROOT/'runs/experiment_3_a_constraints/checkpoint.pt');c=base_ck['config']
    torch.manual_seed(991736);audit=sample(c,8192,.5,1024,'cpu').numpy()
    np.savez_compressed(folder/'evaluation_physics_queries.npz',queries=audit)
    checkpoints=[('3A',ROOT/'runs/experiment_3_a_constraints/checkpoint.pt',dict(steps=0,gradient_batches=0,trial_physics_batches=0,total_physics_batch_assessments=0,elapsed_seconds=0.))]
    for e in manifest['endpoints']:
        checkpoints.append((e['method']+'_'+str(e['steps']),ROOT/e['checkpoint'],e))
    rows=[];final=[];values={};mechanical=[]
    for name,path,cost in checkpoints:
        print('Evaluating '+name,flush=True)
        model,ck=load_checkpoint(path);model.eval();original={k:v.clone() for k,v in model.state_dict().items()}
        parameters={k:p.detach() for k,p in model.named_parameters()}
        audit_loss=physics(model,parameters,audit,c)
        audit_terminal=physics(model,parameters,audit[-1024:],c)
        audit_nonterminal=physics(model,parameters,audit[:-1024],c)
        np.testing.assert_allclose(audit_loss,.125*audit_terminal+.875*audit_nonterminal,rtol=1e-6,atol=1e-8)
        predictions=[]
        terminal_error=None;max_obstacle=-1e30
        for j,t in enumerate(times):
            q=np.column_stack([np.full(len(states),t),states]);pred=predict(model,q)
            assert np.isfinite(pred).all();predictions.append(pred)
            analytic=np.hypot(states[:,0],states[:,1])-c['radius']
            max_obstacle=max(max_obstacle,float(np.max(pred-analytic)))
            if t==0:terminal_error=float(np.max(abs(pred-analytic)))
            err=pred-refs[j]
            row=dict(model=name,time=float(t),**error(pred,refs[j]),**classification(pred,refs[j]),
                bias=float(err.mean()),p95_abs=float(np.quantile(abs(err),.95)),p99_abs=float(np.quantile(abs(err),.99)),
                own_worst_240_mae=float(np.sort(abs(err))[-240:].mean()),
                relative_l2=float(np.linalg.norm(err)/np.linalg.norm(refs[j])),
                fixed_outlier_mae=float(abs(err[top]).mean()),
                below_minus_radius_fraction=float(np.mean(pred < -c['radius']-1e-4)),
                interior_vi_mae=physics(model,parameters,q,c),
                time_increase_from_previous_fraction=0. if j==0 else float(np.mean(pred>predictions[j-1]+1e-4)))
            rows.append(row)
        pp=np.stack(predictions);values[name]=pp
        if name=='3A':
            with np.load(ROOT/'experiments/experiment_3_a/candidate_values.npz') as f:
                np.testing.assert_allclose(pp,f['predictions'],rtol=1e-5,atol=2e-6)
        seam_queries=np.column_stack([np.full(len(states),.5),states])
        seam_queries[:,3]=np.pi;plus=predict(model,seam_queries)
        seam_queries[:,3]=-np.pi;minus=predict(model,seam_queries)
        final.append(dict(rows[-1],audit_physics_loss=audit_loss,
            audit_terminal_physics_loss=audit_terminal,audit_nonterminal_physics_loss=audit_nonterminal,
            heading_seam_mae=float(abs(plus-minus).mean()),mean_nonzero_horizon_mae=float(np.mean([r['mae'] for r in rows[-20:]])),
            gradient_batches=cost['gradient_batches'],trial_physics_batches=cost['trial_physics_batches'],
            total_physics_batch_assessments=cost['total_physics_batch_assessments'],training_seconds=cost['elapsed_seconds']))
        assert terminal_error<2e-7 and max_obstacle<2e-7
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in original.items())
        assert all(p.grad is None for p in model.parameters())
        mechanical.append(dict(model=name,terminal_max_abs=terminal_error,max_obstacle_violation=max(0.,max_obstacle),
            checkpoint_reload=True,evaluation_weights_unchanged=True))
    write_csv(folder/'comparison.csv',rows);write_csv(folder/'final_comparison.csv',final)
    dump(folder/'final_comparison.json',final);dump(folder/'equation_checks.json',mechanical)
    np.savez_compressed(folder/'endpoint_values.npz',times=times,**values)
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    for name,_,_ in checkpoints:
        rr=[r for r in rows if r['model']==name]
        axes[0,0].plot(times,[r['mae'] for r in rr],label=name)
        axes[0,1].plot(times,[100*r['false_unsafe_fraction_of_reference_safe'] for r in rr])
        axes[1,0].plot(times,[r['fixed_outlier_mae'] for r in rr])
        axes[1,1].plot(times,[r['interior_vi_mae'] for r in rr])
    for ax in axes.flat:ax.set_xlabel('Look-ahead horizon [s]');ax.grid(alpha=.2)
    axes[0,0].set(title='Overall value accuracy',ylabel='MAE [m]');axes[0,0].legend(fontsize=7)
    axes[0,1].set(title='Conservative collision classifications',ylabel='False-unsafe / reference-safe [%]')
    axes[1,0].set(title='Fixed original worst-240 states',ylabel='Cohort MAE [m]')
    axes[1,1].set(title='Physics residual on development states',ylabel='Mean absolute VI residual')
    fig.suptitle('Experiment 3D: fixed refinement endpoints from 3A; reused development data')
    fig.savefig(folder/'comparison.png',dpi=170);plt.close(fig)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    base=final[0]
    improvements={r['model']:dict(final_mae_percent=100*(base['mae']-r['mae'])/base['mae'],
        audit_loss_percent=100*(base['audit_physics_loss']-r['audit_physics_loss'])/base['audit_physics_loss'],
        outlier_mae_percent=100*(base['fixed_outlier_mae']-r['fixed_outlier_mae'])/base['fixed_outlier_mae']) for r in final[1:]}
    dump(folder/'evaluation_manifest.json',dict(status='completed',training=False,reserved_final_states_used=False,
        reference_usage='Existing development values, evaluation after all fixed training endpoints completed.',
        protected_inputs=protected,sources={n:sha(ROOT/n) for n in ['compare_refinement.py','deepreach.py','probe_step_directions.py','validate.py']},
        evaluation_physics_seed=991736,heading_seam='Same development x/y coordinates evaluated at -pi/+pi; differs from older seam grids.',
        elapsed_seconds=time.perf_counter()-started,improvements=improvements))
    print(json.dumps(improvements,indent=2),flush=True)


if __name__=='__main__':run()

"""Experiment 2: three controlled variants, with no reference labels in training.

A: terminal-loss multiplier divided by 10, same 12,000-step budget.
B: half of nonterminal physics samples drawn uniformly in a radius-1m disk.
C: continue the exact Experiment 1 optimizer/RNG state for 10,000 full-horizon steps.
"""
import argparse
import csv
import hashlib
import json
import math
import shutil
import time
from pathlib import Path

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from deepreach import load_checkpoint, residual, sample, target, train
from validate import evaluate, predict


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path,data):
    Path(path).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def diagnose(checkpoint):
    model,ck=load_checkpoint(checkpoint)
    c=ck['config']; torch.set_num_threads(c['threads']); torch.manual_seed(20261022)
    q=sample(c,8192,c['horizon'],1024,'cpu')
    r,v,dv=residual(model,q,c,True)
    p=r.abs().mean(); b=(v[-1024:]-target(q[-1024:,1:],c)).abs().mean()
    params=tuple(model.parameters())
    gp=torch.cat([g.reshape(-1) for g in torch.autograd.grad(p,params,retain_graph=True)])
    gb=torch.cat([g.reshape(-1) for g in torch.autograd.grad(b,params)])
    weight=ck['terminal_weight']
    reflected=q.numpy().copy(); reflected[:,2:]*=-1
    symmetry=np.abs(predict(model,q.numpy())-predict(model,reflected))
    radius=torch.linalg.vector_norm(q[:,1:3],dim=-1)
    return dict(seed=20261022,batch_size=8192,terminal_samples=1024,
                terminal_mae=float(b.detach()),vi_mae=float(p.detach()),terminal_weight=weight,
                terminal_gradient_l2=float(gb.norm()),physics_gradient_l2=float(gp.norm()),
                weighted_terminal_to_physics_gradient_l2=float(weight*gb.norm()/gp.norm().clamp_min(1e-12)),
                gradient_cosine=float(torch.dot(gp,gb)/(gp.norm()*gb.norm()).clamp_min(1e-12)),
                value_symmetry_mae=float(symmetry.mean()),
                positive_time_derivative_fraction=float((dv[:,0]>.01).float().mean()),
                near_region_vi_mae=float(r.detach()[radius<=1].abs().mean()),
                far_region_vi_mae=float(r.detach()[radius>1].abs().mean()),
                note='Single diagnostic batch, not a proof of cause. Value symmetry is y,psi -> -y,-psi. No optimizer step.')


def compare_plot(results,folder):
    labels=list(results)
    fig,axs=plt.subplots(1,3,figsize=(13,4),layout='constrained')
    for label,m in results.items():
        times=[float(t) for t in m['comparisons']]
        axs[0].plot(times,[v['mae'] for v in m['comparisons'].values()],marker='o',label=label)
        axs[1].plot(times,[100*v['false_safe_fraction_of_reference_unsafe'] for v in m['comparisons'].values()],marker='o',label=label)
        axs[2].plot(times,[v['iou'] for v in m['comparisons'].values()],marker='o',label=label)
    for ax,title,ylabel in zip(axs,['Value error','False-safe classifications','Unsafe-region overlap'],['MAE [m]','% of reference-unsafe','IoU']):
        ax.set_title(title); ax.set_xlabel('Time remaining [s]'); ax.set_ylabel(ylabel); ax.grid(alpha=.25)
    axs[0].legend(fontsize=8)
    fig.savefig(folder/'comparison.png',dpi=160); plt.close(fig)


def report(results,diagnostic,folder):
    rows=[]
    for label,m in results.items():
        final=m['comparisons']['0.5']
        rows.append(dict(variant=label,steps=m['completed_steps'],new_training_seconds=m.get('additional_training_seconds',m['training_seconds']),
                         terminal_mae=m['heldout']['terminal_mae'],vi_mae=m['heldout']['pde_vi_mae'],
                         value_mae=final['mae'],value_rmse=final['rmse'],iou=final['iou'],
                         false_safe_among_reference_unsafe=final['false_safe_fraction_of_reference_unsafe'],
                         false_unsafe_among_reference_safe=final['false_unsafe_fraction_of_reference_safe'],
                         disagreement=final['disagreement_fraction']))
    with open(folder/'comparison.csv','w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    dump(folder/'comparison.json',dict(results=results,summary=rows))
    lines=['# Experiment 2 — Controlled error-reduction tests','',
           'Three separate candidates are compared against the unchanged Experiment 1 baseline. These are single-seed exploratory tests; no candidate is assumed to help and no statistical generalization or safety guarantee is claimed.','',
           '## Design','',
           '| Variant | Only deliberate change | New optimizer steps |','|---|---|---|',
           '| A — Loss weight | Divide the initially calibrated terminal multiplier by 10; keep it fixed afterward | 12,000, fresh run |',
           '| B — Focused sampling | 50% of nonterminal physics states in a uniform-area radius-1 m disk; the rest uniform in the original box | 12,000, fresh run |',
           '| C — Full-horizon hold | Continue Experiment 1 with its exact optimizer and RNG state for 10,000 more steps, sampling the full [0,.5] s time interval | 10,000 additional; 22,000 cumulative |','',
           'Architecture, physical dynamics, learning rate, domain, horizon and seed stay fixed. Terminal pretraining and terminal-coordinate sampling stay uniform. A and B use the same 2,000 + 10,000 step schedule as Experiment 1; C intentionally spends additional compute. No reference labels enter training. The focus radius is the physical bound R+2*v*T=1 m, not a value learned from the reference. The sampling mixture intentionally changes the physics-training distribution; no importance correction is applied.','',
           'The original checked reference grid is reused. Evaluation uses the same 24,000 interior states, seed and time slices as Experiment 1, plus the same full-box terminal/VI diagnostic distribution. Original Experiment 1 metrics were reproduced before these runs.','',
           '## Baseline diagnostic batch','',
           f"Weighted terminal/PDE gradient L2 ratio: {diagnostic['weighted_terminal_to_physics_gradient_l2']:.3f}. Gradient cosine: {diagnostic['gradient_cosine']:.3f}. Near-region VI MAE: {diagnostic['near_region_vi_mae']:.5f}; far-region VI MAE: {diagnostic['far_region_vi_mae']:.5f}. This is one batch, not a causal attribution.",'',
           '## Measured results at .5 s','',
           '| Variant | Value MAE [m] | RMSE [m] | IoU | False-safe / reference-unsafe | False-unsafe / reference-safe | Terminal MAE [m] | VI MAE | New training [s] |',
           '|---|---|---|---|---|---|---|---|---|']
    for r in rows:
        lines.append(f"| {r['variant']} | {r['value_mae']:.5f} | {r['value_rmse']:.5f} | {r['iou']:.3f} | {100*r['false_safe_among_reference_unsafe']:.2f}% | {100*r['false_unsafe_among_reference_safe']:.2f}% | {r['terminal_mae']:.5f} | {r['vi_mae']:.5f} | {r['new_training_seconds']:.1f} |")
    lines += ['', 'False-safe is PINN>0 and reference<=0, divided by the number of reference-unsafe states. A lower false-safe rate can accompany excessive unsafe predictions, so value error, false-unsafe rate and IoU must also be considered. The reference is approximate; its original refinement/boundary checks are recorded with Experiment 1.','',
              '![Paired comparison](comparison.png)','', '## Outcome','']
    baseline=rows[0]
    for r in rows[1:]:
        change=100*(r['value_mae']/baseline['value_mae']-1)
        fs=100*(r['false_safe_among_reference_unsafe']-baseline['false_safe_among_reference_unsafe'])
        lines.append(f"- {r['variant']}: value MAE changed {change:+.1f}% and false-safe rate changed {fs:+.2f} percentage points against Experiment 1.")
    lines += ['', 'These results establish only what happened for seed 7 and these particular settings. They do not isolate seed variability, prove any method universally superior, or demonstrate paper-scale reproduction. A and B each modify one setting; C tests additional compute without changing its baseline loss or sampling. A combined variant was not run.','',
              '## Saved data','',
              '- comparison.json and comparison.csv contain aggregate data for all variants and the baseline.',
              '- baseline_diagnostics.json records the pre-run value/loss checks.',
              '- manifest.json records source/config/cache hashes, run paths, checkpoint hashes and execution metadata.',
              '- Each variant run folder contains its checkpoint, config, history, environment, validation metrics and plots.',
              '- See PLAN.md for the predefined settings and status.json for pipeline completion.',
              '- Raw checkpoints, training logs and reference arrays are saved locally. No GitHub upload is performed by this experiment script.']
    (folder/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def run(folder):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
    root=Path(__file__).parent
    baseline=root/'runs/air3d_cpu_20261022'
    cache=baseline/'validation/reference_fine.npz'
    baseline_hash=sha(baseline/'checkpoint.pt')
    cache_hash=sha(cache)
    variants=[('A - Loss weight','experiment2_a_loss.json','experiment_2_a_loss_20261022'),
              ('B - Focused sampling','experiment2_b_sampling.json','experiment_2_b_sampling_20261022'),
              ('C - Full-horizon hold','experiment2_c_hold.json','experiment_2_c_hold_20261022')]
    manifest=dict(date='2026-10-22',status='running',execution='VS Code Run and Debug, internal console',
                  baseline_checkpoint_sha256=baseline_hash,reference_sha256=cache_hash,
                  source_sha256={p.name:sha(p) for p in [root/'deepreach.py',root/'validate.py',root/'experiment2.py',root/'reference.py']},variants={})
    dump(folder/'manifest.json',manifest)
    try:
        print('Experiment 2: verify baseline measurements using the saved reference',flush=True)
        dump(folder/'status.json',dict(status='baseline checks',updated=time.time()))
        diagnostics=diagnose(baseline/'checkpoint.pt'); dump(folder/'baseline_diagnostics.json',diagnostics)
        original=json.loads((baseline/'validation/metrics.json').read_text())
        verified=evaluate(baseline/'checkpoint.pt',folder/'baseline_recheck',reference_cache=cache,verbose=False)
        for t in original['comparisons']:
            if abs(original['comparisons'][t]['mae']-verified['comparisons'][t]['mae'])>1e-7:
                raise ValueError('Baseline evaluation does not reproduce Experiment 1')
        results={'Experiment 1':verified}
        for label,name,directory in variants:
            cfg_path=root/'configs'/name; cfg=json.loads(cfg_path.read_text())
            out=root/'runs'/directory; expected=cfg['pretrain_steps']+cfg['curriculum_steps']+cfg.get('full_horizon_steps',0)
            dump(folder/'status.json',dict(status='training',variant=label,output=str(out),updated=time.time()))
            print(f'\nExperiment 2: {label}',flush=True)
            if (out/'checkpoint.pt').exists():
                _,saved=load_checkpoint(out/'checkpoint.pt')
                if saved['config']!=cfg: raise ValueError('Existing variant config mismatch')
                if saved['step']<expected: train(cfg,out,resume=out/'checkpoint.pt')
                elif saved['step']!=expected: raise ValueError('Unexpected completed iteration')
                else: print('Reusing completed variant checkpoint',flush=True)
            else:
                train(cfg,out,extend_from=baseline/'checkpoint.pt' if label.startswith('C') else None)
            dump(folder/'status.json',dict(status='evaluating',variant=label,updated=time.time()))
            metrics=evaluate(out/'checkpoint.pt',out/'validation',reference_cache=cache,verbose=False)
            results[label]=metrics
            manifest['variants'][label]=dict(run_directory=str(out),config_sha256=sha(cfg_path),checkpoint_sha256=sha(out/'checkpoint.pt'),
                                             completed_steps=metrics['completed_steps'],value_mae=metrics['comparisons']['0.5']['mae'],
                                             false_safe=metrics['comparisons']['0.5']['false_safe_fraction_of_reference_unsafe'])
            dump(folder/'manifest.json',manifest)
            print(f"{label} complete: MAE={metrics['comparisons']['0.5']['mae']:.5f} m, false-safe={100*metrics['comparisons']['0.5']['false_safe_fraction_of_reference_unsafe']:.2f}%",flush=True)
        assert sha(baseline/'checkpoint.pt')==baseline_hash and sha(cache)==cache_hash
        compare_plot(results,folder); report(results,diagnostics,folder)
        manifest['status']='completed'; dump(folder/'manifest.json',manifest)
        dump(folder/'status.json',dict(status='completed',updated=time.time()))
        print('\nExperiment 2 completed. Report: '+str(folder/'README.md'),flush=True)
    except Exception as exc:
        dump(folder/'status.json',dict(status='failed',error=str(exc),updated=time.time()))
        raise


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--train',action='store_true'); ap.add_argument('--out',default='outputs/deepreach/experiments/experiment_2')
    a=ap.parse_args()
    if not a.train: ap.error('The experiment includes training; supply --train explicitly.')
    run(a.out)

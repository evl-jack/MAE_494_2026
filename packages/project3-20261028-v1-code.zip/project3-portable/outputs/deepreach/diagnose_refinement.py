"""Three post-refinement diagnostics. Reads frozen checkpoints; never trains."""
import csv
import json
import time
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from deepreach import load_checkpoint, residual
from diagnostics import ROOT, dump, sha, write_csv
from validate import predict, classification


def fields(model,queries,c):
    values=[];res=[]
    for start in range(0,len(queries),1024):
        q=torch.tensor(queries[start:start+1024],dtype=torch.float32)
        r,v,_=residual(model,q,c,False)
        values.append(v.detach().numpy());res.append(r.detach().numpy())
    return np.concatenate(values),np.concatenate(res)


def run():
    started=time.perf_counter();torch.set_num_threads(2)
    parent=ROOT/'experiments/experiment_3_d_refinement'
    out=parent/'followup_diagnostics';out.mkdir(parents=True,exist_ok=True)
    em=json.loads((parent/'evaluation_manifest.json').read_text())
    protected=dict(em['protected_inputs'])
    extra=[parent/'endpoint_values.npz',parent/'evaluation_physics_queries.npz',parent/'final_comparison.json',
           ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv']
    protected.update({str(p.relative_to(ROOT)):sha(p) for p in extra})
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    dump(out/'diagnostic_protocol.json',dict(training=False,topics=['physics by location','separation over horizon','broad value correction versus boundary shift'],
        physics_inputs='Reuse 8192 development audit queries, seed 991736; no new reference labels.',
        value_inputs='Existing 24000 development states and predictions, 21 horizons.',
        boundary_band_m=.02,paired_change_tolerance_m=1e-6,
        separation_threshold_m=.0001,uniform_shift='Mean Adam200-minus-3A value change at each horizon, fitted from predictions only; offline descriptive comparison, not a model.',
        reserved_final_states_used=False))
    with np.load(ROOT/'lookahead_21points_20261027/heldout_values.npz') as f:
        states=f['states'].copy();times=f['times'].copy();reference=f['reference'].copy()
    with np.load(parent/'endpoint_values.npz') as f:
        names=[k for k in f.files if k!='times'];values={k:f[k].copy() for k in names}
        np.testing.assert_array_equal(times,f['times'])
    with np.load(parent/'evaluation_physics_queries.npz') as f:audit=f['queries'].copy()
    with extra[-1].open() as stream:top=np.array([int(r['state_index']) for r in csv.DictReader(stream)])
    endpoints=json.loads((parent/'training_manifest.json').read_text())['endpoints']
    paths={'3A':ROOT/'runs/experiment_3_a_constraints/checkpoint.pt',
           **{e['method']+'_'+str(e['steps']):ROOT/e['checkpoint'] for e in endpoints}}
    old_metrics={r['model']:r for r in json.loads((parent/'final_comparison.json').read_text())}
    core=np.max(abs(audit[:,1:3]),axis=1)<=.6
    time_masks={'terminal':audit[:,0]==0}
    for j in range(5):time_masks[f'({j/10:.1f},{(j+1)/10:.1f}]']=(audit[:,0]>j/10)&(audit[:,0]<=(j+1)/10)
    assert np.all(np.sum(list(time_masks.values()),axis=0)==1)
    audit_res={};interior_res={};slices={};model_checks=[]
    axis=np.linspace(-.6,.6,121);xx,yy=np.meshgrid(axis,axis,indexing='xy')
    slice_queries=np.column_stack([np.full(xx.size,.5),xx.ravel(),yy.ravel(),np.full(xx.size,np.pi)])
    for name in names:
        print('Frozen diagnostic fields: '+name,flush=True)
        model,ck=load_checkpoint(paths[name]);model.eval();c=ck['config']
        original={k:v.clone() for k,v in model.state_dict().items()}
        _,audit_res[name]=fields(model,audit,c)
        np.testing.assert_allclose(abs(audit_res[name]).mean(),old_metrics[name]['audit_physics_loss'],rtol=2e-6,atol=1e-8)
        rr=[]
        for j,t in enumerate(times):
            q=np.column_stack([np.full(len(states),t),states]);v,r=fields(model,q,c)
            np.testing.assert_allclose(v,values[name][j],rtol=2e-5,atol=2e-6)
            rr.append(r)
        interior_res[name]=np.stack(rr)
        slices[name]=predict(model,slice_queries).reshape(xx.shape)
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in original.items())
        assert all(p.grad is None for p in model.parameters())
        model_checks.append(dict(model=name,weights_unchanged=True,no_parameter_gradients=True,predictions_match_saved=True,audit_matches_saved=True))
    location=[];joint=[];base_abs=abs(audit_res['3A']).astype(float)
    region_masks={'core':core,'outside_core':~core}
    for name in names:
        ar=abs(audit_res[name]).astype(float);gain=base_abs-ar;total=float(gain.mean())
        for region,mask in region_masks.items():
            row=dict(model=name,region=region,count=int(mask.sum()),point_fraction=float(mask.mean()),
                baseline_mean_abs_residual=float(base_abs[mask].mean()),mean_abs_residual=float(ar[mask].mean()),
                relative_reduction_percent=float(100*gain[mask].mean()/base_abs[mask].mean()),
                baseline_loss_share=float(base_abs[mask].sum()/base_abs.sum()),
                weighted_loss_reduction=float(gain[mask].sum()/len(audit)),
                share_of_total_reduction=float(gain[mask].sum()/len(audit)/total) if abs(total)>1e-12 else 0.)
            location.append(row)
            for time_bin,tm in time_masks.items():
                both=mask&tm;assert both.any()
                joint.append(dict(model=name,region=region,time_bin=time_bin,count=int(both.sum()),
                    baseline_mean_abs_residual=float(base_abs[both].mean()),mean_abs_residual=float(ar[both].mean()),
                    relative_reduction_percent=float(100*gain[both].mean()/base_abs[both].mean()),
                    weighted_loss_reduction=float(gain[both].sum()/len(audit))))
        np.testing.assert_allclose(sum(r['weighted_loss_reduction'] for r in location if r['model']==name),total,atol=1e-12)
        np.testing.assert_allclose(sum(r['weighted_loss_reduction'] for r in joint if r['model']==name),total,atol=1e-12)
    write_csv(out/'physics_by_location.csv',location);write_csv(out/'physics_by_location_and_time.csv',joint)
    base=values['3A'].astype(float);base_error=base-reference
    horizon=[];groups=[];partitions=[];shifts=[]
    top_mask=np.zeros(len(states),dtype=bool);top_mask[top]=True
    for j,t in enumerate(times):
        ref=reference[j];be=base_error[j];baseline_abs=abs(be)
        masks={'reference_deep_unsafe':ref<-.02,'reference_boundary_band':abs(ref)<=.02,'reference_far_safe':ref>.02}
        assert np.all(np.sum(list(masks.values()),axis=0)==1)
        extra_masks={'all':np.ones(len(states),dtype=bool),'ahead':states[:,0]>0,'behind':states[:,0]<=0,
            'initial_collision':np.hypot(states[:,0],states[:,1])<=.25,
            'initially_separated':np.hypot(states[:,0],states[:,1])>.25,'fixed_outliers':top_mask,
            'same_3A_adam200_classification':(base[j]<=0)==(values['adam_200'][j]<=0)}
        for name in names:
            pred=values[name][j].astype(float);er=pred-ref;change=pred-base[j]
            gain=baseline_abs-abs(er);ar=abs(interior_res[name][j]);br=abs(interior_res['3A'][j])
            horizon.append(dict(model=name,time=float(t),mae=float(abs(er).mean()),mae_reduction=float(gain.mean()),
                relative_mae_reduction_percent=float(100*gain.mean()/baseline_abs.mean()),
                bias=float(er.mean()),physics_mae=float(ar.mean()),
                physics_reduction_percent=float(100*(br.mean()-ar.mean())/br.mean()),
                fraction_states_improved=float(np.mean(gain>1e-6)),fraction_states_worsened=float(np.mean(gain< -1e-6)),
                mean_value_change=float(change.mean()),value_change_std=float(change.std()),
                fraction_predictions_raised=float(np.mean(change>1e-6))))
            for group,mask in {**masks,**extra_masks}.items():
                count=int(mask.sum())
                row=dict(model=name,time=float(t),group=group,count=count,
                    baseline_mae=float(baseline_abs[mask].mean()) if count else None,
                    mae=float(abs(er[mask]).mean()) if count else None,
                    weighted_mae_reduction=float(gain[mask].sum()/len(states)),
                    mean_value_change=float(change[mask].mean()) if count else None,
                    fraction_states_improved=float(np.mean(gain[mask]>1e-6)) if count else None,
                    fraction_states_worsened=float(np.mean(gain[mask]<-1e-6)) if count else None,
                    physics_mae=float(ar[mask].mean()) if count else None)
                groups.append(row)
                if group in masks:partitions.append(row)
            np.testing.assert_allclose(sum(r['weighted_mae_reduction'] for r in partitions if r['model']==name and r['time']==float(t)),gain.mean(),atol=1e-12)
        delta=values['adam_200'][j].astype(float)-base[j];constant=float(delta.mean());shifted=base[j]+constant
        shifted_error=shifted-ref;actual_mae=float(abs(values['adam_200'][j]-ref).mean());denom=float(np.mean(delta**2))
        shifts.append(dict(time=float(t),constant_shift=constant,change_std=float(delta.std()),
            mean_component_fraction_of_change_energy=float(constant**2/denom) if denom>1e-20 else None,
            actual_mae=actual_mae,uniform_shift_mae=float(abs(shifted_error).mean()),baseline_mae=float(baseline_abs.mean()),
            uniform_shift_fraction_of_actual_mae_gain=float((baseline_abs.mean()-abs(shifted_error).mean())/(baseline_abs.mean()-actual_mae)) if baseline_abs.mean()-actual_mae>1e-10 else None,
            uniform_shift_false_safe_fraction=classification(shifted,ref)['false_safe_fraction_of_reference_unsafe'],
            uniform_shift_obstacle_violations=int(np.sum(shifted>np.hypot(states[:,0],states[:,1])-.25+1e-6))))
    write_csv(out/'horizon_diagnostics.csv',horizon);write_csv(out/'value_error_groups.csv',groups)
    write_csv(out/'error_partition_contributions.csv',partitions);write_csv(out/'uniform_shift_comparison.csv',shifts)
    # Exact classification transition counts at final time, using approximate
    # numerical reference only as a development comparator.
    ref=reference[-1];b=base[-1];a=values['adam_200'][-1].astype(float)
    truth=ref<=0;bu=b<=0;au=a<=0;gain=abs(b-ref)-abs(a-ref);delta=a-b
    classification_counts=dict(baseline_false_unsafe=int(np.sum(bu&~truth)),adam_false_unsafe=int(np.sum(au&~truth)),
        corrected_false_unsafe=int(np.sum(bu&~truth&~au)),new_false_unsafe=int(np.sum(~bu&~truth&au)),
        corrected_false_safe=int(np.sum(~bu&truth&au)),new_false_safe=int(np.sum(bu&truth&~au)),
        changed_classification=int(np.sum(bu!=au)),unchanged_classification=int(np.sum(bu==au)),
        unchanged_classification_mae_gain_share=float(gain[bu==au].sum()/gain.sum()),
        fraction_states_improved=float(np.mean(gain>1e-6)),fraction_states_worsened=float(np.mean(gain< -1e-6)),
        fraction_predictions_raised=float(np.mean(delta>1e-6)),mean_change=float(delta.mean()),change_std=float(delta.std()))
    main_final=[r for r in horizon if r['model']=='adam_200' and r['time']==.5][0]
    ahead_final=[r for r in groups if r['model']=='adam_200' and r['time']==.5 and r['group']=='ahead'][0]
    separation={}
    for other in names:
        if other in ['3A','adam_200']:continue
        gap=np.mean(abs(values[other]-reference),axis=1)-np.mean(abs(values['adam_200']-reference),axis=1)
        ids=np.flatnonzero((gap>1e-4)&(times>0))
        separation[other]=dict(first_horizon_adam200_better_by_0_0001m=float(times[ids[0]]) if len(ids) else None,
            horizons_adam200_better=int(np.sum((gap>1e-6)&(times>0))),final_mae_gap=float(gap[-1]))
    summary=dict(classification_final=classification_counts,adam200_final=main_final,adam200_ahead_final=ahead_final,
        uniform_shift_final=shifts[-1],horizon_separation=separation,
        physics_location_final=location,training=False,reserved_final_states_used=False)
    dump(out/'summary.json',summary)
    np.savez_compressed(out/'physics_fields.npz',audit_queries=audit,
        **{'audit_'+k:v for k,v in audit_res.items()},**{'interior_'+k:v for k,v in interior_res.items()})
    np.savez_compressed(out/'heading_pi_slice.npz',axis=axis,**slices)
    labels={'3A':'Original 3A','adam_200':'Adam +200','adam_800':'Adam +800',
        'plain_gradient_200':'Plain +200','second_moment_scaled_200':'Scaled +200'}
    colors=dict(zip(names,['tab:blue','tab:orange','tab:green','tab:red','tab:purple']))
    fig,axes=plt.subplots(1,3,figsize=(16,4.8),layout='constrained')
    candidates=names[1:];x=np.arange(len(candidates))
    for offset,region,label in [(-.18,'core','Comparison region'),(.18,'outside_core','Outside comparison region')]:
        axes[0].bar(x+offset,[next(r['relative_reduction_percent'] for r in location if r['model']==k and r['region']==region) for k in candidates],width=.36,label=label)
    axes[0].set_xticks(x,[labels[k] for k in candidates],rotation=30,ha='right');axes[0].set(title='1. Where physics loss improved',ylabel='Relative audit residual reduction [%]');axes[0].axhline(0,color='gray',lw=.7);axes[0].legend(fontsize=7)
    for name in names:
        hr=[r for r in horizon if r['model']==name]
        axes[1].plot(times,[r['mae'] for r in hr],label=labels[name],color=colors[name])
    axes[1].set(title='2. Accuracy versus horizon',xlabel='Look-ahead [s]',ylabel='Value MAE [m]');axes[1].legend(fontsize=7)
    gm=['reference_deep_unsafe','reference_boundary_band','reference_far_safe'];bottom=np.zeros(len(candidates))
    for group,label in zip(gm,['Deep unsafe (Vref < -.02)','Boundary band (|Vref| ≤ .02)','Far safe (Vref > .02)']):
        contributions=np.array([next(r['weighted_mae_reduction'] for r in partitions if r['model']==k and r['time']==.5 and r['group']==group) for k in candidates])
        axes[2].bar(x,1000*contributions,bottom=bottom,label=label);bottom+=1000*contributions
    axes[2].set_xticks(x,[labels[k] for k in candidates],rotation=30,ha='right');axes[2].set(title='3. Which states supply the accuracy gain?',ylabel='Contribution to overall MAE reduction [mm]');axes[2].legend(fontsize=7)
    fig.suptitle('Frozen Experiment 3D checkpoints: development diagnostics, no training')
    fig.savefig(out/'diagnostic_overview.png',dpi=170);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    change=slices['adam_200']-slices['3A'];im=axes[0].pcolormesh(xx,yy,change,shading='auto',cmap='coolwarm',vmin=-float(abs(change).max()),vmax=float(abs(change).max()))
    for name,style in [('3A','--'),('adam_200','-')]:axes[0].contour(xx,yy,slices[name],levels=[0],colors=['black'],linestyles=[style],linewidths=1.5)
    axes[0].set(title='Value change: Adam +200 minus 3A\nHeading π, horizon .5 s; zero contours dashed/solid',xlabel='Relative x [m]',ylabel='Relative y [m]',aspect='equal');fig.colorbar(im,ax=axes[0],label='Value change [m]')
    axes[1].scatter(ref,delta,s=2,alpha=.2);axes[1].axhline(delta.mean(),color='black',ls='--',label='Uniform shift = mean change');axes[1].axvspan(-.02,.02,color='gray',alpha=.15,label='Reference boundary band')
    axes[1].set(title='Changes vary across the state space',xlabel='Reference value at .5 s [m]',ylabel='Adam +200 minus 3A value [m]');axes[1].legend(fontsize=8)
    fig.savefig(out/'value_change_and_boundary.png',dpi=170);plt.close(fig)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    dump(out/'manifest.json',dict(status='completed',training=False,optimizer_created=False,parameter_updates=0,
        reserved_final_states_used=False,protected_inputs=protected,checks=model_checks,
        location_and_time_decomposition=True,mae_partition_decomposition=True,source_sha256=sha(ROOT/'diagnose_refinement.py'),
        scope='Frozen single-seed development diagnostics; no causal optimizer claim or control evaluation.',
        elapsed_seconds=time.perf_counter()-started,threads=2))
    print(json.dumps({k:v for k,v in summary.items() if k!='physics_location_final'},indent=2),flush=True)


if __name__=='__main__':run()

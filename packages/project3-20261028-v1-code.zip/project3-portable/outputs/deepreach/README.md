# DeepReach Air3D â€” 3D study and 6D failure diagnostics

**Final technical analysis prepared:** [Experiments 1–5, conclusions, limitations and recommendation](final_report/REPORT.md). The packet includes a draft researcher memo, evidence register and reproducibility guide. No new training or reserved 6D final evaluation was performed; researcher delivery and GitHub publication are pending.

**Experiment 5 training completed:** [Training results and recorded costs](experiments_6d/experiment_5_sampling/TRAINING_RESULTS.md). Uniform and residual-bank continuations each completed 2,000 added updates from the same 4C/Adam state (24,000 total) in VS Code. Endpoint checks pass and parent 4C is unchanged. [Common evaluation is complete](experiments_6d/experiment_5_sampling/evaluation/README.md): both improve final MAE by about 10%; 5R has no clear advantage over 5U and no primary contact reduction. A reference-feedback limitation also remains.

**Local physics-loss audit completed:** [Residual visibility and gradient priorities](experiments_6d/local_physics_audit/README.md). 4C has local wrong-sign residual .13324 versus global .01099; the failure region has a strong physics-loss signal. Residual magnitude alone does not distinguish local wrong turns in 6D, and broad-domain versus local physics gradients are nearly orthogonal. A fixed-budget physics-only coverage/priority test is justified, with broad validation; no training or new policy step occurred.

**Local reference refinement completed:** [Initial direction and switching maps](experiments_6d/local_reference_refinement/README.md). Three unchanged-solver levels through 193x193x144 and two derivative estimators retain the negative initial turn; both learned models choose positive. Finest estimates are -.188/-.191 m/rad. Initial-direction evidence strengthens, but the last grid change remains 15.4% in magnitude and nearby switching positions move. The subsequent physics-only residual audit is linked above. No training or policy rollout occurred in the reference audit.

**Shared failure diagnosed:** [Matched-state gradients and initial-turn interventions](experiments_6d/shared_failure_diagnostic/README.md). Autodiff agrees with finite differences, but both learned controllers initially turn opposite to both references. A 5 ms correction fails; the shortest tested successful prefixes are 10 ms for 3D_Long and 50 ms for 4C. Shorter prefixes can worsen clearance. Reference-gradient magnitude and early switching remain resolution-sensitive, so a training fix is not yet established. No training or final-test queries occurred.

**6D closed-loop tests completed:** [Policy matrix and remaining failure](experiments_6d/closed_loop_evaluation/README.md). On 576 posed reference-safe states (144 groups) against the reference pursuer, contacts fall from 40 (4A) to 9 (4B) to 4 (4C). The four 4C contacts are one encounter in four poses, shared by 3D_Long. The reference evader has none. Halving the control interval preserves these learned-policy outcomes. No training or final-state queries occurred.

**6D development evaluation completed:** [Results and gradient diagnostics](experiments_6d/development_evaluation/README.md). On fresh groups at 0.5 s, MAE is .08695 m (4A), .02631 m (4B), .02573 m (4C), versus .01943 m for fixed 3D_Long. The exact-output improvement transfers strongly; extra duration helps modestly. Equivalent-pose and heading-alias defects remain. Reference-stable control signs were promising; the subsequent closed-loop comparison is linked above. No training or final-state queries occurred.

**6D training completed:** [Results and histories](experiments_6d/TRAINING_RESULTS.md). All three frozen runs completed in VS Code: 4A (2,000 terminal-only + 10,000 physics updates), 4B (10,000 physics updates), and 4C (4B plus 12,000 full-horizon updates). Checkpoints and paired sample-stream checks pass. That training-stage record is retained unchanged; the subsequent value/invariance/gradient development evaluation is linked above.

**6D subsection:** [Network, protocol and saved runs](experiments_6d/README.md). The same two-vehicle game is represented in six joint coordinates. The [original design](experiments/experiment_4_joint6d/SPECIFICATION.md) and pre-training checks are retained as historical records. The existing 3D checkpoints and consumed final-state file remain unchanged.

**Study conclusions:** [What Experiments 1â€“3 established](experiments/CONCLUSIONS.md), including negative results, budget effects, final validation and unresolved control/6D questions. No new experiment was run for this synthesis.

**Final evaluation completed:** [Fixed final record](evaluation/final_evaluation_20261028/README.md). On the 24,000 previously unused states, Long22000 has final MAE .020080 m versus Adam +200's .022977 m: **12.61% improvement**, paired 95% interval **11.93%â€“13.25%**. It has lower MAE at all 20 nonzero horizons. No training or tuning occurred. The reserved set is now consumed; its original bytes and all checkpoints remain unchanged.

**Duration versus capacity (3E):** [Results](experiments/experiment_3_e_capacity_budget/RESULTS.md). Long64 at 22,000 total steps gives final MAE .019854 m, 12.99% below Adam +200; Wide96 at 10,000 gives .021266 m, 6.80% below it. Extra training/capacity helped in this single-seed comparison. Long64 is the strongest new development candidate; runtime and remaining defects are reported. Both training runs completed in VS Code; reserved final states remain unused.

**Optimizer-history check:** [Results](experiments/experiment_3_d_refinement/optimizer_history_probe/README.md). At fixed Adam +200 parameters, all 160 probes lower audit physics loss but none improves final MAE, including fresh Adam and plain gradients. Momentum alone does not explain the local residual/value mismatch. A small reference-discovered lead from older 3A is recorded without promoting a reference-selected step. No training or reserved final-test use.

**Geometry/horizon weighting probe:** [Results](experiments/experiment_3_d_refinement/geometry_horizon_probe/README.md). Weighting ahead, late-horizon physics improves local probes at original 3A but not at Adam +200: none of 72 weighted or 24 unweighted probes there lowers final-time value MAE. The physics-selected weighted candidate lowers focused audit loss 8.71% while worsening MAE 4.87%. Adam +200 stays unchanged; no weighted training run or final-test evaluation.

**3D follow-up diagnostics:** [Location, horizon and boundary/value changes](experiments/experiment_3_d_refinement/followup_diagnostics/README.md). Roughly 94% of controlled audit-loss improvement comes from outside the comparison square. Adam +200 improves values at 79.6% of final-time states; 97.3% of the net MAE gain occurs without changing classification. No training or reserved final-test evaluation.

**Short refinement (3D):** [Results](experiments/experiment_3_d_refinement/RESULTS.md). From the same 3A checkpoint, Adam +200 gives the best development value MAE (.02282 m, 12.31% better). Controlled plain/scaled directions lower audit physics loss about 32% but improve value MAE only 3â€“4%. Adam +800 is also recorded for the extra evaluation budget. Training ran in VS Code; all checkpoints are separate and final-test states remain unused.

**3A finite-step probes:** [Results and method](experiments/experiment_3_a/step_direction_probe/README.md). Of 120 independent hypothetical steps, the physics-selected candidate lowers audit physics loss 10.78% and final-time development MAE 2.90%. Plain-gradient and second-moment-scaled directions show promising local reductions; no optimizer superiority is established. No training or checkpoint changes; reserved final states remain unused.

**3A learning-signal diagnosis:** [Parameter gradients, squared correction and frozen Adam directions](experiments/experiment_3_a/learning_signals/README.md). Outliers have strong signals; final-time residual descent can oppose value-error descent, while hypothetical directions from the saved Adam state locally favor overall error reduction on eight sampled batches. No optimizer update or training was performed. Fresh final-evaluation inputs are reserved separately and unused.

**Time-sampling test (3C):** [Results](experiments/experiment_3_c/RESULTS.md). A 50/50 full-horizon/curriculum mixture, with 3A's identical initialization, spatial/heading samples and 10,000 updates, worsens final MAE from .02602 to .02996 m and false-unsafe rate from 7.10% to 8.68%. The fixed old outlier cohort improves 10%, but global and new worst-tail errors worsen. 3A remains the stronger overall baseline.

**Periodic-heading test (3B):** [Results](experiments/experiment_3_b/RESULTS.md). Equivalent-heading inconsistency is removed to numerical precision and the fixed old outlier cohort improves 26%, but final overall MAE worsens from .02602 to .03517 m and false-unsafe rate from 7.10% to 9.52%. 3A remains the stronger overall baseline. Both runs have 10,000 physics updates; 3B adds 64 parameters and matches 3A's sample sequence.

**3A outliers:** [Where the remaining errors concentrate](experiments/experiment_3_a/outliers/README.md). The worst 1% contribute 19.67% of squared error; all are initially separated with the pursuer ahead. Equivalent-heading inconsistencies support testing periodic inputs next. No retraining was performed for this analysis.

**Experiment 3A completed:** [Exact terminal/obstacle output results](experiments/experiment_3_a/RESULTS.md) for V=l-.25*(tau/T)*gÂ². The VS Code run took 220.28 s for the same 10,000 physics steps as A, omitting its 2,000 terminal-only steps. At .5 s, MAE fell from .04477 to .02602 m, relative L2 from 24.24% to 19.12%, IoU rose to .799, and no false-safe cases were observed in this validation set. False-unsafe rate is 7.10%. Remaining physical-bound, monotonicity and heading defects are recorded; no safety guarantee is claimed.

**Failure analysis:** [Where the errors occur and which exact game properties fail](failure_analysis_20261027/README.md). Covers collision geometry, heading periodicity, temporal monotonicity, equation residuals and curriculum exposure without training.

**Denser difficulty knob:** [21-point look-ahead evaluation](lookahead_21points_20261027/README.md) covers 0 to .5 s every .025 s, using directly computed numerical-reference snapshots and the same four saved networks. No additional training.

**27 October diagnostic supplement (no training):** [Look-ahead error, Fourier spectra and cost measurements](diagnostics_20261027/README.md), with [findings and implications](diagnostics_20261027/FINDINGS.md). The existing four checkpoints and reference are unchanged. Relative L2 at .5 s is 48.88% for Experiment 1 and 24.24% for A. These are validation diagnostics, not an untouched final test or a newly trained experiment.

**Experiment 2** ran all three candidates through VS Code Run and Debug on 22 October 2026. At .5 s, value MAE / false-safe among reference-unsafe states were A (lower terminal weight): .04477 m / 10.82%; B (focused sampling): .07189 m / 20.00%; C (10,000 additional full-horizon steps): .06048 m / 22.80%. A had the best value error and unsafe-region overlap in this single-seed comparison, but its terminal error and false-unsafe rate increased. See the [Experiment 2 report](experiments/experiment_2/README.md) for all metrics, saved data and limitations. The original baseline and reference were preserved.

The active code models two fixed-altitude drones in the Air3D collision-avoidance game. **Experiment 1** is the first trained baseline: a 12,000-step reduced CPU run completed on 22 October 2026. The 60-step smoke run is a preceding setup check, not another experiment. The CPU training loop took 206.4 seconds using two threads and saved a resumable checkpoint. See runs/air3d_cpu_20261022 for the actual run and its comparison outputs. This is a reduced experiment, not a paper-scale reproduction or a safety certificate.

**Experiment 1 outcome:** the baseline is not accurate enough for collision decisions. At .5 s, value MAE is .0915 m and 46.4% of reference-unsafe held-out states are labeled safe by the PINN. Grid refinement and checkpoint restart checks passed. See the [Experiment 1 report](experiments/experiment_1/README.md) for denominators, plots and limitations, or the [experiment index](experiments/README.md).

## The problem

Both drones fly at .75 m/s. The evader chooses turn u to maximize minimum separation while a worst-case pursuer chooses turn d to minimize it. Both rates lie in [-3,3] rad/s. Separation <=.25 m is unsafe. This is a planar relative-motion model, without altitude, thrust or full quadrotor dynamics.

Relative state s=(x,y,psi) is expressed in the evader's rotating frame:

    xdot   = .75*(cos(psi)-1) + u*y
    ydot   = .75*sin(psi) - u*x
    psidot = d-u
    l(s)   = sqrt(x*x+y*y)-.25

For spatial value gradient p, the avoid Hamiltonian and candidate controls are:

    H  = .75*((cos(psi)-1)*p_x+sin(psi)*p_y)
         +3*abs(y*p_x-x*p_y-p_psi)-3*abs(p_psi)
    u* =  3*sign(y*p_x-x*p_y-p_psi)
    d* = -3*sign(p_psi)

Time-to-go tau=T-t gives max(V_tau-H,V-l)=0, with V(0,s)=l(s).
For the ideal solution, V<=0 identifies states from which collision can be forced despite optimal evasion. A neural approximation's sign and control are not certified safe.

## Files

| File | Purpose |
|---|---|
| deepreach.py | Air3D dynamics, sine PINN, derivatives, physics loss, sampling, curriculum, training and checkpoint code |
| reference.py | Independent NumPy HJI grid solver and periodic heading interpolation |
| preflight.py | Implementation checks; never trains |
| validate.py | Trained-PINN/reference comparisons, diagnostics and plots |
| experiment2.py | Sequential VS Code experiment runner for the three controlled candidates |
| diagnostics.py | Evaluation only: relative L2 versus look-ahead, spatial/heading error spectra, inference and reference-build timing |
| configs/ | Smoke, reduced CPU and full paper-scale budgets |
| checks/ | Actual implementation-check results; these are not trained PINN results |
| PLAN.md | Air3D plan and explicit pause before training |
| AIR3D_PROPOSED_UPDATES.md | Earlier proposal, with status updated |
| THIRD_PARTY_NOTICES.md | Source attribution and SIREN license |
| requirements.txt | Core dependency pins |
| requirements-lock.txt | Exact installed dependencies |
| VSCODE.md | VS Code Run and Debug instructions |
| runs/ | Actual checkpoints, configs, logs, provenance, metrics and plots |

## Sources and departures

Paper: [Bansal and Tomlin, DeepReach](https://arxiv.org/abs/2011.02082).
Official source: [smlbansal/deepreach](https://github.com/smlbansal/deepreach/tree/a8127aa7825d58623e9646211644876c83dd71d0), public_release commit a8127aa7825d58623e9646211644876c83dd71d0, dated 13 November 2024. The homework copy includes this source in references/upstream-a8127aa.

The full physical parameters and 1 s horizon follow the paper. Full uses three actual sine hidden layers of width 512. The modern repository's num_hl=3 creates four sine hidden layers; its constructor and the paper's architecture wording are not treated as equivalent.

Experiments 1/2 use original soft terminal loss (vanilla value semantics). The modern Air3D constructor and launcher default to exact, enforcing V=l+25*tau*network. The diff option adds l without the tau multiplier. Those upstream alternatives remain unimplemented; the separate Experiment 3A candidate uses the squared nonpositive correction documented above.

Inputs normalize time by T, x/y by domain half-width, and psi by 1.2*pi. Output is 25*network+.25. Autodiff includes physical-unit chain rules. Hidden activations are sin(30*z), with SIREN weight initialization. Losses use mean absolute errors. The terminal loss weight is calibrated once at curriculum start to balance initial terms, then fixed: a documented interpretation of the paper's initial balancing, distinct from the modern repository's optional adaptive parameter-gradient weighting and sum losses. Terminal samples also enter the physics loss, as upstream does.

| Config | Sine hidden layers | Samples/step | Pretrain + curriculum | Horizon | x/y domain |
|---|---|---|---|---|---|
| smoke | 3 x 32 | 256 | 20 + 40 | .5 s | [-2,2] m |
| cpu | 3 x 64 | 2048 | 2000 + 10000 | .5 s | [-2,2] m |
| full | 3 x 512 | 65000 | 10000 + 100000 | 1 s | [-3,3] m |

All select CPU and Adam at 1e-4. Full is paper-scale, rather than an exact recreation of every paper setting. The widened domains depart from the repository's [-1,1] scaling and support an interior comparison on [-.6,.6]^2. Since evader-frame rotation preserves radius and radial speed is bounded by 2v, all dependency trajectories from that square have radius <=sqrt(2)*.6+2*v*T: <2 for the reduced horizon and <3 for full. Numerical boundary sensitivity must still be checked at the actual horizon. This interior region does not necessarily contain the entire BRT.

## Independent numerical reference

The NumPy solver implements Air3D independently of the PINN. It uses positive local Lax-Friedrichs viscosity for V_tau=H, explicit Euler steps, and obstacle projection V=min(V,l). Heading is periodic; spatial ghost cells use constant extension.

    alpha_x   = abs(v*(cos(psi)-1)) + omega*abs(y)
    alpha_y   = abs(v*sin(psi))    + omega*abs(x)
    alpha_psi = 2*omega
    dt <= .8 / max(alpha_x/dx + alpha_y/dy + alpha_psi/dpsi)

These speed bounds and CFL give a monotone update. Spatial extension is artificial; compare only in the interior and test against an expanded domain at matching spacing and time-step schedule. Future full validation uses 65/97/129 spatial nodes and 48/72/96 headings. These approximate references have diffusion, especially on the larger full domain; refinement does not provide a rigorous error bound. Reference labels never enter PINN training.

## Setup and checks: no training

From the project root with Python 3.12:

    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r outputs/deepreach/requirements.txt
    .\.venv\Scripts\python.exe outputs/deepreach/preflight.py --config outputs/deepreach/configs/cpu.json --out outputs/deepreach/checks/preflight_cpu.json

Add --upstream references/upstream-a8127aa to compare against the bundled official source. In the original Codex workspace the source is work/upstream and the existing interpreter is work/venv/Scripts/python.exe.

Preflight checks autodiff versus finite differences, explicit max-min optimization, NumPy/PyTorch Hamiltonians, physical-time signs, finite physics-loss parameter derivatives without applying them, sampling, a .1 s grid refinement, larger-domain sensitivity, frozen dynamics, no-turn analytic agreement and the periodic heading seam. The randomly initialized network has not learned a value function. Saved checks include software versions and optimizer_steps=0.

## Training commands

The launcher refuses to train without --train and refuses to overwrite an existing checkpoint without --resume. The dated smoke and CPU runs below have completed. For a new experiment, choose a fresh output folder.

    .\.venv\Scripts\python.exe outputs/deepreach/deepreach.py --train --config outputs/deepreach/configs/smoke.json --out outputs/deepreach/runs/air3d_smoke_20261022
    .\.venv\Scripts\python.exe outputs/deepreach/deepreach.py --train --config outputs/deepreach/configs/cpu.json --out outputs/deepreach/runs/air3d_cpu_20261022
    .\.venv\Scripts\python.exe outputs/deepreach/validate.py --checkpoint outputs/deepreach/runs/air3d_cpu_20261022/checkpoint.pt --out outputs/deepreach/runs/air3d_cpu_20261022/validation

Resume by adding --resume outputs/deepreach/runs/air3d_cpu_20261022/checkpoint.pt to the identical training command. Configs must match exactly; old Dubins checkpoints are rejected. Full training substitutes configs/full.json and a separate output directory and requires substantial compute; it has not run. CUDA requires suitable hardware, installation and a device config change. This laptop has integrated Intel graphics and uses CPU PyTorch.

Normal validation does not train. Its optional --check-training-resume runs a six-step optimizer sequence both continuously and with a split restart. The reduced-run comparison command on 22 October includes that check. Comparison outputs include held-out terminal/VI errors, value errors, BRT overlap, false-safe fractions and slices at multiple times/headings. See the actual metrics and results report for measured agreement and limitations. Loss alone does not establish correctness. Empirical agreement is not a safety guarantee; a gradient reliability study remains outside scope.

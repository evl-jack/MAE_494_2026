"""Experiment 3A implementation checks. No optimizer is created or stepped."""
import argparse
import importlib.util
import json
import io
from pathlib import Path

import numpy as np
import torch

from deepreach import Siren, load_checkpoint, residual, target, validate_config, environment
from diagnostics import ROOT, RUNS, sha, dump
from validate import mechanical_checks


def checks(config, out):
    c=json.loads(Path(config).read_text())
    validate_config(c)
    if c['formulation']!='terminal_obstacle_square':
        raise ValueError('This check is specific to the square candidate')
    torch.set_num_threads(c['threads']); torch.manual_seed(c['seed'])
    protected=[ROOT/'runs'/d/'checkpoint.pt' for _,_,d in RUNS]
    protected += [ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz']
    before_files={str(p.relative_to(ROOT)):sha(p) for p in protected}
    model=Siren(c).eval()
    before_weights={key:value.clone() for key,value in model.state_dict().items()}
    rng=np.random.default_rng(20261029)
    q=torch.tensor(rng.uniform([0,-2,-2,-1.2*np.pi],[.5,2,2,1.2*np.pi],(8192,4)),dtype=torch.float32)
    # Include origin and exact collision boundary for value checks, but do not
    # differentiate the nonsmooth radial target at the origin.
    special=torch.tensor([[0.,0.,0.,0.],[.5,0.,0.,0.],[.5,.25,0.,0.],[.5,.1,0.,0.]])
    values=model(torch.cat([q,special]))
    ell=target(torch.cat([q,special])[:,1:],c)
    assert torch.all(values<=ell)
    terminal=q.clone(); terminal[:,0]=0
    assert torch.equal(model(terminal),target(terminal[:,1:],c))
    inside=q.clone(); inside[:,1:3]*=.02
    assert torch.all(model(inside)<=0)
    manual=target(q[:,1:],c)-c['constraint_scale']*(q[:,0]/c['horizon'])*model.raw(q/model.scales).square()
    assert torch.equal(model(q),manual)
    mechanical=mechanical_checks(model,c)
    # Evaluate actual differentiable physics loss, without an optimizer/update.
    r,_,_=residual(model,q[:512],c,True)
    params=tuple(model.parameters())
    gradients=torch.autograd.grad(r.abs().mean(),params)
    assert all(torch.isfinite(g).all() for g in gradients)
    norms=[float(g.norm()) for g in gradients]
    assert all(n>0 for n in norms), norms
    with torch.no_grad():
        g=model.raw(q/model.scales)
        correction=target(q[:,1:],c)-model(q)
    # An independent hand-set function verifies the formula at known values.
    hand=Siren(c)
    with torch.no_grad():
        hand.layers[-1].weight.zero_(); hand.layers[-1].bias.fill_(1.)
    probe=torch.tensor([[0.,.4,0.,0.],[.25,.4,0.,0.],[.5,.4,0.,0.]])
    np.testing.assert_allclose(hand(probe).detach().numpy(),[.15,.025,-.1],atol=1e-7)
    # Legacy checkpoint inference must remain bit-for-bit identical to the
    # archived baseline implementation under the new optional output branch.
    archive=ROOT/'runs/air3d_cpu_20261022/source/deepreach.py'
    spec=importlib.util.spec_from_file_location('archived_soft_terminal',archive)
    old=importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    legacy={}
    for label,slug,directory in RUNS:
        current,ck=load_checkpoint(ROOT/'runs'/directory/'checkpoint.pt')
        original=old.Siren(ck['config']); original.load_state_dict(ck['model']); original.eval()
        with torch.no_grad():
            assert torch.equal(current(q[:128]),original(q[:128]))
        legacy[slug]=dict(predictions_bitwise_identical=True)
    # Save/reload a temporary untrained fixture to test the new config branch.
    # This is not a run checkpoint and contains no optimizer/training state.
    fixture=io.BytesIO()
    torch.save(dict(model=model.state_dict(),config=c),fixture)
    fixture.seek(0)
    restored,_=load_checkpoint(fixture)
    with torch.no_grad():
        assert torch.equal(restored(q[:128]),model(q[:128]))
    for bad in [dict(c,pretrain_steps=1),dict(c,constraint_scale=0.),dict(c,constraint_initial_bias=0.)]:
        try:
            validate_config(bad)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid constrained initialization or schedule accepted')
    assert all(torch.equal(value,model.state_dict()[key]) for key,value in before_weights.items())
    after_files={str(p.relative_to(ROOT)):sha(p) for p in protected}
    assert before_files==after_files
    result=dict(status='implementation verified; training paused',optimizer_steps=0,
        reference_labels_used_for_training=False,environment=environment('cpu'),
        terminal_exact=True,obstacle_exact_for_tested_nonnegative_times=True,
        already_collided_predictions_nonpositive=True,formula_matches_hand_example=True,
        mechanical=mechanical,physics_parameter_gradient_norms=norms,
        initialization=dict(raw_min=float(g.min()),raw_max=float(g.max()),raw_mean=float(g.mean()),
                            correction_mean_m=float(correction.mean()),vi_mae=float(r.detach().abs().mean())),
        legacy=legacy,untrained_reload_bitwise_identical=True,weights_unchanged=True,
        invalid_configs_rejected=True,protected_inputs=after_files,
        sources={name:sha(ROOT/name) for name in ['deepreach.py','validate.py','check_constraints.py']},
        config_sha256=sha(config),parameter_count=sum(p.numel() for p in model.parameters()),
        limitations='No trained candidate, optimizer trajectory or accuracy improvement tested. Spatial derivatives of l are nonsmooth at x=y=0; derivative probes exclude that point.')
    Path(out).parent.mkdir(parents=True,exist_ok=True)
    dump(out,result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default=str(ROOT/'configs/experiment3a_constraints.json'))
    parser.add_argument('--out',default=str(ROOT/'experiments/experiment_3_a/implementation_checks.json'))
    args=parser.parse_args()
    checks(args.config,args.out)

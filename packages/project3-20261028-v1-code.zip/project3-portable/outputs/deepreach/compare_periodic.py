"""Evaluate periodic-heading Experiment 3B; no training or reference solve."""
import argparse
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch
from deepreach import load_checkpoint, value_grad, hamiltonian, target
from diagnostics import ROOT, dump, sha, write_csv, relative_l2
from validate import predict, error, classification, evaluate


def run(folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    run_dir=ROOT/'runs/experiment_3_b_periodic'; checkpoint=run_dir/'checkpoint.pt'
    model,ck=load_checkpoint(checkpoint);model.eval();c=ck['config'];torch.set_num_threads(2)
    if ck['step']!=10000 or c.get('heading_encoding')!='sin_cos':raise ValueError('Expected completed 3B')
    a_path=ROOT/'runs/experiment_3_a_constraints/checkpoint.pt'
    _,base=load_checkpoint(a_path)
    assert torch.equal(ck['torch_rng'].cpu(),base['torch_rng'].cpu())
    for key in base['config']:
        if c[key]!=base['config'][key]:raise ValueError('Unexpected config change: '+key)
    sweep=ROOT/'lookahead_21points_20261027/heldout_values.npz'
    raw_file=ROOT/'experiments/experiment_3_a/candidate_values.npz'
    outlier_file=ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv'
    fine=ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz'
    protected=[checkpoint,a_path,sweep,raw_file,outlier_file,fine]
    before={str(p.relative_to(ROOT)):sha(p) for p in protected}
    checks=json.loads((folder/'implementation_checks.json').read_text())
    for rel,expected in checks['protected_inputs'].items():assert sha(ROOT/rel)==expected
    with np.load(sweep) as f:states=f['states'];times=f['times'];truth=f['reference'];a=f['a']
    with np.load(raw_file) as f:np.testing.assert_array_equal(times,f['times']);raw=f['predictions']
    periodic=np.stack([predict(model,np.column_stack([np.full(len(states),t),states])) for t in times])
    np.savez_compressed(folder/'candidate_values.npz',times=times,predictions=periodic)
    ell=np.linalg.norm(states[:,:2],axis=1)-c['radius'];outside=ell>0
    rows=[]
    for slug,label,values in [('2a','Experiment 2A',a),('3a','Experiment 3A',raw),('3b','Experiment 3B',periodic)]:
        for k,t in enumerate(times):
            v,b=values[k],truth[k];o=classification(v[outside],b[outside])
            rows.append(dict(model=label,slug=slug,tau=float(t),relative_l2=relative_l2(v,b),**error(v,b),**classification(v,b),
                outside_collision_false_safe=o['false_safe_fraction_of_reference_unsafe'],
                outside_collision_false_unsafe=o['false_unsafe_fraction_of_reference_safe'],
                outside_reference_unsafe_count=o['reference_unsafe_count'],
                initially_collided_predicted_safe=int(np.sum(v[~outside]>0)),
                below_physical_minimum_fraction=float(np.mean(v<-c['radius']-1e-4)),
                obstacle_violation_fraction=float(np.mean(v>ell+1e-4)),
                increasing_value_fraction=float(np.mean(v>values[max(0,k-1)]+1e-5)) if k else 0.))
    write_csv(folder/'comparison.csv',rows);dump(folder/'comparison.json',rows)
    np.testing.assert_allclose(periodic[0],ell,atol=2e-7,rtol=0)
    assert np.all(periodic[:,~outside]<=0) and np.max(periodic-ell[None,:])<2e-7
    equations=[]
    for k,t in enumerate(times):
        q=torch.tensor(np.column_stack([np.full(6000,t),states[:6000]]),dtype=torch.float32)
        v,dv=value_grad(model,q);r=torch.maximum(dv[:,0]-hamiltonian(q[:,1:],dv[:,1:],c),v-target(q[:,1:],c))
        seam=[]
        for heading in [-np.pi,np.pi]:
            z=q.clone();z[:,3]=heading
            with torch.no_grad():seam.append(model(z).numpy())
        equations.append(dict(tau=float(t),vi_mae=float(r.detach().abs().mean()),
            heading_seam_mae=float(np.mean(abs(seam[1]-seam[0]))),
            positive_time_derivative_fraction=float((dv[:,0]>1e-4).float().mean())))
    write_csv(folder/'equation_checks.csv',equations);dump(folder/'equation_checks.json',equations)
    fixed=np.array([int(r['state_index']) for r in csv.DictReader(outlier_file.open())])
    old_error=raw[-1]-truth[-1];new_error=periodic[-1]-truth[-1]
    new_top=np.argsort(abs(new_error))[-240:]
    selected=[]
    for i in fixed:
        selected.append(dict(state_index=int(i),x=float(states[i,0]),y=float(states[i,1]),psi=float(states[i,2]),
            reference=float(truth[-1,i]),raw_prediction=float(raw[-1,i]),periodic_prediction=float(periodic[-1,i]),
            raw_error=float(old_error[i]),periodic_error=float(new_error[i])))
    write_csv(folder/'fixed_3a_outliers.csv',selected)
    alias_mask=abs(states[:,2])>=.8*np.pi
    alias=states[alias_mask].copy();alias[:,2]-=np.sign(alias[:,2])*2*np.pi
    alias_values=predict(model,np.column_stack([np.full(len(alias),.5),alias]))
    mirrored=states.copy();mirrored[:,1:]*=-1
    mirrored_values=predict(model,np.column_stack([np.full(len(states),.5),mirrored]))
    outliers=dict(fixed_3a_cohort_count=len(fixed),raw_mae=float(np.mean(abs(old_error[fixed]))),
        periodic_mae=float(np.mean(abs(new_error[fixed]))),
        fixed_cohort_mae_reduction_percent=float(100*(1-np.mean(abs(new_error[fixed]))/np.mean(abs(old_error[fixed])))),
        fixed_cohort_improved_count=int(np.sum(abs(new_error[fixed])<abs(old_error[fixed]))),
        new_top_mae=float(np.mean(abs(new_error[new_top]))),new_top_state_indices=new_top.tolist(),
        new_top_squared_error_share=float(np.sum(new_error[new_top]**2)/np.sum(new_error**2)),
        alias_gap_mae=float(np.mean(abs(alias_values-periodic[-1,alias_mask]))),
        alias_gap_max=float(np.max(abs(alias_values-periodic[-1,alias_mask]))),
        reflection_gap_mae=float(np.mean(abs(mirrored_values-periodic[-1]))))
    dump(folder/'outlier_summary.json',outliers)
    print('21-point and fixed-outlier comparisons complete; legacy validation next',flush=True)
    evaluate(checkpoint,run_dir/'validation',reference_cache=fine,verbose=False)
    fig,axes=plt.subplots(2,3,figsize=(15,8),layout='constrained')
    keys=['relative_l2','mae','false_safe_fraction_of_reference_unsafe','false_unsafe_fraction_of_reference_safe','iou','below_physical_minimum_fraction']
    titles=['Relative L2 [%]','Value MAE [m]','False-safe / reference-unsafe [%]','False-unsafe / reference-safe [%]','Unsafe-region IoU','Below physical minimum -R [%]']
    for slug,label in [('2a','Experiment 2A'),('3a','Experiment 3A'),('3b','Experiment 3B')]:
        rr=[r for r in rows if r['slug']==slug]
        for ax,key,title in zip(axes.flat,keys,titles):
            scale=1 if key in ['mae','iou'] else 100
            ax.plot(times,[scale*r[key] for r in rr],'o-',markersize=3,label=label);ax.set_title(title,fontsize=10)
            ax.set_xlabel('Look-ahead τ [s]');ax.grid(alpha=.25)
    axes[0,0].legend(fontsize=8);fig.suptitle('Periodic-heading test: identical 3A physics batches; 10,000 updates; +64 parameters')
    fig.savefig(folder/'comparison.png',dpi=170);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    axes[0].scatter(abs(old_error[fixed]),abs(new_error[fixed]),s=9,alpha=.6)
    limit=max(abs(old_error[fixed]).max(),abs(new_error[fixed]).max())
    axes[0].plot([0,limit],[0,limit],'k--');axes[0].set(xlabel='3A absolute error [m]',ylabel='3B absolute error [m]',title='Same 240 outliers: below diagonal improves')
    worst=int(fixed[0])
    for val,label in [(truth,'Reference'),(raw,'3A'),(periodic,'3B')]:axes[1].plot(times,val[:,worst],label=label)
    axes[1].axhline(0,color='gray',linestyle=':');axes[1].set(xlabel='Look-ahead τ [s]',ylabel='Value [m]',title=f'Former worst state #{worst}, fixed state')
    axes[1].legend();fig.savefig(folder/'outlier_comparison.png',dpi=170);plt.close(fig)
    after={str(p.relative_to(ROOT)):sha(p) for p in protected};assert before==after
    dump(folder/'manifest.json',dict(status='completed',training_source='VS Code Run and Debug',evaluation_trains=False,
        protected_inputs=after,checks=dict(inputs_unchanged=True,sampler_final_rng_matches_3a=True,terminal_and_obstacle=True),
        parameters=sum(p.numel() for p in model.parameters()),training_seconds=ck['elapsed_seconds'],completed_steps=ck['step'],
        sources={n:sha(ROOT/n) for n in ['deepreach.py','validate.py','compare_periodic.py']},evaluation_times=times.tolist()))
    final=[r for r in rows if r['tau']==.5]
    print(json.dumps(dict(final_metrics=final,outliers=outliers,training_seconds=ck['elapsed_seconds']),indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',default=str(ROOT/'experiments/experiment_3_b'))
    run(parser.parse_args().out)

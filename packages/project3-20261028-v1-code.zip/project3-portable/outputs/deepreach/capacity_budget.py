"""Experiment 3E: fixed duration/capacity comparison. Explicit --train required."""
import argparse
import ctypes
import hashlib
import json
import os
import shutil
import tempfile
import time
import winreg
from pathlib import Path
import numpy as np
import torch
from deepreach import Siren, load_checkpoint, raw_sampling_rng, residual, sample, train, environment
from validate import mechanical_checks
from diagnostics import ROOT, dump, sha

FOLDER=ROOT/'experiments/experiment_3_e_capacity_budget'
PARENT=ROOT/'runs/experiment_3_a_constraints/checkpoint.pt'
PARENT_SHA='44d19503406e4339fda5376c1074a20e5bf2c3508085af9f47d159e9858d8b62'


def configs():
    base=json.loads((ROOT/'configs/experiment3a_constraints.json').read_text())
    return base,dict(base,full_horizon_steps=12000),dict(base,width=96,sampling_initial_width=64)


def hardware():
    class Memory(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(n,ctypes.c_ulonglong) for n in ['total_phys','avail_phys','total_page','avail_page','total_virtual','avail_virtual','extended']]
    mem=Memory();mem.length=ctypes.sizeof(mem)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem)):raise OSError('Memory status unavailable')
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:
        cpu=winreg.QueryValueEx(key,'ProcessorNameString')[0]
    disk=shutil.disk_usage(ROOT)
    assert mem.avail_phys>4*1024**3 and disk.free>2*1024**3
    return dict(cpu=cpu,logical_processors=os.cpu_count(),physical_ram_gib=mem.total_phys/1024**3,
        available_ram_gib=mem.avail_phys/1024**3,disk_free_gib=disk.free/1024**3,
        torch_cuda_available=torch.cuda.is_available(),training_device='cpu',threads=2,
        method='Read-only registry CPU name, Windows memory status API, filesystem disk usage; CIM unavailable in this environment.')


def linear_macs(width):return 2*width*width+5*width


def preflight():
    FOLDER.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    assert sha(PARENT)==PARENT_SHA
    base,long,wide=configs();hw=hardware();_,parent=load_checkpoint(PARENT)
    assert base==parent['config']
    protocol=dict(experiment='3E: duration versus capacity',parent_sha256=PARENT_SHA,threads=2,seed=7,
        long64=dict(total_steps=22000,additional_steps=12000,curriculum_steps=10000,full_horizon_hold_steps=12000,
            snapshots=[10200,10800,12000,16000,22000]),
        wide96=dict(total_steps=10000,curriculum_steps=10000,full_horizon_hold_steps=0,sampling_initial_width=64),
        primary_endpoints=['original_3A_64_10000','long64_22000','wide96_10000'],
        secondary_endpoints=['saved_Adam200','long64_12000','long64_16000'],
        unchanged='Air3D physics, raw heading, 3 hidden sine layers, exact terminal/obstacle output, Adam lr .0001, 2048 samples/step, 256 zero-time physics points.',
        sampling='Wide network initialization has seed 7, then sampling RNG resets to post-width64 initialization. First 10000 physical batches match original 3A exactly.',
        budget=dict(linear_macs_per_point_64=linear_macs(64),linear_macs_per_point_96=linear_macs(96),
            wide_to_long_nominal_work_ratio=10000*linear_macs(96)/(22000*linear_macs(64)),
            note='Layer linear multiply-accumulate proxy only; not actual FLOPs, wall-time or derivative cost equivalence. Report timing and point counts too.'),
        evaluation='After all fixed endpoints complete: existing development references at 21 horizons, same physics audit as 3D, constraints and outliers. Reserved final states unused.',
        stopping='Fixed step counts, no reference-based early stopping; native checkpoints every 1000 steps plus declared snapshots.',
        scope='Single seed. Same-update capacity comparison uses 3A64 vs wide96; approximate compute comparison uses long64 vs wide96. Wider initialization and full-horizon exposure differ.')
    dump(FOLDER/'protocol.json',protocol);dump(FOLDER/'hardware.json',hw)
    for name,c in [('long64',long),('wide96',wide)]:dump(FOLDER/f'config_{name}.json',c)
    # Replay the complete original sampling stream without any training.
    torch.manual_seed(base['seed']);original_model=Siren(base);initial_rng=torch.get_rng_state().clone()
    matched_rng=raw_sampling_rng(wide);assert torch.equal(initial_rng,matched_rng)
    digests=[]
    for c,rng in [(base,initial_rng),(wide,matched_rng)]:
        torch.set_rng_state(rng);digest=hashlib.sha256()
        for step in range(1,10001):
            q=sample(c,2048,.5*step/10000,256,'cpu',focus=True);digest.update(q.numpy().tobytes())
        assert torch.equal(torch.get_rng_state(),parent['torch_rng'].cpu())
        digests.append(digest.hexdigest())
    assert digests[0]==digests[1]
    mechanics={};benchmarks={};counts={}
    for name,c in [('width64',base),('width96',wide)]:
        torch.manual_seed(c['seed']);model=Siren(c)
        counts[name]=sum(p.numel() for p in model.parameters())
        mechanics[name]=mechanical_checks(model,c)
        torch.manual_seed(991741);q=sample(c,2048,.5,256,'cpu')
        durations=[]
        for j in range(8):
            clock=time.perf_counter();r,_,_=residual(model,q,c,True)
            gradients=torch.autograd.grad(r.abs().mean(),tuple(model.parameters()))
            assert all(torch.isfinite(g).all() for g in gradients)
            if j>=3:durations.append(time.perf_counter()-clock)
        benchmarks[name]=dict(median_gradient_batch_seconds=float(np.median(durations)),parameter_updates=0)
    # Meaningful native-trainer check: snapshots and split resume must not
    # alter the parameter/optimizer sampling trajectory. Disposable tiny runs.
    fixture=Path(tempfile.mkdtemp(prefix='capacity_snapshot_',dir=str(ROOT.parent.parent/'work')))
    tiny=dict(base,width=8,samples=64,terminal_samples=8,curriculum_steps=4,log_every=4,save_every=4)
    train(tiny,fixture/'continuous',snapshot_steps=[2,4])
    train(tiny,fixture/'split',stop_after=2,snapshot_steps=[2,4])
    train(tiny,fixture/'split',resume=fixture/'split/checkpoint.pt',snapshot_steps=[2,4])
    train(tiny,fixture/'no_snapshots')
    loaded=[load_checkpoint(fixture/n/'checkpoint.pt')[1] for n in ['continuous','split','no_snapshots']]
    for ck in loaded[1:]:
        assert all(torch.equal(v,ck['model'][k]) for k,v in loaded[0]['model'].items())
        assert torch.equal(loaded[0]['torch_rng'],ck['torch_rng'])
        for pid,state in loaded[0]['optimizer']['state'].items():
            assert all(torch.equal(v,ck['optimizer']['state'][pid][k]) for k,v in state.items())
    assert (fixture/'continuous/checkpoint_2.pt').exists() and (fixture/'continuous/checkpoint_4.pt').exists()
    assert sha(PARENT)==PARENT_SHA
    dump(FOLDER/'preflight.json',dict(status='passed',hardware=hw,parameter_counts=counts,
        full_10000_batch_sampling_hash=digests[0],both_sampling_streams_match=True,parent_final_sampling_rng_matches=True,
        mechanical_checks=mechanics,gradient_benchmarks=benchmarks,snapshot_and_resume_trajectory_check=True,
        checks_use_disposable_four_step_optimizer_fixtures=True,fixture_directory=str(fixture),
        sources={n:sha(ROOT/n) for n in ['capacity_budget.py','deepreach.py']},protocol_sha256=sha(FOLDER/'protocol.json')))
    print(json.dumps(dict(hardware=hw,counts=counts,gradient_benchmarks=benchmarks,status='preflight passed'),indent=2),flush=True)


def run(resume=False,execution='managed process'):
    check=json.loads((FOLDER/'preflight.json').read_text());assert check['status']=='passed'
    assert check['sources']=={n:sha(ROOT/n) for n in ['capacity_budget.py','deepreach.py']}
    assert check['protocol_sha256']==sha(FOLDER/'protocol.json') and sha(PARENT)==PARENT_SHA
    if (FOLDER/'training_manifest.json').exists():raise FileExistsError('Completed experiment cannot be overwritten')
    for n in ['capacity_budget.py','deepreach.py']:
        (FOLDER/'sources').mkdir(exist_ok=True);shutil.copy2(ROOT/n,FOLDER/'sources'/n)
    protected={str(p.relative_to(ROOT)):sha(p) for p in list((ROOT/'runs').glob('*/checkpoint.pt'))+
        [ROOT/'experiments/experiment_3_d_refinement/adam/checkpoint_200.pt',ROOT/'experiments/experiment_3_d_refinement/adam/checkpoint_800.pt',
         ROOT/'lookahead_21points_20261027/heldout_values.npz',ROOT/'evaluation/reserved_final_states/states.npz']}
    if (FOLDER/'protected_inputs.json').exists():
        protected=json.loads((FOLDER/'protected_inputs.json').read_text())
        assert all(sha(ROOT/p)==h for p,h in protected.items())
    else:dump(FOLDER/'protected_inputs.json',protected)
    dump(FOLDER/'execution.json',dict(launch=execution,threads=2,device='cpu',training=True,resume=resume))
    endpoints=[];clock=time.perf_counter()
    for name,snapshots in [('long64',[10200,10800,12000,16000,22000]),('wide96',[10000])]:
        c=json.loads((FOLDER/f'config_{name}.json').read_text());run_dir=ROOT/f'runs/experiment_3_e_{name}'
        total=c['curriculum_steps']+c.get('full_horizon_steps',0)
        existing=run_dir/'checkpoint.pt'
        if existing.exists():
            _,saved=load_checkpoint(existing)
            if saved['config']!=c:raise ValueError('Saved run config differs')
            if saved['step']<total:
                if not resume:raise FileExistsError('Interrupted run exists; explicit --resume required')
                dump(FOLDER/'progress.json',dict(status='training',run=name,mode='resume'))
                train(c,run_dir,resume=existing,snapshot_steps=snapshots)
        else:
            dump(FOLDER/'progress.json',dict(status='training',run=name,mode='new'))
            train(c,run_dir,extend_from=PARENT if name=='long64' else None,snapshot_steps=snapshots)
        for step in snapshots:
            p=run_dir/f'checkpoint_{step}.pt';_,ck=load_checkpoint(p);assert ck['step']==step
            endpoints.append(dict(run=name,step=step,checkpoint=str(p.relative_to(ROOT)),sha256=sha(p),
                elapsed_seconds=ck['elapsed_seconds'],additional_training_seconds=ck['additional_training_seconds'],
                width=c['width'],samples=c['samples']*step,linear_mac_proxy=c['samples']*step*linear_macs(c['width'])))
        dump(FOLDER/'progress.json',dict(status='run_completed',run=name,endpoints=endpoints))
    # Independently verify continuation matches the earlier 200/800-step Adam
    # trial, which used the same parent and sampler.
    replay={}
    for step in [10200,10800]:
        _,a=load_checkpoint(ROOT/f'runs/experiment_3_e_long64/checkpoint_{step}.pt')
        _,b=load_checkpoint(ROOT/f'experiments/experiment_3_d_refinement/adam/checkpoint_{step-10000}.pt')
        max_diff=max(float((a['model'][k]-b['model'][k]).abs().max()) for k in a['model'])
        assert max_diff==0 and torch.equal(a['torch_rng'],b['torch_rng'])
        replay[str(step)]=dict(model_max_abs_difference=max_diff,sampling_rng_matches=True)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    dump(FOLDER/'training_manifest.json',dict(status='completed',endpoints=endpoints,protected_inputs=protected,
        short_refinement_replay=replay,reference_labels_loaded=False,reserved_final_states_used=False,
        protocol_sha256=sha(FOLDER/'protocol.json'),sources=check['sources'],
        orchestration_elapsed_seconds=time.perf_counter()-clock))
    dump(FOLDER/'progress.json',dict(status='training_completed',evaluation='pending'))
    print('Experiment 3E training completed. Reference evaluation remains separate.',flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');ap.add_argument('--train',action='store_true')
    ap.add_argument('--resume',action='store_true');ap.add_argument('--execution',default='managed process')
    args=ap.parse_args()
    if args.check:preflight()
    elif args.train:run(args.resume,args.execution)
    else:ap.error('Choose --check or explicit --train; training is not implicit.')

"""Denser within-horizon Air3D validation. No training or optimizer updates."""
import argparse
import json
import time
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from deepreach import load_checkpoint
from diagnostics import RUNS, ROOT, dump, sha, relative_l2, write_csv
from reference import solve, interpolate
from validate import comparison_region, predict, error, classification


def run(folder, points):
    if points < 3 or points % 4 != 1:
        raise ValueError('Use 4k+1 points so 0, .25 and .5 remain in the sweep')
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    original_cache = ROOT / 'runs/air3d_cpu_20261022/validation/reference_fine.npz'
    protected = [original_cache] + [ROOT / 'runs' / d / 'checkpoint.pt' for _, _, d in RUNS]
    before = {str(p.relative_to(ROOT)): sha(p) for p in protected}
    models = {}
    for label, slug, directory in RUNS:
        model, checkpoint = load_checkpoint(ROOT / 'runs' / directory / 'checkpoint.pt')
        model.eval()
        models[slug] = model
        config = checkpoint['config']
        if slug == 'baseline':
            c = config
        for key in ['radius', 'speed', 'turn', 'domain', 'horizon', 'comparison_half_width']:
            if config[key] != c[key]:
                raise ValueError('Inconsistent physical configurations: ' + key)
    times = np.linspace(0, c['horizon'], points)
    dump(folder / 'status.json', dict(status='computing reference snapshots', training=False))
    print(f'Solving 129x129x96 reference at {points} times; no training', flush=True)
    started = time.perf_counter()
    ref = solve(c, 129, 96, times)
    seconds = time.perf_counter() - started
    # Additional output times shorten some Euler steps. Quantify the small change
    # instead of assuming the shared snapshots are numerically identical.
    shared = []
    with np.load(original_cache) as old:
        np.testing.assert_array_equal(ref['x'], old['x'])
        np.testing.assert_array_equal(ref['theta'], old['theta'])
        for tau, previous in zip(old['times'], old['values']):
            current = ref['values'][float(tau)]
            shared.append(dict(tau=float(tau), max_abs=float(np.max(np.abs(current-previous))),
                               rmse=float(np.sqrt(np.mean((current-previous)**2)))))
    # Guard against accidentally changing the solver, game or resolution.
    if max(row['max_abs'] for row in shared) > .001:
        raise ValueError('Shared reference snapshots differ by more than 1 mm; investigate')
    interior, _ = comparison_region(c)
    rng = np.random.default_rng(20261019)
    states = rng.uniform([-interior, -interior, -np.pi], [interior, interior, np.pi], (24000, 3))
    reference_values = np.stack([interpolate(ref, float(t), states) for t in times])
    # Only the queried reference values are required for reproducing the metrics.
    # Full grid snapshots can be reconstructed by the deterministic solver.
    del ref
    arrays = dict(times=times, states=states, reference=reference_values)
    rows = []
    for label, slug, _ in RUNS:
        print('Evaluating ' + label, flush=True)
        predictions = np.stack([predict(models[slug], np.column_stack([np.full(len(states), t), states])) for t in times])
        arrays[slug] = predictions
        for i, tau in enumerate(times):
            a, b = predictions[i], reference_values[i]
            rows.append(dict(model=label, slug=slug, tau=float(tau), relative_l2=relative_l2(a,b),
                             **error(a,b), **classification(a,b)))
    np.savez_compressed(folder / 'heldout_values.npz', **arrays)
    write_csv(folder / 'metrics.csv', rows)
    dump(folder / 'metrics.json', rows)
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6), layout='constrained')
    for label, slug, _ in RUNS:
        selected = [r for r in rows if r['slug'] == slug]
        for ax, key, scale in zip(axes, ['relative_l2', 'mae', 'false_safe_fraction_of_reference_unsafe'], [100,1,100]):
            ax.plot(times, [scale*r[key] for r in selected], 'o-', markersize=3, label=label)
    for ax, title in zip(axes, ['Relative L2 error [%]', 'Value MAE [m]', 'False-safe / reference-unsafe [%]']):
        ax.set_xlabel('Evaluation look-ahead τ [s]')
        ax.set_ylabel(title)
        ax.grid(alpha=.25)
    axes[0].legend(fontsize=8)
    fig.suptitle(f'{points} evaluation times; fixed trained horizon T = 0.5 s; unchanged checkpoints')
    fig.savefig(folder / 'error_vs_lookahead.png', dpi=170)
    plt.close(fig)
    # Independent check that exported values reproduce every reported L2 metric.
    for row in rows:
        i = int(np.argmin(np.abs(times-row['tau'])))
        np.testing.assert_allclose(row['relative_l2'], np.linalg.norm(arrays[row['slug']][i]-reference_values[i]) / np.linalg.norm(reference_values[i]), rtol=1e-12)
    after = {str(p.relative_to(ROOT)): sha(p) for p in protected}
    if before != after:
        raise ValueError('Protected checkpoint/reference changed')
    dump(folder / 'reference_check.json', dict(grid=[129,129,96], times=times.tolist(),
         build_seconds=seconds, shared_snapshot_comparison=shared, shared_snapshot_tolerance_m=.001,
         note='Extra requested output times shorten Euler steps; no temporal interpolation.'))
    dump(folder / 'manifest.json', dict(training=False, protected_inputs=after,
         source_sha256={n:sha(ROOT/n) for n in ['lookahead_sweep.py','diagnostics.py','reference.py','deepreach.py','validate.py']},
         evaluation_states=24000, evaluation_seed=20261019, times=times.tolist(),
         threads=2, torch_version=torch.__version__, device='cpu'))
    dump(folder / 'checks.json', dict(checkpoints_and_reference_unchanged=True,
         shared_reference_within_1mm=True, all_exported_relative_l2_recomputed=True,
         comparisons=len(rows), no_training=True))
    lines = ['# Denser look-ahead diagnostic', '',
         f'{points} points from 0 to .5 seconds, spacing {times[1]-times[0]:g} s, '
         'using the four unchanged Experiment 1/2 checkpoints and the same 24,000 validation states. No training.', '',
         '![Error versus look-ahead](error_vs_lookahead.png)', '',
         'The independent 129×129×96 grid solver computed each requested snapshot directly. '
         'No reference values were interpolated in time. Additional output times shorten some Euler steps, '
         'so this reference can differ slightly from the original three-snapshot solve. '
         f'Maximum shared-snapshot difference: {max(r["max_abs"] for r in shared):.8f} m; '
         f'reference construction: {seconds:.2f} s. See reference_check.json.', '',
         'This varies evaluation look-ahead inside a fixed trained horizon. It is not a sweep of independently '
         'trained horizons, an untouched final test, a new training experiment, or a safety guarantee. '
         'The original three-point report, spectra and timing measurements are preserved.', '',
         '| Model | Relative L2 at .5 s | MAE at .5 s [m] | False-safe / reference-unsafe at .5 s |',
         '|---|---|---|---|']
    for row in rows:
        if row['tau'] == times[-1]:
            lines.append(f'| {row["model"]} | {100*row["relative_l2"]:.2f}% | {row["mae"]:.5f} | {100*row["false_safe_fraction_of_reference_unsafe"]:.2f}% |')
    lines += ['', 'Files: metrics.csv/json contain all model/time comparisons; heldout_values.npz retains '
              'the exact query states, reference values and predictions; manifest.json records source/input hashes; '
              'checks.json records verification. Full grid snapshots are not duplicated; rerunning the solver reconstructs them.', '',
              'Reproduce from the project root:', '', '```powershell',
              f'python outputs/deepreach/lookahead_sweep.py --points {points} --out outputs/deepreach/{folder.name}',
              '```', '', '[Original diagnostics](../diagnostics_20261027/README.md)', '']
    (folder/'README.md').write_text('\n'.join(lines), encoding='utf-8')
    dump(folder/'status.json', dict(status='completed', training=False))
    print('Completed: ' + str(folder/'README.md'), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--points', type=int, default=21)
    parser.add_argument('--out', default=str(ROOT/'lookahead_21points_20261027'))
    args = parser.parse_args()
    run(args.out, args.points)

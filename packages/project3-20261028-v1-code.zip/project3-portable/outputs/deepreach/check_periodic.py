"""Periodic-candidate derivatives, invariance and sampler replay; no optimizer."""
import argparse
import importlib.util
import json
from pathlib import Path
import numpy as np
import torch
from deepreach import Siren, load_checkpoint, raw_sampling_rng, sample, target, value_grad, residual
from diagnostics import ROOT, dump, sha, RUNS
from validate import mechanical_checks


def check(out):
    c=json.loads((ROOT/'configs/experiment3b_periodic.json').read_text())
    torch.set_num_threads(2);torch.manual_seed(c['seed']);model=Siren(c).eval()
    before={k:v.clone() for k,v in model.state_dict().items()}
    gen=np.random.default_rng(20261030)
    q=torch.tensor(gen.uniform([0,-.6,-.6,-np.pi],[.5,.6,.6,np.pi],(1024,4)),dtype=torch.float64)
    md=model.double()
    v,dv=value_grad(md,q)
    shifted=q.clone();shifted[:,3]+=2*np.pi
    v2,dv2=value_grad(md,shifted)
    gap=float((v-v2).detach().abs().max()); grad_gap=float((dv-dv2).detach().abs().max())
    assert gap<1e-12 and grad_gap<1e-10
    # Independent feature-level chain rule for physical heading.
    z=q/md.scales;psi=q[:,3]
    features=torch.cat((z[:,:3],psi.sin()[:,None],psi.cos()[:,None]),dim=1).detach().requires_grad_(True)
    g=features
    for layer in md.layers[:-1]:g=torch.sin(30*layer(g))
    g=md.layers[-1](g).squeeze(-1)
    df=torch.autograd.grad(g.sum(),features)[0]
    dg=torch.cat((df[:,:3]/md.scales[:3],(df[:,3]*psi.cos()-df[:,4]*psi.sin())[:,None]),dim=1)
    chain=-2*c['constraint_scale']*(q[:,0]/c['horizon'])[:,None]*g[:,None]*dg
    chain[:,0]-=c['constraint_scale']*g.square()/c['horizon']
    chain[:,1:3]+=q[:,1:3]/torch.linalg.vector_norm(q[:,1:3],dim=1,keepdim=True)
    chain_error=float((chain-dv).detach().abs().max()); assert chain_error<1e-10
    mech=mechanical_checks(md,c)
    assert torch.all(md(q)<=target(q[:,1:],c))
    zero=q.clone();zero[:,0]=0
    assert torch.equal(md(zero),target(zero[:,1:],c))
    r,_,_=residual(md,q[:256],c,True)
    grads=torch.autograd.grad(r.abs().mean(),tuple(md.parameters()))
    assert all(torch.isfinite(g).all() and g.norm()>0 for g in grads)
    # Old model predictions must be bitwise identical to their own archived source.
    legacy={}; protected={}
    runs=[(slug,d) for _,slug,d in RUNS]+[('3a','experiment_3_a_constraints')]
    for slug,d in runs:
        path=ROOT/'runs'/d/'checkpoint.pt'; protected[str(path.relative_to(ROOT))]=sha(path)
        current,ck=load_checkpoint(path)
        archive=ROOT/'runs'/('experiment_3_a_constraints' if slug=='3a' else 'air3d_cpu_20261022')/'source/deepreach.py'
        spec=importlib.util.spec_from_file_location('old_'+slug,archive)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        old=module.Siren(ck['config']);old.load_state_dict(ck['model'])
        probe=q[:128].float()
        with torch.no_grad():assert torch.equal(current(probe),old(probe))
        legacy[slug]=True
    # Replay 3A's 10,000 stochastic batches (sampling only, not training).
    _,base=load_checkpoint(ROOT/'runs/experiment_3_a_constraints/checkpoint.pt')
    torch.set_rng_state(raw_sampling_rng(c))
    for step in range(c['curriculum_steps']):
        sample(c,c['samples'],c['horizon']*(step+1)/c['curriculum_steps'],c['terminal_samples'],'cpu')
    assert torch.equal(torch.get_rng_state(),base['torch_rng'].cpu())
    assert all(torch.equal(v.double(),md.state_dict()[k]) for k,v in before.items())
    for rel,expected in protected.items():assert sha(ROOT/rel)==expected
    result=dict(status='periodic implementation verified',optimizer_steps=0,
        value_periodicity_max=gap,derivative_periodicity_max=grad_gap,feature_chain_rule_max=chain_error,
        mechanical=mech,terminal_and_obstacle_verified=True,finite_nonzero_physics_gradients=True,
        raw_sampler_replay_matches_3a_final_rng=True,legacy_predictions_bitwise_identical=legacy,
        parameters=sum(p.numel() for p in md.parameters()),protected_inputs=protected,
        sources={n:sha(ROOT/n) for n in ['deepreach.py','validate.py','check_periodic.py']},
        config_sha256=sha(ROOT/'configs/experiment3b_periodic.json'),
        note='No optimizer created; replayed sampler only. Double-precision periodicity is numerical, not a formal floating-point proof.')
    Path(out).parent.mkdir(parents=True,exist_ok=True);dump(out,result);print(json.dumps(result,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',default=str(ROOT/'experiments/experiment_3_b/implementation_checks.json'))
    check(p.parse_args().out)

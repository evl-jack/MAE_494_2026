"""P3/P4/P5 diagnostics for existing Air3D checkpoints. Never trains.

Uses the three saved reference snapshots without temporal interpolation.
A timed fine-grid solve measures baseline construction cost, not training.
"""
import argparse
import csv
import hashlib
import json
import math
import platform
import time
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.interpolate import RegularGridInterpolator

from deepreach import load_checkpoint
from reference import interpolate, solve
from validate import classification, comparison_region, error, predict

ROOT = Path(__file__).resolve().parent
RUNS = [
    ('Experiment 1', 'baseline', 'air3d_cpu_20261022'),
    ('A: lower terminal weight', 'a', 'experiment_2_a_loss_20261022'),
    ('B: focused sampling', 'b', 'experiment_2_b_sampling_20261022'),
    ('C: full-horizon hold', 'c', 'experiment_2_c_hold_20261022'),
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def write_csv(path, rows):
    with open(path, 'w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def relative_l2(a, b):
    denominator = float(np.linalg.norm(b))
    if denominator <= np.finfo(float).eps:
        raise ValueError('Relative L2 undefined for a zero reference norm')
    return float(np.linalg.norm(a - b) / denominator)


def spectra(field, dx):
    """field[x,y,heading]; Parseval-normalized power, no spatial periodicity assumed."""
    nx, ny, nh = field.shape
    window = np.hanning(nx)[:, None] * np.hanning(ny)[None, :]
    mean = np.sum(field * window[..., None], axis=(0, 1), keepdims=True) / window.sum()
    tapered = (field - mean) * window[..., None] / np.sqrt(np.mean(window ** 2))
    transform = np.fft.fft2(tapered, axes=(0, 1), norm='forward')
    power = np.mean(np.abs(transform) ** 2, axis=2)
    fx, fy = np.meshgrid(np.fft.fftfreq(nx, dx), np.fft.fftfreq(ny, dx), indexing='ij')
    radial = np.hypot(fx, fy)
    step = min(1 / (nx * dx), 1 / (ny * dx))
    edges = np.arange(0, math.ceil(radial.max() / step) + 2) * step
    spatial = np.histogram(radial.ravel(), bins=edges, weights=power.ravel())[0]
    spatial_f = (edges[:-1] + edges[1:]) / 2
    spatial_energy = float(np.mean(tapered ** 2))
    np.testing.assert_allclose(spatial.sum(), spatial_energy, rtol=1e-11, atol=1e-20)

    centered = field - field.mean(axis=2, keepdims=True)
    angular = np.fft.rfft(centered, axis=2, norm='forward')
    heading = np.mean(np.abs(angular) ** 2, axis=(0, 1))
    heading[1:-1 if nh % 2 == 0 else None] *= 2
    heading_energy = float(np.mean(centered ** 2))
    np.testing.assert_allclose(heading.sum(), heading_energy, rtol=1e-11, atol=1e-20)
    return dict(spatial_frequency=spatial_f, spatial_power=spatial,
                heading_harmonic=np.arange(len(heading)), heading_power=heading,
                spatial_energy=spatial_energy, heading_energy=heading_energy)


def mathematical_checks():
    truth = np.array([1., 2., -3.])
    assert abs(relative_l2(1.1 * truth, truth) - .1) < 1e-14
    n, nh = 17, 96
    angle = 2 * np.pi * np.arange(nh) / nh
    field = np.broadcast_to(np.sin(3 * angle), (n, n, nh)).copy()
    result = spectra(field, .1)
    assert np.argmax(result['heading_power']) == 3
    np.testing.assert_allclose(result['heading_energy'], .5, atol=1e-14)
    assert spectra(np.ones((n, n, nh)), .1)['spatial_energy'] < 1e-25
    return dict(relative_l2_known_error=True, angular_harmonic_recovered=3,
                spatial_and_heading_parseval=True, constant_field_removed=True)


def benchmark(function, repeats, calls, warmups):
    for _ in range(warmups):
        function()
    samples = []
    for _ in range(repeats):
        started = time.perf_counter()
        for _ in range(calls):
            function()
        samples.append((time.perf_counter() - started) / calls)
    return dict(median_seconds=float(np.median(samples)),
                min_seconds=float(np.min(samples)), max_seconds=float(np.max(samples)),
                block_seconds=samples, repeats=repeats, calls_per_block=calls, warmups=warmups)


def cost_comparison(train, build, neural_query, grid_query):
    """Both methods build once, then reuse. Solve Tnn + N*qnn < Tgrid + N*qgrid."""
    difference = train - build
    saving = grid_query - neural_query
    if saving > 0:
        threshold = max(0, difference / saving)
        return dict(pattern='PINN cheaper above crossover', crossover_state_queries=float(threshold),
                    first_integer_query=max(0, math.floor(threshold) + 1))
    if saving < 0:
        if difference >= 0:
            return dict(pattern='No PINN cost break-even: grid build and queries both cheaper',
                        crossover_state_queries=None)
        return dict(pattern='PINN cheaper initially; grid cheaper beyond crossover',
                    crossover_state_queries=float(difference / saving))
    return dict(pattern='Equal query cost; lower build cost determines total',
                crossover_state_queries=None)


def cost_checks():
    assert cost_comparison(10, 2, 1, 2)['crossover_state_queries'] == 8
    assert cost_comparison(10, 2, 2, 1)['crossover_state_queries'] is None
    assert cost_comparison(2, 10, 2, 1)['crossover_state_queries'] == 8
    return True


def plots(folder, times, rows, all_spectra, lattice, fields, labels, timing):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout='constrained')
    for label, slug in labels:
        selected = [r for r in rows if r['slug'] == slug]
        axes[0].plot(times, [100 * r['relative_l2'] for r in selected], 'o-', label=label)
        axes[1].plot(times, [100 * r['false_safe_fraction_of_reference_unsafe'] for r in selected], 'o-')
    for ax in axes:
        ax.set_xlabel('Evaluation look-ahead τ [s]'); ax.set_xticks(times); ax.grid(alpha=.25)
    axes[0].set_ylabel('Relative L2 value error [%]'); axes[0].legend(fontsize=8)
    axes[1].set_ylabel('False-safe / reference-unsafe [%]')
    fig.suptitle('Difficulty knob: evaluation look-ahead, fixed trained horizon T = 0.5 s')
    fig.savefig(folder / 'error_vs_lookahead.png', dpi=170); plt.close(fig)

    fig, axes = plt.subplots(2, len(times), figsize=(13, 7), layout='constrained')
    for k, tau in enumerate(times):
        for label, slug in [('Reference signal', 'reference')] + labels:
            spec = all_spectra[slug][k]
            for row, xkey, ykey in [(0, 'spatial_frequency', 'spatial_power'),
                                    (1, 'heading_harmonic', 'heading_power')]:
                x, power = spec[xkey], spec[ykey]
                mask = x > 0
                axes[row, k].semilogy(x[mask], np.maximum(power[mask], 1e-16),
                                     '--' if slug == 'reference' else '-',
                                     color='gray' if slug == 'reference' else None, label=label)
        axes[0, k].set_title(f'τ = {tau:g} s')
        axes[0, k].set_xlabel('Radial spatial frequency [cycles/m]')
        axes[1, k].set_xlabel('Heading harmonic [cycles / full turn]')
        for row in [0, 1]:
            axes[row, k].set_ylabel('Band mean-square power [m²]'); axes[row, k].grid(alpha=.25)
    axes[0, 0].legend(fontsize=7)
    fig.suptitle('Error spectra: native spatial grid, Hann taper; periodic heading transform')
    fig.savefig(folder / 'error_spectra.png', dpi=170); plt.close(fig)

    headings = [0., np.pi / 2, -np.pi]
    iy = int(np.argmin(np.abs(lattice['x'])))
    vlim = max(float(np.max(np.abs(v[:, :, iy, :]))) for v in fields.values())
    fig, axes = plt.subplots(len(labels), 3, figsize=(12, 10), layout='constrained')
    for i, (label, slug) in enumerate(labels):
        for j, heading in enumerate(headings):
            ih = int(np.argmin(np.abs(lattice['theta'] - heading)))
            image = axes[i, j].pcolormesh(lattice['x'], times, fields[slug][:, :, iy, ih],
                                          shading='nearest', cmap='coolwarm', vmin=-vlim, vmax=vlim)
            axes[i, j].set_ylim(times[0], times[-1]); axes[i, j].set_yticks(times)
            axes[i, j].set_xlabel('Relative x [m]'); axes[i, j].set_ylabel('Look-ahead τ [s]')
            axes[i, j].set_title(f'{label}\nψ = {heading / np.pi:g}π, y = 0')
    fig.colorbar(image, ax=axes.ravel().tolist(), label='PINN − grid value [m]', shrink=.7)
    fig.suptitle('Space–time error slices: only the three saved time planes; no temporal interpolation')
    fig.savefig(folder / 'space_time_error.png', dpi=160); plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4), layout='constrained')
    names = [name for name, _ in labels] + ['Cached grid']
    for j, batch in enumerate([1, 1024]):
        keys = [slug for _, slug in labels] + ['grid']
        vals = [1e6 * timing[key][str(batch)]['median_seconds'] / batch for key in keys]
        axes[j].barh(names, vals); axes[j].invert_yaxis()
        axes[j].set_xlabel('Median value-only time per state [µs]'); axes[j].set_title(f'Batch size {batch}')
        axes[j].grid(axis='x', alpha=.25)
    fig.suptitle('Warm CPU inference: prepared inputs, two PyTorch threads, no loading or control derivatives')
    fig.savefig(folder / 'inference_cost.png', dpi=170); plt.close(fig)


def report(folder, rows, timing, build, metrics, spectral_summary, status):
    lines = [
        '# Air3D — Missing diagnostic measurements', '',
        'Evaluation date: 27 October 2026. No training or optimizer updates were performed. '
        'The existing Experiment 1 and Experiment 2 A/B/C checkpoints are unchanged.', '',
        '## Scope and difficulty knob', '',
        'The knob is evaluation look-ahead τ at 0, .25 and .5 s. Every network was already trained '
        'through T=.5 s. This tests error growth within the learned time interval; it is not a sweep '
        'of independently trained maximum horizons, and three planes do not locate a precise collapse threshold. '
        'The same 24,000 interior states (x,y in [−.6,.6] m, heading in [−π,π), seed 20261019) '
        'and saved approximate reference are reused. These comparisons are validation diagnostics; '
        'they are not an untouched final test set.', '',
        'Relative L2 is sqrt(sum((PINN−reference)^2) / sum(reference^2)), using the same states at each time. '
        'MAE/RMSE and classification values were checked against the previously saved metrics.', '',
        '## P3 — Error versus look-ahead', '',
        '| Model | τ [s] | Relative L2 | Value MAE [m] | False-safe / reference-unsafe |',
        '|---|---|---|---|---|',
    ]
    for row in rows:
        lines.append(f"| {row['model']} | {row['tau']:g} | {100 * row['relative_l2']:.2f}% | "
                     f"{row['mae']:.5f} | {100 * row['false_safe_fraction_of_reference_unsafe']:.2f}% |")
    lines += ['', '![Error versus look-ahead](error_vs_lookahead.png)', '',
              '## P4 — Error fields and spectra', '',
              'Fields use the finest reference’s native spatial nodes inside the comparison square '
              '(39×39, spacing .03125 m), all 96 periodic heading nodes, and all three saved times. '
              'The plotted space–time slices have y=0 and headings 0, π/2 and −π. No intermediate-time '
              'values are invented. Original x–y error figures remain in each run’s validation folder.', '',
              'Spatial spectra subtract each heading plane’s Hann-weighted mean, apply a 2D Hann window '
              'normalized by its RMS, and sum FFT power into radial frequency bands; powers are averaged '
              'over heading. This reduces edge leakage from the nonperiodic spatial crop. Heading spectra '
              'subtract the mean over heading and use a one-sided periodic transform, averaged over x/y. '
              'Nonzero harmonic power can include the PINN’s heading seam mismatch. Spectra omit DC '
              '(mean error), so the field and value metrics must be considered alongside them. '
              'Parseval energy identities and a known third-harmonic field were checked.', '',
              'The dashed reference-signal spectrum provides context; it is not a reference-error bound. '
              'A high-frequency tail alone does not prove spectral bias: solution nonsmoothness, numerical '
              'diffusion, seams and sampling can also affect it. Frequency units differ between the two rows.', '',
              '![Space–time error](space_time_error.png)', '', '![Error spectra](error_spectra.png)', '',
              '| Model at .5 s | Spatial centered/tapered RMS [m] | Heading-centered RMS [m] |',
              '|---|---|---|']
    for item in spectral_summary:
        if item['tau'] == .5 and item['slug'] != 'reference':
            lines.append(f"| {item['model']} | {math.sqrt(item['spatial_energy']):.5f} | "
                         f"{math.sqrt(item['heading_energy']):.5f} |")
    lines += ['', 'These RMS values describe different centered/windowed fields; neither is the held-out value RMSE.', '',
              '## P1/P5 — Construction cost and inference', '',
              f"The finest grid (129×129×96) was solved once through .5 s for timing: **{build['seconds']:.2f} s**. "
              f"Maximum difference from the saved grid was **{build['max_abs_vs_cache']:.3g} m**. "
              'This is the standalone fine-grid construction time. Experiment 1’s previously recorded '
              '696.7 s was a multi-solve verification suite, not this single solve. Original reference '
              'refinement, boundary and analytic checks remain in the Experiment 1 report.', '',
              f"Hardware: {status['cpu']}; {status['logical_processors']} logical processors; "
              f"PyTorch {torch.__version__}, CPU, two PyTorch threads. "
              'Timings are current-machine measurements and may vary with workload.', '',
              'Inference benchmarks use warm calls with prepared inputs at τ=.5 s; seven timed blocks '
              'follow warmup. Batch 1 uses 100 calls/block; batch 1024 uses 10 calls/block. Network loading, '
              'input conversion, UI rendering, gradients and control calculations are excluded. The grid '
              'interpolator is constructed once and reused, with heading periodicity. All per-block timings '
              'and setup costs are retained in timing.json.', '',
              '| Model | Historical training [s] | Batch-1 value query [µs] | Batch-1024 per state [µs] |',
              '|---|---|---|---|']
    for label, slug, _ in RUNS:
        lines.append(f"| {label} | {metrics[slug]['training_seconds']:.2f} | "
                     f"{timing[slug]['1']['median_seconds'] * 1e6:.2f} | "
                     f"{timing[slug]['1024']['median_seconds'] * 1e6 / 1024:.2f} |")
    lines.append(f"| Cached grid | Build: {build['seconds']:.2f} | "
                 f"{timing['grid']['1']['median_seconds'] * 1e6:.2f} | "
                 f"{timing['grid']['1024']['median_seconds'] * 1e6 / 1024:.2f} |")
    lines += ['', '![Inference timing](inference_cost.png)', '',
              '### Repeated-query break-even', '',
              'Both the PINN and the numerical grid can be built once and queried repeatedly for this '
              'fixed game. We compare T_train + N·t_PINN with T_grid-build + N·t_grid-interpolation. '
              'Charging a new full PDE solve for every state query would unfairly favor the PINN. '
              'The historical training runs used different machine conditions and debugger settings; '
              'these are illustrative measured-cost comparisons, not controlled speedup claims. '
              'No accuracy-matched performance claim is made: the grid is substantially more accurate '
              'than these networks in our reference checks.', '']
    for label, slug, _ in RUNS:
        comparison = timing[slug]['cached_grid_break_even_batch1']
        value = comparison['crossover_state_queries']
        tail = '' if value is None else f"; crossover ≈ {value:,.0f} state queries"
        lines.append(f"- {label}: {comparison['pattern']}{tail}.")
    lines += ['', 'Batch-1024 crossover calculations are also saved. These apply to repeated states for '
              'one fixed model, not new PDE instances or a neural operator trained over a parameter family.', '',
              '## Interpretation and limits', '',
              'The new diagnostics supplement, rather than replace, the controlled Experiment 2 comparisons. '
              'A lower loss weight helped this seed; the spectra are descriptive evidence and do not '
              'by themselves isolate a unique cause. No new activation, optimizer, periodic encoding, '
              'hybrid trainer, gradient-accuracy study or closed-loop controller experiment was run.', '',
              'A formal sweep beyond .5 s or of independently trained maximum horizons would require '
              'new reference snapshots and possibly new training. A time Fourier spectrum cannot be '
              'reliably inferred from only three snapshots; the supplied spectra are spatial and heading spectra.', '',
              '## Reproduce and inspect', '',
              'From the project root, with the existing environment/dependencies:', '',
              '```powershell',
              'python outputs/deepreach/diagnostics.py --out outputs/deepreach/diagnostics_20261027',
              '```', '',
              'No --train flag exists. The timed reference-build record is reused on reruns only when '
              'its source/cache/config hashes match. Use --retime-reference to measure it again. '
              'Fresh inference timings are collected on each run.', '',
              '- metrics.csv / metrics.json: complete look-ahead comparisons.',
              '- spectra.csv / spectral_summary.json: all spectral bands and energy checks.',
              '- heldout_values.npz / error_fields.npz: evaluation inputs, predictions and reference values.',
              '- timing.json / reference_build.json: repeat timings and construction cost.',
              '- checks.json / integrity.json / manifest.json: mathematical checks, provenance and unchanged-file checks.',
              '- Existing reference accuracy checks: ../experiments/experiment_1/README.md.',
              '- Existing controlled comparison: ../experiments/experiment_2/README.md.',
              '- Run inputs remain original validation data; an untouched final test remains future work.', '']
    (folder / 'README.md').write_text('\n'.join(lines), encoding='utf-8')


def run(folder, retime=False):
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    checks = mathematical_checks(); checks['cached_grid_cost_cases'] = cost_checks()
    dump(folder / 'checks.json', checks)
    cache = ROOT / 'runs/air3d_cpu_20261022/validation/reference_fine.npz'
    protected = [cache] + [ROOT / 'runs' / directory / 'checkpoint.pt' for _, _, directory in RUNS]
    original_hashes = {str(p.relative_to(ROOT)): sha(p) for p in protected}
    with np.load(cache) as data:
        times = data['times'].copy(); x = data['x'].copy(); theta = data['theta'].copy()
        reference_values = data['values'].copy()
    ref = dict(x=x, theta=theta, values={float(t):v for t, v in zip(times, reference_values)})
    models = {}; metrics = {}; labels = []; configs = {}
    for label, slug, directory in RUNS:
        model, ck = load_checkpoint(ROOT / 'runs' / directory / 'checkpoint.pt')
        model.eval(); models[slug] = model; configs[slug] = ck['config']; labels.append((label, slug))
        metrics[slug] = json.loads((ROOT / 'runs' / directory / 'validation/metrics.json').read_text())
        for key in ['radius', 'speed', 'turn', 'domain', 'horizon', 'comparison_half_width']:
            if ck['config'][key] != configs['baseline'][key]:
                raise ValueError(f'Physical configuration mismatch: {key}')
    c = configs['baseline']; interior, _ = comparison_region(c)
    if not np.array_equal(times, [0., .25, .5]):
        raise ValueError('This diagnostic expects the saved .5 s reference')
    dump(folder / 'status.json', dict(status='held-out value evaluation', training=False))
    rng = np.random.default_rng(20261019)
    states = rng.uniform([-interior, -interior, -np.pi], [interior, interior, np.pi], size=(24000, 3))
    references = np.stack([interpolate(ref, float(t), states) for t in times])
    rows = []; arrays = dict(states=states, times=times, reference=references)
    for label, slug in labels:
        print('Held-out values: ' + label, flush=True)
        predictions = np.stack([predict(models[slug], np.column_stack([np.full(len(states), t), states])) for t in times])
        arrays[slug] = predictions
        for k, tau in enumerate(times):
            a, b = predictions[k], references[k]
            recorded = metrics[slug]['comparisons'][str(float(tau))]
            measured = error(a, b)
            if abs(measured['mae'] - recorded['mae']) > 1e-7:
                raise ValueError('Existing value comparison not reproduced')
            rows.append(dict(model=label, slug=slug, tau=float(tau), relative_l2=relative_l2(a, b),
                             **measured, **classification(a, b)))
    np.savez_compressed(folder / 'heldout_values.npz', **arrays)
    write_csv(folder / 'metrics.csv', rows); dump(folder / 'metrics.json', rows)
    del arrays

    dump(folder / 'status.json', dict(status='error fields and Fourier spectra', training=False))
    ids = np.flatnonzero(np.abs(x) <= interior)
    xx, yy, th = np.meshgrid(x[ids], x[ids], theta, indexing='ij')
    native_states = np.column_stack([xx.ravel(), yy.ravel(), th.ravel()])
    reference_native = reference_values[:, ids][:, :, ids, :]
    fields = {}; all_spectra = {}; spectral_summary = []; spectral_rows = []
    native_predictions = {}
    for label, slug in [('Reference signal', 'reference')] + labels:
        print('Fields and spectra: ' + label, flush=True)
        if slug == 'reference':
            field = reference_native
        else:
            values = np.stack([predict(models[slug], np.column_stack([np.full(len(native_states), tau), native_states])).reshape(xx.shape) for tau in times])
            native_predictions[slug] = values
            field = values - reference_native; fields[slug] = field
        all_spectra[slug] = []
        for k, tau in enumerate(times):
            spec = spectra(field[k], float(x[1] - x[0])); all_spectra[slug].append(spec)
            spectral_summary.append(dict(model=label, slug=slug, tau=float(tau),
                                         spatial_energy=spec['spatial_energy'], heading_energy=spec['heading_energy']))
            for axis, xkey, ykey in [('spatial', 'spatial_frequency', 'spatial_power'),
                                     ('heading', 'heading_harmonic', 'heading_power')]:
                for frequency, power in zip(spec[xkey], spec[ykey]):
                    spectral_rows.append(dict(model=label, slug=slug, tau=float(tau), axis=axis,
                                              frequency=float(frequency), power=float(power)))
    np.savez_compressed(folder / 'error_fields.npz', x=x[ids], theta=theta, times=times,
                        reference=reference_native, **native_predictions)
    write_csv(folder / 'spectra.csv', spectral_rows); dump(folder / 'spectral_summary.json', spectral_summary)

    dump(folder / 'status.json', dict(status='warm inference timing', training=False))
    timing = {}; interpolator_started = time.perf_counter()
    interpolator = RegularGridInterpolator((x, x, np.r_[theta, np.pi]),
                       np.concatenate([ref['values'][.5], ref['values'][.5][:, :, :1]], axis=2), bounds_error=True)
    interpolation_setup = time.perf_counter() - interpolator_started
    for label, slug in labels + [('Cached grid', 'grid')]:
        print('Inference timing: ' + label, flush=True)
        timing[slug] = {}
        for batch in [1, 1024]:
            if slug == 'grid':
                query = states[:batch].copy()
                function = lambda query=query: interpolator(query)
            else:
                query = torch.tensor(np.column_stack([np.full(batch, .5), states[:batch]]), dtype=torch.float32)
                function = lambda query=query, model=models[slug]: model(query)
            with torch.inference_mode():
                timing[slug][str(batch)] = benchmark(function, repeats=7, calls=100 if batch == 1 else 10, warmups=30)
    timing['grid']['interpolator_setup_seconds'] = interpolation_setup

    dump(folder / 'status.json', dict(status='timed numerical reference build', training=False))
    build_path = folder / 'reference_build.json'
    signature = dict(reference_sha256=sha(cache), solver_sha256=sha(ROOT / 'reference.py'),
                     config={k:c[k] for k in ['radius', 'speed', 'turn', 'domain', 'horizon']})
    build = json.loads(build_path.read_text()) if build_path.exists() else None
    if retime or not build or build.get('signature') != signature:
        print('Timing one 129×129×96 reference solve; no neural training', flush=True)
        started = time.perf_counter(); timed_ref = solve(c, 129, 96, times)
        seconds = time.perf_counter() - started
        maximum = max(float(np.max(np.abs(timed_ref['values'][float(t)] - ref['values'][float(t)]))) for t in times)
        if maximum > 1e-12:
            raise ValueError('Timed solve differs from saved numerical reference')
        build = dict(seconds=seconds, max_abs_vs_cache=maximum, signature=signature,
                     grid=[129, 129, 96], times=times.tolist(), steps=timed_ref['steps'],
                     dtmax=timed_ref['dtmax'], reused_on_this_run=False)
        dump(build_path, build)
        del timed_ref
    else:
        build = dict(build, reused_on_this_run=True)
    for _, slug in labels:
        for batch in [1, 1024]:
            timing[slug][f'cached_grid_break_even_batch{batch}'] = cost_comparison(
                metrics[slug]['training_seconds'], build['seconds'] + interpolation_setup,
                timing[slug][str(batch)]['median_seconds'] / batch,
                timing['grid'][str(batch)]['median_seconds'] / batch)
    dump(folder / 'timing.json', dict(benchmarks=timing, reference_build=build,
                                    threads=2, value_only=True, prepared_inputs=True))
    print(f"Reference solve: {build['seconds']:.2f} s; max cache difference {build['max_abs_vs_cache']:.3g}", flush=True)

    plots(folder, times, rows, all_spectra, dict(x=x[ids], theta=theta), fields, labels, timing)
    hardware = dict(cpu=platform.processor() or 'Intel Core Ultra 7 165U (previous hardware check)',
                    logical_processors=__import__('os').cpu_count(), platform=platform.platform())
    report(folder, rows, timing, build, metrics, spectral_summary, hardware)
    final_hashes = {str(p.relative_to(ROOT)): sha(p) for p in protected}
    if final_hashes != original_hashes:
        raise ValueError('A checkpoint or reference array changed')
    dump(folder / 'integrity.json', dict(checkpoints_and_reference_unchanged=True, hashes=final_hashes,
                                       existing_metrics_reproduced=True, no_training=True))
    dump(folder / 'manifest.json', dict(date='2026-10-27', status='completed', training=False,
         source_sha256={name:sha(ROOT / name) for name in ['diagnostics.py', 'deepreach.py', 'validate.py', 'reference.py']},
         protected_inputs=final_hashes, evaluation_seed=20261019, evaluation_states=24000,
         evaluation_times=times.tolist(), spectral_grid=[len(ids), len(ids), len(theta)], hardware=hardware))
    dump(folder / 'status.json', dict(status='completed', training=False))
    print('Completed. Report: ' + str(folder / 'README.md'), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', default=str(ROOT / 'diagnostics_20261027'))
    parser.add_argument('--retime-reference', action='store_true')
    parser.add_argument('--self-check', action='store_true', help='Only mathematical utility checks, no inference or solve')
    args = parser.parse_args()
    if args.self_check:
        print(json.dumps(dict(**mathematical_checks(), cost_comparison_checks=cost_checks()), indent=2))
    else:
        run(args.out, args.retime_reference)

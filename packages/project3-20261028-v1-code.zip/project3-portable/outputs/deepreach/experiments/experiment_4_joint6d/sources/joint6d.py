"""Joint-coordinate two-vehicle Air3D mechanics. No network or trainer.

State order: pursuer x,y,heading; evader x,y,heading.
u maximizes avoidance value (evader); d minimizes it (pursuer).
"""
import torch


def relative_state(z,wrap=False):
    delta=z[...,0:2]-z[...,3:5];heading=z[...,5]
    co,si=heading.cos(),heading.sin()
    psi=z[...,2]-heading
    if wrap:psi=(psi+torch.pi)%(2*torch.pi)-torch.pi
    return torch.stack((co*delta[...,0]+si*delta[...,1],
        -si*delta[...,0]+co*delta[...,1],psi),dim=-1)


def lift_relative(r,midpoint,evader_heading):
    """Generate joint evaluation poses with the same relative configuration."""
    co,si=evader_heading.cos(),evader_heading.sin()
    delta=torch.stack((co*r[...,0]-si*r[...,1],si*r[...,0]+co*r[...,1]),dim=-1)
    p=midpoint+delta/2;e=midpoint-delta/2
    ph=(evader_heading+r[...,2]+torch.pi)%(2*torch.pi)-torch.pi
    return torch.stack((p[...,0],p[...,1],ph,e[...,0],e[...,1],evader_heading),dim=-1)


def dynamics(z,u,d,c):
    xp,yp,hp,xe,ye,he,u,d=torch.broadcast_tensors(*z.unbind(-1),u,d)
    return torch.stack((c['speed']*hp.cos(),c['speed']*hp.sin(),d,
        c['speed']*he.cos(),c['speed']*he.sin(),u),dim=-1)


def target(z,c):return torch.linalg.vector_norm(z[...,0:2]-z[...,3:5],dim=-1)-c['radius']


def hamiltonian(z,p,c):
    drift=c['speed']*(z[...,2].cos()*p[...,0]+z[...,2].sin()*p[...,1]+
        z[...,5].cos()*p[...,3]+z[...,5].sin()*p[...,4])
    return drift+c['turn']*p[...,5].abs()-c['turn']*p[...,2].abs()


def optimal_inputs(p,c):return c['turn']*p[...,5].sign(),-c['turn']*p[...,2].sign()


def lift_covector(z,g):
    """J_R(z)^T g: chain rule for an invariant value W(tau,z)=V(tau,R(z))."""
    r=relative_state(z);co,si=z[...,5].cos(),z[...,5].sin()
    px=co*g[...,0]-si*g[...,1];py=si*g[...,0]+co*g[...,1]
    he=r[...,1]*g[...,0]-r[...,0]*g[...,1]-g[...,2]
    return torch.stack((px,py,g[...,2],-px,-py,he),dim=-1)

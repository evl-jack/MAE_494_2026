"""Frozen physics-only geometry/horizon weighting probes. Never trains.

Reference values evaluate candidates only. Selection uses a fixed physics score
and global-loss guard, shared across all construction weights.
"""
import copy
import csv
import json
import time
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from deepreach import load_checkpoint, sample, residual
from diagnostics import ROOT, dump, sha, write_csv
from diagnose_learning_signals import flat, group_gradient, adam_direction
from probe_step_directions import physics, predict
from validate import classification


def focused(n,c):
    q=torch.rand(n,4)
    return (q*torch.tensor([.15,.6,1.2,2*c['angle_factor']*np.pi])+
            torch.tensor([.35,0.,-.6,-c['angle_factor']*np.pi])).numpy()


def choose_physics_candidate(eligible,baseline):
    return min(eligible,key=lambda r:r['selection_score']) if eligible else dict(baseline,trial='baseline')


def run():
    start=time.perf_counter();torch.set_num_threads(2)
    out=ROOT/'experiments/experiment_3_d_refinement/geometry_horizon_probe';out.mkdir(parents=True,exist_ok=True)
    paths={'3A':ROOT/'runs/experiment_3_a_constraints/checkpoint.pt',
        'Adam200':ROOT/'experiments/experiment_3_d_refinement/adam/checkpoint_200.pt'}
    old=json.loads((ROOT/'experiments/experiment_3_d_refinement/evaluation_manifest.json').read_text())
    protected=dict(old['protected_inputs'])
    protected.update({str(p.relative_to(ROOT)):sha(p) for p in paths.values()})
    sweep=ROOT/'lookahead_21points_20261027/heldout_values.npz'
    cohort=ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv'
    for p in [sweep,cohort]:protected[str(p.relative_to(ROOT))]=sha(p)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    _,ck=load_checkpoint(paths['3A']);c=ck['config']
    weights=[0.,.1,.25,.5];alphas=[.1,.3,1.]
    assert choose_physics_candidate([],dict(checkpoint='fixture',selection_score=1.))['trial']=='baseline'
    dump(out/'protocol.json',dict(training=False,primary_checkpoint='Adam200',secondary_checkpoint='3A',
        focused_region=dict(time=[.35,.5],x=[0.,.6],y=[-.6,.6],heading='Original extended training heading range'),
        objective='(1-lambda)*mean(global |VI|) + lambda*mean(focused |VI|)',weights=weights,
        construction_batches=8,global_batch_size=2048,global_terminal_points=256,focused_batch_size=512,
        construction_seed=991738,selection_seed=991739,audit_seed=991740,
        assessment_global_size=8192,assessment_global_terminal_points=1024,assessment_focused_size=2048,
        directions='Saved-state hypothetical Adam from each weighted physics gradient; normalize to unweighted Adam displacement for that batch.',
        step_multipliers=alphas,selection_score='0.75*global physics loss + 0.25*focused physics loss, same score for every candidate.',
        selection_guard='Global selection physics loss must not exceed frozen baseline; unchanged baseline always available.',
        reference_usage='Development evaluation only; no labels/gradients in construction or selection.',
        reserved_final_states_used=False))
    torch.manual_seed(991738)
    global_queries=[];focus_queries=[]
    for _ in range(8):global_queries.append(sample(c,2048,.5,256,'cpu').numpy());focus_queries.append(focused(512,c))
    assessments={}
    for label,seed in [('selection',991739),('audit',991740)]:
        torch.manual_seed(seed)
        assessments[label]=(sample(c,8192,.5,1024,'cpu').numpy(),focused(2048,c))
    np.savez_compressed(out/'physics_queries.npz',global_batches=np.stack(global_queries),focused_batches=np.stack(focus_queries),
        **{label+'_'+kind:q for label,pool in assessments.items() for kind,q in zip(['global','focused'],pool)})
    with np.load(sweep) as f:states=f['states'].copy();times=f['times'].copy();refs=f['reference'].copy()
    tids=[int(np.argmin(abs(times-t))) for t in [.1,.25,.5]]
    query_by_time={i:np.column_stack([np.full(len(states),times[i]),states]) for i in tids}
    with cohort.open() as stream:top=np.array([int(r['state_index']) for r in csv.DictReader(stream)])
    def metrics(pred,i):
        err=pred-refs[i];ahead=states[:,0]>0
        return dict(mae=float(abs(err).mean()),rmse=float(np.sqrt(np.mean(err**2))),
            fixed_outlier_mae=float(abs(err[top]).mean()),ahead_mae=float(abs(err[ahead]).mean()),
            behind_mae=float(abs(err[~ahead]).mean()),max_abs=float(abs(err).max()),
            below_minus_radius_fraction=float(np.mean(pred < -.2501)),**classification(pred,refs[i]))
    rows=[];ev=[];baselines=[];gradient_rows=[];directions=[];all_winners=[];checks=[]
    for checkpoint,path in paths.items():
        print('Weighted physics directions at '+checkpoint,flush=True)
        model,ck=load_checkpoint(path);model.eval();params=tuple(model.parameters())
        original={k:v.clone() for k,v in model.state_dict().items()}
        base={k:p.detach().clone() for k,p in model.named_parameters()}
        cuts=np.cumsum([0]+[p.numel() for p in base.values()]);named=list(base)
        def overrides(d,alpha):
            return {k:base[k]+torch.tensor(alpha*d[cuts[j]:cuts[j+1]],dtype=base[k].dtype).reshape(base[k].shape) for j,k in enumerate(named)}
        pg=ck['optimizer']['param_groups'][0];moments=[ck['optimizer']['state'][pid] for pid in pg['params']]
        m=flat([x['exp_avg'] for x in moments]);v=flat([x['exp_avg_sq'] for x in moments]);step=int(moments[0]['step'])
        assert all(int(x['step'])==step for x in moments)
        baseline=dict(checkpoint=checkpoint)
        for label,(gq,fq) in assessments.items():
            baseline[label+'_global']=physics(model,base,gq,c);baseline[label+'_focused']=physics(model,base,fq,c)
            baseline[label+'_score']=.75*baseline[label+'_global']+.25*baseline[label+'_focused']
        baselines.append(baseline)
        for i,q in query_by_time.items():ev.append(dict(checkpoint=checkpoint,trial='baseline',weight=0.,alpha=0.,time=float(times[i]),**metrics(predict(model,base,q),i)))
        for batch,(gq,fq) in enumerate(zip(global_queries,focus_queries)):
            _,gg,_,_,_=group_gradient(model,c,gq);_,gf,_,_,_=group_gradient(model,c,fq)
            anchor=adam_direction(gg,m,v,step,pg['lr'],pg['betas'],pg['eps']);anchor_norm=np.linalg.norm(anchor)
            # Verify the weighted-gradient identity directly once per checkpoint.
            if batch==0:
                gr,_,_=residual(model,torch.tensor(gq[:128]),c,True)
                fr,_,_=residual(model,torch.tensor(fq[:128]),c,True)
                direct=flat(torch.autograd.grad(.75*gr.abs().mean()+.25*fr.abs().mean(),params))
                _,small_g,_,_,_=group_gradient(model,c,gq[:128]);_,small_f,_,_,_=group_gradient(model,c,fq[:128])
                np.testing.assert_allclose(direct,.75*small_g+.25*small_f,rtol=3e-4,atol=2e-6)
                # Independently compare the raw saved-state Adam formula with
                # a standard optimizer step on a disposable model copy.
                md=copy.deepcopy(model);opt=torch.optim.Adam(md.parameters(),lr=pg['lr']);opt.load_state_dict(copy.deepcopy(ck['optimizer']))
                opt.zero_grad();rr,_,_=residual(md,torch.tensor(gq),c,True);rr.abs().mean().backward();opt.step()
                actual=flat([p.detach()-base[k] for k,p in md.named_parameters()])
                np.testing.assert_allclose(actual,anchor,rtol=5e-3,atol=6e-8)
                checks.append(dict(checkpoint=checkpoint,weighted_gradient_identity=True,raw_adam_formula_matches_disposable_torch_step=True))
            for weight in weights:
                gradient=(1-weight)*gg+weight*gf
                raw=adam_direction(gradient,m,v,step,pg['lr'],pg['betas'],pg['eps'])
                d=raw*(anchor_norm/np.linalg.norm(raw));directions.append(d)
                gradient_rows.append(dict(checkpoint=checkpoint,batch=batch,weight=weight,
                    global_gradient_norm=float(np.linalg.norm(gg)),focused_gradient_norm=float(np.linalg.norm(gf)),
                    global_focused_cosine=float(gg@gf/(np.linalg.norm(gg)*np.linalg.norm(gf))),
                    raw_adam_displacement=float(np.linalg.norm(raw)),matched_displacement=float(anchor_norm),
                    first_order_global=float(gg@d),first_order_focused=float(gf@d)))
                for alpha in alphas:
                    trial=f'b{batch}_w{weight:g}_a{alpha:g}';parameters=overrides(d,alpha)
                    row=dict(checkpoint=checkpoint,trial=trial,batch=batch,weight=weight,alpha=alpha,displacement_l2=float(alpha*anchor_norm))
                    for label,(agq,afq) in assessments.items():
                        row[label+'_global']=physics(model,parameters,agq,c)
                        row[label+'_focused']=physics(model,parameters,afq,c)
                        row[label+'_score']=.75*row[label+'_global']+.25*row[label+'_focused']
                    row['selection_guard_passed']=row['selection_global']<=baseline['selection_global']
                    rows.append(row)
                    for i,q in query_by_time.items():
                        ev.append(dict(checkpoint=checkpoint,trial=trial,weight=weight,alpha=alpha,time=float(times[i]),**metrics(predict(model,parameters,q),i)))
            print(f'{checkpoint}: completed batch {batch+1}/8',flush=True)
        # All ranking is physics-only; baseline is retained if nothing qualifies.
        for family in ['unweighted','weighted','all']:
            eligible=[r for r in rows if r['checkpoint']==checkpoint and r['selection_guard_passed'] and r['selection_score']<baseline['selection_score']
                and (family=='all' or (r['weight']==0 if family=='unweighted' else r['weight']>0))]
            winner=choose_physics_candidate(eligible,baseline)
            evaluation=[r for r in ev if r['checkpoint']==checkpoint and r['trial']==winner['trial']]
            all_winners.append(dict(checkpoint=checkpoint,family=family,physics=winner,validation=evaluation))
        assert all(torch.equal(value,model.state_dict()[k]) for k,value in original.items())
        assert all(p.grad is None for p in model.parameters())
    write_csv(out/'physics_trials.csv',rows);write_csv(out/'validation_trials.csv',ev)
    write_csv(out/'baseline_physics.csv',baselines);write_csv(out/'gradient_directions.csv',gradient_rows)
    dump(out/'physics_selected_winners.json',all_winners)
    np.savez_compressed(out/'matched_directions.npz',directions=np.stack(directions))
    aggregate=[]
    for checkpoint in paths:
        base_final=next(r for r in ev if r['checkpoint']==checkpoint and r['trial']=='baseline' and r['time']==.5)
        baseline=next(r for r in baselines if r['checkpoint']==checkpoint)
        for weight in weights:
            for alpha in alphas:
                rr=[r for r in rows if r['checkpoint']==checkpoint and r['weight']==weight and r['alpha']==alpha]
                ee=[r for r in ev if r['checkpoint']==checkpoint and r['weight']==weight and r['alpha']==alpha and r['time']==.5]
                aggregate.append(dict(checkpoint=checkpoint,weight=weight,alpha=alpha,
                    global_audit_improved=sum(r['audit_global']<baseline['audit_global'] for r in rr),
                    focused_audit_improved=sum(r['audit_focused']<baseline['audit_focused'] for r in rr),
                    final_value_mae_improved=sum(r['mae']<base_final['mae'] for r in ee),
                    median_final_mae=float(np.median([r['mae'] for r in ee])),
                    median_audit_focused=float(np.median([r['audit_focused'] for r in rr]))))
    write_csv(out/'aggregate_by_weight_and_step.csv',aggregate)
    fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for ax,checkpoint in zip(axes,paths):
        baseline=next(r for r in baselines if r['checkpoint']==checkpoint)
        base_final=next(r for r in ev if r['checkpoint']==checkpoint and r['trial']=='baseline' and r['time']==.5)
        for weight in weights:
            rr=[r for r in rows if r['checkpoint']==checkpoint and r['weight']==weight]
            ee=[next(e for e in ev if e['checkpoint']==checkpoint and e['trial']==r['trial'] and e['time']==.5) for r in rr]
            ax.scatter([100*(baseline['audit_focused']-r['audit_focused'])/baseline['audit_focused'] for r in rr],
                [100*(base_final['mae']-e['mae'])/base_final['mae'] for e in ee],s=20,alpha=.65,label=f'Focused weight {weight:g}')
        ax.axhline(0,color='gray',ls=':');ax.axvline(0,color='gray',ls=':')
        ax.set(title=checkpoint,xlabel='Focused audit residual reduction [%]',ylabel='Final-time development MAE reduction [%]');ax.legend(fontsize=8)
    fig.suptitle('Geometry/horizon weighting: equal-displacement frozen probes, no training')
    fig.savefig(out/'weighting_probe.png',dpi=170);plt.close(fig)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    dump(out/'manifest.json',dict(status='completed',training=False,optimizer_created_for_training=False,
        disposable_optimizer_formula_check_only=True,persisted_parameter_updates=0,independent_probes=len(rows),
        checks_baseline_fallback=True,
        cost=dict(main_physics_gradient_batches=32,main_physics_gradient_point_assessments=40960,
            candidate_physics_point_assessments=len(rows)*2*(8192+2048),
            candidate_reference_value_point_assessments=len(rows)*3*24000,
            note='Excludes baseline evaluation and small disposable verification calculations; this is extra diagnostic compute.'),
        checkpoints_unchanged=True,model_parameters_unchanged=True,no_accumulated_parameter_gradients=True,
        reference_labels_used_for_directions_or_selection=False,reserved_final_states_used=False,
        checks=checks,protected_inputs=protected,
        sources={n:sha(ROOT/n) for n in ['probe_geometry_horizon.py','deepreach.py','probe_step_directions.py','diagnose_learning_signals.py']},
        elapsed_seconds=time.perf_counter()-start,threads=2))
    print(json.dumps([dict(checkpoint=w['checkpoint'],family=w['family'],trial=w['physics']['trial'],
        weight=w['physics'].get('weight'),final_mae=w['validation'][-1]['mae']) for w in all_winners],indent=2),flush=True)


if __name__=='__main__':run()

"""Fixed-budget, physics-only refinement. Requires explicit --train.

No numerical-reference labels are read here. Comparisons run separately after
all endpoints are saved. Existing output folders/checkpoints are never replaced.
"""
import argparse
import copy
import csv
import hashlib
import json
import os
import shutil
import time
from pathlib import Path
import numpy as np
import torch
from deepreach import load_checkpoint, residual, sample, environment
from probe_step_directions import physics
from diagnostics import ROOT, dump, sha


def copy_parameters(model, parameters):
    with torch.no_grad():
        for name,p in model.named_parameters():p.copy_(parameters[name])


def controlled_update(model,optimizer,q,c,alphas):
    """Advance moments once; choose among three finite steps and staying put."""
    optimizer.zero_grad(set_to_none=True)
    r,_,_=residual(model,q,c,True);loss=r.abs().mean()
    if not torch.isfinite(loss):raise FloatingPointError('Nonfinite physics loss')
    loss.backward()
    named=list(model.named_parameters())
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for _,p in named)
    base={k:p.detach().clone() for k,p in named}
    grad={k:p.grad.detach().clone() for k,p in named}
    optimizer.step() # Standard Adam updates moments; parameter proposal is temporary.
    adam={k:p.detach()-base[k] for k,p in named}
    norm=torch.sqrt(sum(d.square().sum() for d in adam.values()))
    copy_parameters(model,base)
    return float(loss.detach()),base,grad,float(norm)


def run(protocol_path,execution):
    protocol=json.loads(Path(protocol_path).read_text())
    parent=ROOT/protocol['parent_checkpoint'];assert sha(parent)==protocol['parent_sha256']
    folder=ROOT/protocol['output']
    if folder.exists():raise FileExistsError('Refinement folder exists; use a new protocol/output. No overwrite or implicit resume.')
    assert protocol['controlled_steps']==protocol['adam_intermediate']==200 and protocol['adam_steps']==800
    assert protocol['step_multipliers']==[.1,.3,1.]
    assert protocol['directions']==['plain_gradient','second_moment_scaled']
    torch.set_num_threads(protocol['threads']);torch.use_deterministic_algorithms(True)
    protected=list((ROOT/'runs').glob('*/checkpoint.pt'))+[ROOT/'lookahead_21points_20261027/heldout_values.npz',ROOT/'evaluation/reserved_final_states/states.npz']
    hashes={str(p.relative_to(ROOT)):sha(p) for p in protected}
    folder.mkdir(parents=True);dump(folder/'protocol.json',protocol)
    (folder/'sources').mkdir()
    for name in ['train_refinement.py','probe_step_directions.py','deepreach.py']:
        shutil.copy2(ROOT/name,folder/'sources'/name)
    dump(folder/'execution.json',dict(launch=execution,training=True,reference_labels_loaded=False,threads=protocol['threads']))
    base_model,original=load_checkpoint(parent);c=original['config']
    assert c['formulation']=='terminal_obstacle_square' and c['samples']==2048 and c['terminal_samples']==256
    dump(folder/'environment.json',environment(torch.device('cpu')))
    results=[];prefix=None;total_clock=time.perf_counter()
    for method in ['adam']+protocol['directions']:
        print('Starting refinement: '+method,flush=True)
        model,ck=load_checkpoint(parent);model.train()
        optimizer=torch.optim.Adam(model.parameters(),lr=c['lr']);optimizer.load_state_dict(ck['optimizer'])
        torch.set_rng_state(ck['torch_rng'].cpu())
        limit=protocol['adam_steps'] if method=='adam' else protocol['controlled_steps']
        arm=folder/method;arm.mkdir();batch_hash=hashlib.sha256();accepted=0;trials=0;clock=time.perf_counter()
        with (arm/'history.csv').open('w',newline='') as log:
            writer=csv.DictWriter(log,fieldnames=['step','pre_physics_loss','chosen_physics_loss','alpha','adam_displacement_l2','accepted','elapsed_seconds'])
            writer.writeheader()
            for step in range(1,limit+1):
                q=sample(c,2048,c['horizon'],256,'cpu');batch_hash.update(q.numpy().tobytes())
                if method=='adam':
                    optimizer.zero_grad(set_to_none=True)
                    r,_,_=residual(model,q,c,True);loss=r.abs().mean()
                    if not torch.isfinite(loss):raise FloatingPointError('Nonfinite Adam loss')
                    loss.backward()
                    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
                    optimizer.step();pre=float(loss.detach());chosen_loss=None;alpha=1.;norm=None;accepted+=1
                else:
                    pre,base,grad,norm=controlled_update(model,optimizer,q,c,protocol['step_multipliers'])
                    if method=='plain_gradient':direction={k:-g for k,g in grad.items()}
                    else:
                        pg=optimizer.param_groups[0];b2=pg['betas'][1]
                        direction={k:-grad[k]/((optimizer.state[p]['exp_avg_sq']/(1-b2**int(optimizer.state[p]['step']))).sqrt()+pg['eps']) for k,p in model.named_parameters()}
                    dnorm=float(torch.sqrt(sum(d.square().sum() for d in direction.values())))
                    direction={k:d*(norm/max(dnorm,1e-30)) for k,d in direction.items()}
                    chosen_loss=pre;alpha=0.;selected=base
                    for multiplier in protocol['step_multipliers']:
                        proposal={k:base[k]+multiplier*d for k,d in direction.items()}
                        score=physics(model,proposal,q.numpy(),c);trials+=1
                        if not np.isfinite(score):raise FloatingPointError('Nonfinite trial loss')
                        if score<chosen_loss:chosen_loss=score;alpha=multiplier;selected=proposal
                    copy_parameters(model,selected);accepted+=int(alpha>0)
                assert all(torch.isfinite(p).all() for p in model.parameters())
                writer.writerow(dict(step=step,pre_physics_loss=pre,chosen_physics_loss=chosen_loss,alpha=alpha,
                    adam_displacement_l2=norm,accepted=int(alpha>0),elapsed_seconds=time.perf_counter()-clock));log.flush()
                if step%50==0:print(f'{method} {step}/{limit}; accepted={accepted}; loss={pre:.6g}',flush=True)
                if step==200:
                    if method=='adam':prefix=batch_hash.hexdigest()
                    else:assert batch_hash.hexdigest()==prefix
                if step in ([200,800] if method=='adam' else [200]):
                    elapsed=time.perf_counter()-clock;path=arm/f'checkpoint_{step}.pt'
                    updated=dict(ck,model=model.state_dict(),optimizer=optimizer.state_dict(),step=ck['step']+step,
                        full_horizon_step=step,torch_rng=torch.get_rng_state(),parent_checkpoint=str(parent),
                        elapsed_seconds=ck['elapsed_seconds']+elapsed,additional_training_seconds=elapsed,
                        inherited_training_seconds=ck['elapsed_seconds'],refinement=dict(method=method,attempts=step,
                            accepted_parameter_steps=accepted,trial_physics_batches=trials,protocol=protocol))
                    torch.save(updated,path.with_suffix('.tmp'));os.replace(path.with_suffix('.tmp'),path)
                    result=dict(method=method,steps=step,accepted_steps=accepted,gradient_batches=step,
                        trial_physics_batches=trials,total_physics_batch_assessments=step+trials,
                        elapsed_seconds=elapsed,checkpoint=str(path.relative_to(ROOT)),sha256=sha(path),
                        sample_prefix_sha256=batch_hash.hexdigest())
                    results.append(result);dump(folder/'training_progress.json',results)
        optimizer.zero_grad(set_to_none=True)
    assert hashes=={str(p.relative_to(ROOT)):sha(p) for p in protected}
    dump(folder/'training_manifest.json',dict(status='completed',training=True,endpoints=results,
        protected_inputs=hashes,reserved_final_states_used=False,reference_labels_loaded=False,
        identical_200_batch_prefix=True,elapsed_seconds=time.perf_counter()-total_clock,
        protocol_sha256=sha(folder/'protocol.json'),source_sha256=sha(ROOT/'train_refinement.py')))
    print('Training complete; all four fixed endpoints saved. Reference evaluation is separate.',flush=True)


def check():
    """Meaningful check of moment advancement and rejected-proposal restoration."""
    torch.set_num_threads(2);model,ck=load_checkpoint(ROOT/'runs/experiment_3_a_constraints/checkpoint.pt')
    control=copy.deepcopy(model);c=ck['config']
    a=torch.optim.Adam(model.parameters(),lr=c['lr']);a.load_state_dict(copy.deepcopy(ck['optimizer']))
    b=torch.optim.Adam(control.parameters(),lr=c['lr']);b.load_state_dict(copy.deepcopy(ck['optimizer']))
    torch.manual_seed(991737);q=sample(c,128,.5,16,'cpu')
    original={k:p.detach().clone() for k,p in model.named_parameters()}
    _,base,grad,norm=controlled_update(model,a,q,c,[.1,.3,1.])
    assert all(torch.equal(base[k],p) for k,p in model.named_parameters())
    b.zero_grad();r,_,_=residual(control,q,c,True);r.abs().mean().backward();b.step()
    assert norm>0 and all(torch.equal(original[k],p) for k,p in model.named_parameters())
    for (_,p),(_,other) in zip(model.named_parameters(),control.named_parameters()):
        assert torch.equal(a.state[p]['exp_avg'],b.state[other]['exp_avg'])
        assert torch.equal(a.state[p]['exp_avg_sq'],b.state[other]['exp_avg_sq'])
    assert abs(norm-float(torch.sqrt(sum((p-original[k]).square().sum() for k,p in control.named_parameters()))))<1e-10
    print('Checks passed: proposals restore weights; Adam moment advancement/displacement match standard Adam. No checkpoint writes.')


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--train',action='store_true');ap.add_argument('--check',action='store_true')
    ap.add_argument('--protocol',default=str(ROOT/'configs/experiment3d_refinement.json'))
    ap.add_argument('--execution',default='managed process with existing project interpreter')
    args=ap.parse_args()
    if args.check:check()
    elif args.train:run(args.protocol,args.execution)
    else:ap.error('Use --check for checks, or explicit --train to start the fixed refinement.')

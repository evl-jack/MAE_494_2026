"""Finite physics-only parameter-direction probes; no training or checkpoint writes.

All candidates branch independently from the frozen 3A checkpoint. Reference
values only evaluate the candidates; they never construct their directions.
"""
import csv
import time
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from deepreach import load_checkpoint, sample, hamiltonian, target
from diagnose_learning_signals import flat, group_gradient, adam_direction
from diagnostics import ROOT, sha, dump, write_csv
from validate import classification


def physics(model, parameters, queries, c):
    total=0.
    for start in range(0,len(queries),1024):
        q=torch.tensor(queries[start:start+1024],dtype=torch.float32,requires_grad=True)
        value=torch.func.functional_call(model,parameters,(q,))
        dv=torch.autograd.grad(value.sum(),q)[0]
        r=torch.maximum(dv[:,0]-hamiltonian(q[:,1:],dv[:,1:],c),value-target(q[:,1:],c))
        total+=float(r.abs().sum().detach())
    return total/len(queries)


def predict(model,parameters,queries):
    with torch.no_grad():
        return np.concatenate([torch.func.functional_call(model,parameters,
            (torch.tensor(queries[i:i+1_024],dtype=torch.float32),)).numpy()
            for i in range(0,len(queries),1_024)])


def run():
    started=time.perf_counter();torch.set_num_threads(2)
    folder=ROOT/'experiments/experiment_3_a/step_direction_probe'
    folder.mkdir(parents=True,exist_ok=True)
    checkpoint=ROOT/'runs/experiment_3_a_constraints/checkpoint.pt'
    sweep=ROOT/'lookahead_21points_20261027/heldout_values.npz'
    cohort=ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv'
    vectors=ROOT/'experiments/experiment_3_a/learning_signals/parameter_vectors.npz'
    reserved=ROOT/'evaluation/reserved_final_states/states.npz'
    protected=list((ROOT/'runs').glob('*/checkpoint.pt'))+[sweep,cohort,vectors,reserved]
    before={str(p.relative_to(ROOT)):sha(p) for p in protected}
    model,ck=load_checkpoint(checkpoint);model.eval();c=ck['config']
    original={k:v.clone() for k,v in model.state_dict().items()}
    base={k:p.detach().clone() for k,p in model.named_parameters()}
    named=list(base);sizes=[p.numel() for p in base.values()];cuts=np.cumsum([0]+sizes)
    def overrides(direction,alpha):
        return {k:base[k]+torch.tensor(alpha*direction[cuts[j]:cuts[j+1]],dtype=base[k].dtype).reshape(base[k].shape)
                for j,k in enumerate(named)}
    with np.load(sweep) as f:
        states=f['states'].copy();times=f['times'].copy();refs=f['reference'].copy()
    with cohort.open() as stream:top=np.array([int(r['state_index']) for r in csv.DictReader(stream)])
    time_ids=[int(np.argmin(abs(times-t))) for t in [.1,.25,.5]]
    queries={i:np.column_stack([np.full(len(states),times[i]),states]) for i in time_ids}
    # Two independent full-training-distribution physics assessment batches.
    # Neither supplies gradients used to construct the candidates.
    torch.manual_seed(991735)
    assessment=[sample(c,8192,.5,1024,'cpu').numpy() for _ in range(2)]
    np.savez_compressed(folder/'physics_assessment_queries.npz',selection=assessment[0],audit=assessment[1])
    baseline_selection=physics(model,base,assessment[0],c)
    baseline_audit=physics(model,base,assessment[1],c)
    baseline={i:predict(model,base,q) for i,q in queries.items()}
    pg=ck['optimizer']['param_groups'][0]
    moments=[ck['optimizer']['state'][pid] for pid in pg['params']]
    m=flat([x['exp_avg'] for x in moments]);second=flat([x['exp_avg_sq'] for x in moments])
    step=int(moments[0]['step']);assert all(int(x['step'])==step for x in moments)
    with np.load(vectors) as f:expected=f['batch_physics'].copy();expected_adam=f['frozen_adam_directions'].copy()
    rows=[];evaluation=[];direction_rows=[];directions=[];baselines=[]
    def metrics(pred,i):
        err=pred-refs[i]
        out=dict(mae=float(abs(err).mean()),rmse=float(np.sqrt((err**2).mean())),
                 outlier_cohort_mae=float(abs(err[top]).mean()),max_abs=float(abs(err).max()),
                 below_minus_radius_fraction=float(np.mean(pred < -c['radius']-1e-4)))
        out.update(classification(pred,refs[i]));return out
    for i in time_ids:baselines.append(dict(time=float(times[i]),**metrics(baseline[i],i)))
    with np.load(ROOT/'experiments/experiment_3_a/candidate_values.npz') as f:
        for i in time_ids:np.testing.assert_allclose(baseline[i],f['predictions'][i],rtol=1e-5,atol=2e-6)
    write_csv(folder/'baseline_validation.csv',baselines)
    # Replay previously inspected batches; loading the checkpoint happened before reseeding.
    torch.manual_seed(991733)
    alphas=[.01,.1,.3,1.,3.]
    for batch in range(8):
        q=sample(c,2048,.5,256,'cpu').numpy()
        stats,gp,_,_,_=group_gradient(model,c,q)
        np.testing.assert_allclose(gp,expected[batch],rtol=1e-6,atol=1e-7)
        adam=adam_direction(gp,m,second,step,pg['lr'],pg['betas'],pg['eps'])
        np.testing.assert_allclose(adam,expected_adam[batch],rtol=1e-6,atol=1e-10)
        norm=np.linalg.norm(adam)
        # Equal Euclidean parameter displacement isolates direction from scale.
        # Saved Adam second moments provide a physics-derived diagonal metric.
        raw={'adam':adam,'plain_gradient':-gp,
             'second_moment_preconditioned':-gp/(np.sqrt(second/(1-pg['betas'][1]**step))+pg['eps'])}
        for name,d in raw.items():
            d=d*(norm/np.linalg.norm(d))
            directions.append(d);direction_rows.append(dict(batch=batch,direction=name,unit_scale_l2=float(norm),
                construction_physics_first_order=float(gp@d)))
            for alpha in alphas:
                p=overrides(d,alpha)
                construction=physics(model,p,q,c)
                selection=physics(model,p,assessment[0],c)
                audit=physics(model,p,assessment[1],c)
                trial=f'b{batch}_{name}_a{alpha:g}'
                rows.append(dict(trial=trial,batch=batch,direction=name,alpha=alpha,
                    parameter_displacement_l2=float(alpha*norm),construction_physics=construction,
                    construction_physics_delta=construction-stats['physics_loss'],
                    selection_physics=selection,selection_physics_delta=selection-baseline_selection,
                    audit_physics=audit,audit_physics_delta=audit-baseline_audit))
                preds={i:predict(model,p,query) for i,query in queries.items()}
                for i,pred in preds.items():
                    evaluation.append(dict(trial=trial,batch=batch,direction=name,alpha=alpha,time=float(times[i]),
                        **metrics(pred,i)))
                rows[-1]['time_increase_025_05_fraction']=float(np.mean(preds[time_ids[-1]]>preds[time_ids[1]]+1e-4))
            print(f'Completed batch {batch+1}/8, {name}',flush=True)
    write_csv(folder/'physics_probes.csv',rows);write_csv(folder/'validation_probes.csv',evaluation)
    write_csv(folder/'directions.csv',direction_rows)
    np.savez_compressed(folder/'physics_directions.npz',directions=np.stack(directions))
    # Rank using only selection physics loss, then expose independent audit and
    # development-reference outcomes. Retain the unchanged baseline as a choice.
    best=min(rows,key=lambda r:r['selection_physics'])
    accepted=best['selection_physics']<baseline_selection
    best_eval=[r for r in evaluation if r['trial']==best['trial']]
    aggregate=[];chosen=[]
    final={r['trial']:r for r in evaluation if r['time']==.5}
    for method in raw:
        for alpha in alphas:
            rr=[r for r in rows if r['direction']==method and r['alpha']==alpha]
            ee=[final[r['trial']] for r in rr]
            aggregate.append(dict(direction=method,alpha=alpha,
                audit_physics_improved=sum(r['audit_physics_delta']<0 for r in rr),
                final_mae_improved=sum(r['mae']<baselines[-1]['mae'] for r in ee),
                median_audit_physics_delta=float(np.median([r['audit_physics_delta'] for r in rr])),
                median_final_mae=float(np.median([r['mae'] for r in ee])),
                max_false_safe_final=max(r['false_safe_fraction_of_reference_unsafe'] for r in ee)))
        for batch in range(8):
            r=min([r for r in rows if r['direction']==method and r['batch']==batch],key=lambda r:r['selection_physics'])
            # All per-batch/method minima improve selection loss; otherwise
            # this summary would need to retain the unchanged baseline.
            assert r['selection_physics']<baseline_selection
            e=final[r['trial']]
            chosen.append(dict(direction=method,batch=batch,alpha=r['alpha'],selection_physics=r['selection_physics'],
                audit_physics_delta=r['audit_physics_delta'],final_mae=e['mae'],final_outlier_mae=e['outlier_cohort_mae']))
    write_csv(folder/'aggregate_by_scale.csv',aggregate);write_csv(folder/'physics_selected_by_batch.csv',chosen)
    dump(folder/'interpretation_metrics.json',dict(
        selected_audit_physics_percent_reduction=100*(baseline_audit-best['audit_physics'])/baseline_audit,
        selected_final_mae_percent_reduction=100*(baselines[-1]['mae']-best_eval[-1]['mae'])/baselines[-1]['mae'],
        selected_outlier_mae_percent_reduction=100*(baselines[-1]['outlier_cohort_mae']-best_eval[-1]['outlier_cohort_mae'])/baselines[-1]['outlier_cohort_mae'],
        by_method={method:dict(audit_improvements=sum(r['audit_physics_delta']<0 for r in chosen if r['direction']==method),
            final_mae_improvements=sum(r['final_mae']<baselines[-1]['mae'] for r in chosen if r['direction']==method),
            median_final_mae=float(np.median([r['final_mae'] for r in chosen if r['direction']==method]))) for method in raw}))
    selected_direction=directions[[f'b{r["batch"]}_{r["direction"]}' for r in direction_rows].index(f'b{best["batch"]}_{best["direction"]}')]
    selected_parameters=overrides(selected_direction,best['alpha'])
    terminal_query=np.column_stack([np.zeros(len(states)),states])
    terminal_error=float(np.max(abs(predict(model,selected_parameters,terminal_query)-(np.hypot(states[:,0],states[:,1])-c['radius']))))
    assert terminal_error<2e-7
    assert all(np.isfinite(d).all() for d in directions)
    assert all(np.isfinite(r[k]) for r in evaluation for k in ['mae','rmse','max_abs'])
    summary=dict(training=False,optimizer_steps=0,persisted_parameter_updates=0,
        independent_hypothetical_candidates=len(rows),construction_batches=8,construction_seed=991733,
        assessment_seed=991735,assessment_batch_size=8192,alphas=alphas,
        selection_rule='Minimum selection-batch physics loss, including unchanged baseline; no reference labels in selection.',
        baseline_selection_physics=baseline_selection,baseline_audit_physics=baseline_audit,
        best_physics_trial=best,best_trial_beats_baseline_selection=accepted,best_trial_validation=best_eval,
        baseline_validation=baselines,reserved_final_states_used=False,
        selected_terminal_max_abs=terminal_error,
        cost=dict(physics_parameter_gradient_batches=8,candidate_physics_loss_assessments=360,
            candidate_physics_point_assessments=120*(2048+2*8192),candidate_reference_value_point_assessments=120*3*24000),
        scope='Independent finite perturbations from frozen 3A, not sequential steps or trained optimizer comparison.',
        elapsed_seconds=time.perf_counter()-started)
    dump(folder/'summary.json',summary)
    fig,axes=plt.subplots(1,3,figsize=(15,4.8),layout='constrained')
    colors={'adam':'tab:blue','plain_gradient':'tab:orange','second_moment_preconditioned':'tab:green'}
    final=[r for r in evaluation if r['time']==.5]
    for name,color in colors.items():
        rr=[r for r in rows if r['direction']==name]
        axes[0].scatter([r['parameter_displacement_l2'] for r in rr],[r['audit_physics_delta'] for r in rr],s=16,alpha=.65,label=name,color=color)
        ee=[r for r in final if r['direction']==name]
        axes[1].scatter([r['alpha'] for r in ee],[r['mae'] for r in ee],s=16,alpha=.65,color=color)
        axes[2].scatter([r['audit_physics_delta'] for r in rr],[r['mae'] for r in ee],s=16,alpha=.65,color=color)
    axes[0].axhline(0,color='gray',ls=':');axes[0].set(xscale='log',xlabel='Parameter displacement L2',ylabel='Audit physics loss change',title='Does the finite step reduce physics loss?')
    for ax in axes[1:]:ax.axhline(baselines[-1]['mae'],color='gray',ls=':')
    axes[1].set(xscale='log',xlabel='Step multiplier (equal displacement per batch)',ylabel='Final-time validation MAE [m]',title='Does reference accuracy follow?')
    axes[2].set(xlabel='Audit physics loss change',ylabel='Final-time validation MAE [m]',title='Physics improvement versus value accuracy')
    axes[0].legend(fontsize=7);fig.suptitle('Frozen 3A: 120 independent finite-step probes; no training')
    fig.savefig(folder/'step_direction_probe.png',dpi=170);plt.close(fig)
    assert all(torch.equal(v,model.state_dict()[k]) for k,v in original.items())
    assert all(p.grad is None for p in model.parameters())
    after={str(p.relative_to(ROOT)):sha(p) for p in protected};assert before==after
    dump(folder/'manifest.json',dict(status='completed',protected_inputs=after,
        sources={p:sha(ROOT/p) for p in ['probe_step_directions.py','diagnose_learning_signals.py','deepreach.py']},
        training=False,optimizer_created=False,checkpoint_weights_unchanged=True,
        baseline_matches_saved_3A_predictions=True,replayed_gradients_match_previous_diagnostic=True,
        selected_terminal_max_abs=terminal_error,directions_and_validation_errors_finite=True,
        candidate_parameters='Temporary functional_call overrides; none saved as a checkpoint.',
        reference_usage='Development evaluation only, excluded from direction construction and physics selection.',
        reserved_inputs='Hashed for preservation only; not loaded or evaluated.',threads=2))
    print('Completed finite-step probe: '+str(folder),flush=True)


if __name__=='__main__':run()

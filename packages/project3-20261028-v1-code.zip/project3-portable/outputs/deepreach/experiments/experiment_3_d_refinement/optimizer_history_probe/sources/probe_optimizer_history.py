"""Isolate optimizer-history directions at frozen parameters. Never trains."""
import csv
import json
import time
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from deepreach import load_checkpoint
from diagnostics import ROOT, dump, sha, write_csv
from diagnose_learning_signals import flat, group_gradient, adam_direction, cosine
from probe_step_directions import physics, predict
from validate import classification


def history_directions(g,m,v,other_m,step,pg):
    """Physics gradient and moment inputs only; no reference values/gradients."""
    args=(step,pg['lr'],pg['betas'],pg['eps'])
    return dict(saved_adam=adam_direction(g,m,v,*args),
        suppress_first_moment=adam_direction(g,np.zeros_like(m),v,*args),
        fresh_adam=adam_direction(g,np.zeros_like(m),np.zeros_like(v),0,pg['lr'],pg['betas'],pg['eps']),
        plain_gradient=-g,
        swapped_first_moment=adam_direction(g,other_m,v,*args))


def choose(candidates,baseline):
    valid=[r for r in candidates if r['selection_global']<baseline['selection_global']]
    return min(valid,key=lambda r:r['selection_global']) if valid else dict(baseline,trial='baseline')


def run():
    started=time.perf_counter();torch.set_num_threads(2)
    parent=ROOT/'experiments/experiment_3_d_refinement'
    previous=parent/'geometry_horizon_probe';out=parent/'optimizer_history_probe';out.mkdir(parents=True,exist_ok=True)
    old=json.loads((previous/'manifest.json').read_text());protected=dict(old['protected_inputs'])
    for p in [previous/'physics_queries.npz',previous/'matched_directions.npz',previous/'gradient_directions.csv']:
        protected[str(p.relative_to(ROOT))]=sha(p)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    paths={'3A':ROOT/'runs/experiment_3_a_constraints/checkpoint.pt','Adam200':parent/'adam/checkpoint_200.pt'}
    checkpoints={name:load_checkpoint(path)[1] for name,path in paths.items()}
    moment_data={}
    for name,ck in checkpoints.items():
        pg=ck['optimizer']['param_groups'][0];states=[ck['optimizer']['state'][pid] for pid in pg['params']]
        assert not pg['amsgrad'] and not pg['maximize'] and pg['weight_decay']==0
        step=int(states[0]['step']);assert all(int(s['step'])==step for s in states)
        moment_data[name]=(flat([s['exp_avg'] for s in states]),flat([s['exp_avg_sq'] for s in states]),step,pg)
    alphas=[.01,.1,.3,1.]
    dump(out/'protocol.json',dict(training=False,primary_checkpoint='Adam200',secondary_checkpoint='3A',
        construction='Reuse eight 2048-point global batches from geometry/horizon probe, seed 991738; no focused loss in gradient.',
        selection='Lowest global physics selection loss, with unchanged baseline available.',
        audit='Reuse separate seed 991740 global and focused physics pools; neither constructs/selects directions.',
        selection_pool='Reuse global seed 991739 pool.',
        directions=['saved_adam','suppress_first_moment','fresh_adam','plain_gradient','swapped_first_moment'],
        normalization='Every direction matches saved-Adam L2 displacement for that checkpoint/batch; natural restart step magnitude is not tested.',
        suppressed_m='Set incoming first moment to zero; retain saved second moment, clock and usual beta1 update.',
        swapped_m='Borrow only incoming first moment from other checkpoint; keep current weights, gradient, second moment and clock.',
        fresh_adam='Zero both moments and restart clock at zero; normalize resulting first-step direction.',
        step_multipliers=alphas,reference_usage='Evaluation-only final-time MAE/half-MSE gradients and finite-step development accuracy; never direction construction or selection.',
        evaluated_times=[.1,.25,.5],reserved_final_states_used=False))
    with np.load(previous/'physics_queries.npz') as f:
        batches=f['global_batches'].copy();selection=f['selection_global'].copy()
        audit=f['audit_global'].copy();focused=f['audit_focused'].copy()
    with np.load(previous/'matched_directions.npz') as f:old_directions=f['directions'].copy()
    old_rows=list(csv.DictReader((previous/'gradient_directions.csv').open()))
    with np.load(ROOT/'lookahead_21points_20261027/heldout_values.npz') as f:
        states=f['states'].copy();times=f['times'].copy();refs=f['reference'].copy()
    with (ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv').open() as stream:
        top=np.array([int(r['state_index']) for r in csv.DictReader(stream)])
    tids=[int(np.argmin(abs(times-t))) for t in [.1,.25,.5]]
    queries={i:np.column_stack([np.full(len(states),times[i]),states]) for i in tids}
    def metrics(pred,i):
        e=pred-refs[i]
        return dict(mae=float(abs(e).mean()),rmse=float(np.sqrt(np.mean(e**2))),
            outlier_mae=float(abs(e[top]).mean()),max_abs=float(abs(e).max()),
            below_minus_radius_fraction=float(np.mean(pred<-.2501)),**classification(pred,refs[i]))
    rows=[];ev=[];baselines=[];direction_rows=[];vectors=[];winners=[];checks=[]
    assert choose([],dict(selection_global=1.))['trial']=='baseline'
    # Fresh Adam's first step equals -lr*g/(|g|+eps), independently checked.
    fixture=np.array([2.,-3.,.01]);fresh=adam_direction(fixture,np.zeros(3),np.zeros(3),0,.001,(.9,.999),1e-8)
    np.testing.assert_allclose(fresh,-.001*fixture/(abs(fixture)+1e-8),rtol=1e-12)
    for name,path in paths.items():
        print('Optimizer-history probe at '+name,flush=True)
        model,ck=load_checkpoint(path);model.eval();c=ck['config']
        original={k:v.clone() for k,v in model.state_dict().items()}
        base={k:p.detach().clone() for k,p in model.named_parameters()};cuts=np.cumsum([0]+[p.numel() for p in base.values()])
        def override(d,alpha):
            return {k:base[k]+torch.tensor(alpha*d[cuts[j]:cuts[j+1]],dtype=base[k].dtype).reshape(base[k].shape) for j,k in enumerate(base)}
        m,v,step,pg=moment_data[name];other='Adam200' if name=='3A' else '3A';other_m=moment_data[other][0]
        b=dict(checkpoint=name,selection_global=physics(model,base,selection,c),audit_global=physics(model,base,audit,c),audit_focused=physics(model,base,focused,c))
        baselines.append(b)
        for i,q in queries.items():ev.append(dict(checkpoint=name,trial='baseline',direction='baseline',alpha=0.,time=float(times[i]),**metrics(predict(model,base,q),i)))
        # These oracle gradients are evaluated once for interpretation only.
        # history_directions has no access to them.
        _,_,oracle_mse,oracle_mae,_=group_gradient(model,c,queries[tids[-1]],refs[tids[-1]])
        for batch,q in enumerate(batches):
            _,g,_,_,_=group_gradient(model,c,q)
            raw=history_directions(g,m,v,other_m,step,pg);anchor=np.linalg.norm(raw['saved_adam'])
            previous_index=next(i for i,r in enumerate(old_rows) if r['checkpoint']==name and int(r['batch'])==batch and float(r['weight'])==0.)
            np.testing.assert_allclose(raw['saved_adam'],old_directions[previous_index],rtol=1e-6,atol=1e-10)
            # Removing first-moment history is exactly proportional to the
            # current gradient scaled by the same next-step denominator.
            b1,b2=pg['betas'];next_v=b2*v+(1-b2)*g*g
            scaled=-g/(np.sqrt(next_v/(1-b2**(step+1)))+pg['eps'])
            np.testing.assert_allclose(raw['suppress_first_moment'],pg['lr']*(1-b1)/(1-b1**(step+1))*scaled,rtol=1e-12,atol=1e-12)
            for kind,d0 in raw.items():
                d=d0*(anchor/np.linalg.norm(d0));vectors.append(d)
                direction_rows.append(dict(checkpoint=name,batch=batch,direction=kind,raw_norm=float(np.linalg.norm(d0)),matched_norm=float(anchor),
                    cosine_with_saved=cosine(d,raw['saved_adam']),construction_physics_first_order=float(g@d),
                    final_mae_first_order=float(oracle_mae@d),final_half_mse_first_order=float(oracle_mse@d)))
                for alpha in alphas:
                    trial=f'b{batch}_{kind}_a{alpha:g}';parameters=override(d,alpha)
                    row=dict(checkpoint=name,trial=trial,batch=batch,direction=kind,alpha=alpha,displacement_l2=float(alpha*anchor),
                        selection_global=physics(model,parameters,selection,c),audit_global=physics(model,parameters,audit,c),audit_focused=physics(model,parameters,focused,c))
                    rows.append(row)
                    for i,qv in queries.items():ev.append(dict(checkpoint=name,trial=trial,direction=kind,alpha=alpha,time=float(times[i]),**metrics(predict(model,parameters,qv),i)))
            print(f'{name}: batch {batch+1}/8 complete',flush=True)
        for kind in list(raw)+['all']:
            candidates=[r for r in rows if r['checkpoint']==name and (kind=='all' or r['direction']==kind)]
            winner=choose(candidates,b)
            wins=[r for r in ev if r['checkpoint']==name and r['trial']==winner['trial']]
            winners.append(dict(checkpoint=name,family=kind,physics=winner,validation=wins))
        assert all(torch.equal(value,model.state_dict()[k]) for k,value in original.items())
        assert all(p.grad is None for p in model.parameters())
        checks.append(dict(checkpoint=name,weights_unchanged=True,no_accumulated_parameter_gradients=True,
            saved_direction_replays_previous_probe=True,suppressed_first_moment_identity=True))
    write_csv(out/'physics_trials.csv',rows);write_csv(out/'validation_trials.csv',ev)
    write_csv(out/'baseline_physics.csv',baselines);write_csv(out/'direction_diagnostics.csv',direction_rows)
    np.savez_compressed(out/'matched_directions.npz',directions=np.stack(vectors))
    dump(out/'physics_selected_winners.json',winners)
    aggregate=[]
    for name in paths:
        b=next(r for r in baselines if r['checkpoint']==name)
        base_final=next(r for r in ev if r['checkpoint']==name and r['trial']=='baseline' and r['time']==.5)
        for kind in raw:
            dd=[r for r in direction_rows if r['checkpoint']==name and r['direction']==kind]
            for alpha in alphas:
                rr=[r for r in rows if r['checkpoint']==name and r['direction']==kind and r['alpha']==alpha]
                ee=[r for r in ev if r['checkpoint']==name and r['direction']==kind and r['alpha']==alpha and r['time']==.5]
                aggregate.append(dict(checkpoint=name,direction=kind,alpha=alpha,
                    audit_global_improves=sum(r['audit_global']<b['audit_global'] for r in rr),
                    final_mae_improves=sum(r['mae']<base_final['mae'] for r in ee),
                    median_final_mae=float(np.median([r['mae'] for r in ee])),
                    median_audit_global=float(np.median([r['audit_global'] for r in rr])),
                    first_order_final_mae_descends=sum(r['final_mae_first_order']<0 for r in dd)))
    write_csv(out/'aggregate_by_direction_and_step.csv',aggregate)
    fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for ax,name in zip(axes,paths):
        b=next(r for r in baselines if r['checkpoint']==name)
        bval=next(r for r in ev if r['checkpoint']==name and r['trial']=='baseline' and r['time']==.5)
        for kind in raw:
            rr=[r for r in rows if r['checkpoint']==name and r['direction']==kind]
            ee=[next(e for e in ev if e['checkpoint']==name and e['trial']==r['trial'] and e['time']==.5) for r in rr]
            ax.scatter([100*(b['audit_global']-r['audit_global'])/b['audit_global'] for r in rr],
                [100*(bval['mae']-e['mae'])/bval['mae'] for e in ee],s=18,alpha=.65,label=kind)
        ax.axhline(0,color='gray',ls=':');ax.axvline(0,color='gray',ls=':');ax.legend(fontsize=7)
        ax.set(title=name,xlabel='Global audit physics loss reduction [%]',ylabel='Final-time value MAE reduction [%]')
    fig.suptitle('Optimizer memory at fixed parameters: equal-displacement probes, no training')
    fig.savefig(out/'optimizer_history_probe.png',dpi=170);plt.close(fig)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    dump(out/'manifest.json',dict(status='completed',training=False,optimizer_created=False,parameter_updates=0,
        reserved_final_states_used=False,reference_gradients_used_for_directions_or_selection=False,
        checks=checks,fresh_adam_scalar_identity=True,baseline_fallback=True,protected_inputs=protected,
        sources={n:sha(ROOT/n) for n in ['probe_optimizer_history.py','deepreach.py','probe_step_directions.py','diagnose_learning_signals.py']},
        cost=dict(independent_probes=len(rows),construction_gradient_batches=16,
            reference_error_gradient_evaluations=2,candidate_physics_point_assessments=len(rows)*(8192+8192+2048),
            candidate_reference_value_point_assessments=len(rows)*3*24000,
            note='Additional diagnostic compute; excludes baseline and verification calculations.'),
        elapsed_seconds=time.perf_counter()-started,threads=2))
    print(json.dumps([dict(checkpoint=w['checkpoint'],family=w['family'],trial=w['physics']['trial'],
        final_mae=w['validation'][-1]['mae']) for w in winners],indent=2),flush=True)


if __name__=='__main__':run()

# DeepReach Air3D experiments

[Phase 4 â€” joint-coordinate 6D specification](experiment_4_joint6d/README.md): design and physics checks completed; proposed soft/exact/longer baselines are not trained. This phase studies the same two-vehicle game with six absolute state variables and new invariance/control diagnostics.

[Consolidated conclusions across Experiments 1â€“3](CONCLUSIONS.md) distinguish measured results, supported interpretations and unanswered questions. Experiment 3 comprises the archived 3Aâ€“3E stages and their diagnostics; their IDs are unchanged.

[Frozen final evaluation](../evaluation/final_evaluation_20261028/README.md): the selected 22,000-step model improves final-time MAE 12.61% over Adam +200 on 24,000 previously unused states. The set is now consumed; no training or tuning occurred during final evaluation.

[Experiment 3A â€” exact terminal/obstacle constraints](experiment_3_a/RESULTS.md) completed through VS Code with A's same 10,000 physics steps, omitting its 2,000 terminal-only steps. The saved comparison includes all 21 look-ahead points and remaining defects.

[Failure analysis of the unchanged models](../failure_analysis_20261027/README.md): locations, equation residuals and exact-property checks distinguish measured defects from causal hypotheses. No additional training experiment.

[Denser 21-point look-ahead diagnostic](../lookahead_21points_20261027/README.md): extends the evaluation knob to .025 s spacing without retraining. The original diagnostic measurements are retained.

[27 October diagnostic supplement](../diagnostics_20261027/README.md): relative L2 versus evaluation look-ahead, spatial/heading error spectra, reference construction and warm inference timings for the four existing models. No additional training; not Experiment 3. See [findings](../diagnostics_20261027/FINDINGS.md) for implications and limitations.

| Experiment | Date | Scope | Outcome |
|---|---|---|---|
| [Experiment 1 â€” Reduced CPU baseline](experiment_1/README.md) | 22 October 2026 | Three sine hidden layers of width 64, 2,048 samples/step, 2,000 terminal + 10,000 physics steps, .5 s horizon | Executed and compared with independent grids; .0915 m final-horizon value MAE, 46.42% false-safe among reference-unsafe samples |
| [Experiment 2 â€” Three controlled candidates](experiment_2/README.md) | 22 October 2026 | A: lower terminal weight; B: focused physics sampling; C: 10,000 additional full-horizon steps; all launched in VS Code | All improved final-horizon value MAE; A best at .04477 m and 10.82% false-safe, with increased false-unsafe and terminal error |
| [Experiment 3A â€” Exact terminal/obstacle output](experiment_3_a/RESULTS.md) | 27 October 2026 | Squared nonpositive correction; 10,000 physics updates, no terminal-only pretraining; VS Code | .02602 m final MAE, 19.12% relative L2, IoU .799, 0% observed false-safe and 7.10% false-unsafe; remaining lower-bound, time and heading defects |
| [Experiment 3B â€” Periodic heading](experiment_3_b/RESULTS.md) | 27 October 2026 | 3A square output, sin/cos heading; matched 10,000 physics batches; +64 parameters; VS Code | Old outlier cohort MAE improves 26%, heading seam removed numerically, but overall MAE .03517 m and false-unsafe 9.52% worsen versus 3A; retain 3A as overall baseline |
| [Experiment 3C â€” Mixed time sampling](experiment_3_c/RESULTS.md) | 27 October 2026 | 3A raw-angle architecture/initialization, matched spatial/heading draws; 50/50 full-horizon/curriculum times; 10,000 updates; managed process | Old outlier cohort improves 10%, but overall MAE .02996 m and false-unsafe 8.68% worsen versus 3A; new worst tail also worsens; retain 3A |
| [Experiment 3D â€” Short refinement](experiment_3_d_refinement/RESULTS.md) | 28 October 2026 | Adam +200/+800 versus plain/scaled directions with step selection | Adam +200 gives best development MAE in this trial, .02282 m; stronger residual reduction does not imply better value accuracy; later probes find a local mismatch that persists without momentum |
| [Experiment 3E â€” Duration versus capacity](experiment_3_e_capacity_budget/RESULTS.md) | 28 October 2026 | Width 64 to 22,000 total steps versus width 96 at 10,000; close nominal MAC budgets, different actual times | Development MAE .01985 m and .02127 m respectively; longer narrow model strongest overall; later fixed final evaluation confirms its advantage |

Experiment 1 reproduces the core PINN workflow but does not reproduce the paper's reported accuracy. Experiment 2 tests three separate modifications using the same reference and held-out states; it is a single-seed exploratory comparison. The smoke run is a setup check and is not counted as another experiment. The full paper-scale configuration is available but has not run.

Run artifacts retain their original dated directory names for reproducibility. Each experiment record maps its label to the original run, configuration, checkpoint, metrics and plots. Numerical-reference agreement is empirical evidence, not a safety guarantee.

## 6D experiments

Continue in the separate [6D subsection](../experiments_6d/README.md), inside this same project. The original Experiment 4 design record remains here for provenance.

6D training is now complete for the three fixed-budget runs; [training record](../experiments_6d/TRAINING_RESULTS.md). Accuracy and control evaluation remain separate.

6D grouped development evaluation is complete: [value, invariance and gradient results](../experiments_6d/development_evaluation/README.md). The subsequent closed-loop comparison is linked below.

6D closed-loop development tests are complete: [policy comparisons, time-step sensitivity and the shared remaining failure](../experiments_6d/closed_loop_evaluation/README.md).

The shared failure diagnostic is complete: [initial gradients, fixed turn-prefix interventions and reference uncertainty](../experiments_6d/shared_failure_diagnostic/README.md). No model update or general controller patch was introduced.

Local numerical reference refinement is complete: [three grid levels, two derivative estimators and switching maps](../experiments_6d/local_reference_refinement/README.md). The initial direction mismatch persists; full gradient convergence is not claimed.

The local physics-loss audit is complete: [strong local residual signals, loss priorities and sampling-test implications](../experiments_6d/local_physics_audit/README.md). No parameter update or new controller was introduced.

Experiment 5 training is complete: [uniform versus residual-guided continuation results](../experiments_6d/experiment_5_sampling/TRAINING_RESULTS.md). Both arms added the same 2,000 updates in VS Code; extra candidate-scoring cost is recorded separately. [Common evaluation is complete](../experiments_6d/experiment_5_sampling/evaluation/README.md): about 10% value improvement for both, no clear mixed-sampler advantage, and no primary contact reduction.

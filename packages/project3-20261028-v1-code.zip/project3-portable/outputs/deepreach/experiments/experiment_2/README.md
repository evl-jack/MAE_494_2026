# Experiment 2 — Controlled error-reduction tests

Three separate candidates are compared against the unchanged Experiment 1 baseline. These are single-seed exploratory tests; no candidate is assumed to help and no statistical generalization or safety guarantee is claimed.

## Design

| Variant | Only deliberate change | New optimizer steps |
|---|---|---|
| A — Loss weight | Divide the initially calibrated terminal multiplier by 10; keep it fixed afterward | 12,000, fresh run |
| B — Focused sampling | 50% of nonterminal physics states in a uniform-area radius-1 m disk; the rest uniform in the original box | 12,000, fresh run |
| C — Full-horizon hold | Continue Experiment 1 with its exact optimizer and RNG state for 10,000 more steps, sampling the full [0,.5] s time interval | 10,000 additional; 22,000 cumulative |

Architecture, physical dynamics, learning rate, domain, horizon and seed stay fixed. Terminal pretraining and terminal-coordinate sampling stay uniform. A and B use the same 2,000 + 10,000 step schedule as Experiment 1; C intentionally spends additional compute. No reference labels enter training. The focus radius is the physical bound R+2*v*T=1 m, not a value learned from the reference. The sampling mixture intentionally changes the physics-training distribution; no importance correction is applied.

The original checked reference grid is reused. Evaluation uses the same 24,000 interior states, seed and time slices as Experiment 1, plus the same full-box terminal/VI diagnostic distribution. Original Experiment 1 metrics were reproduced before these runs.

## Baseline diagnostic batch

Weighted terminal/PDE gradient L2 ratio: 137.478. Gradient cosine: 0.647. Near-region VI MAE: 0.09177; far-region VI MAE: 0.08846. This is one batch, not a causal attribution.

## Measured results at .5 s

All three candidates completed through the VS Code Python debugger. The time column below is original recorded training for Experiment 1 (not retrained here), fresh training for A/B, and additional training for C. C's cumulative training time is 436.9 s, including the inherited 206.4 s. Debugger and machine workload affect wall-clock comparisons; optimizer step counts are the controlled budgets. The checked reference was reused without a new numerical solve.

The calibrated terminal multipliers were 106.4252 (baseline/C), 10.6425 (A), and 125.3498 (B). B retains the same automatic calibration rule; changing its first physics batch also changes the resulting multiplier.

| Variant | Value MAE [m] | RMSE [m] | IoU | False-safe / reference-unsafe | False-unsafe / reference-safe | Terminal MAE [m] | VI MAE | New training [s] |
|---|---|---|---|---|---|---|---|---|
| Experiment 1 | 0.09150 | 0.11689 | 0.478 | 46.42% | 3.43% | 0.00891 | 0.09033 | 206.4 |
| A - Loss weight | 0.04477 | 0.05797 | 0.688 | 10.82% | 8.33% | 0.01457 | 0.04840 | 326.5 |
| B - Focused sampling | 0.07189 | 0.09929 | 0.626 | 20.00% | 7.86% | 0.01045 | 0.09979 | 341.5 |
| C - Full-horizon hold | 0.06048 | 0.07652 | 0.613 | 22.80% | 7.31% | 0.00708 | 0.07065 | 230.6 |

False-safe is PINN>0 and reference<=0, divided by the number of reference-unsafe states. A lower false-safe rate can accompany excessive unsafe predictions, so value error, false-unsafe rate and IoU must also be considered. The reference is approximate; its original refinement/boundary checks are recorded with Experiment 1.

![Paired comparison](comparison.png)

## Outcome

A has the lowest final-horizon value MAE, false-safe rate and disagreement, and the highest IoU among these candidates. Its terminal MAE rises from .00891 to .01457 m, and its false-unsafe rate rises from 3.43% to 8.33%. C has lower value MAE and terminal error than B, while B has fewer missed reference-unsafe states and higher IoU than C. The results support further testing of the lower terminal weight at this scale, without assuming it will generalize to other seeds or larger runs.

- A - Loss weight: value MAE changed -51.1% and false-safe rate changed -35.60 percentage points against Experiment 1.
- B - Focused sampling: value MAE changed -21.4% and false-safe rate changed -26.42 percentage points against Experiment 1.
- C - Full-horizon hold: value MAE changed -33.9% and false-safe rate changed -23.62 percentage points against Experiment 1.

These results establish only what happened for seed 7 and these particular settings. They do not isolate seed variability, prove any method universally superior, or demonstrate paper-scale reproduction. A and B each modify one setting; C tests additional compute without changing its baseline loss or sampling. A combined variant was not run.

## Saved data

- comparison.json and comparison.csv contain aggregate data for all variants and the baseline.
- baseline_diagnostics.json records the pre-run value/loss checks.
- manifest.json records source/config/cache hashes, run paths, checkpoint hashes and execution metadata.
- source/ preserves the executed Python files, three candidate configurations and the tiny verification script. checks.json records the implementation checks; execution.json records the observed VS Code launch. hardware_during_run.json records the memory/device observation.
- Each variant run folder contains its checkpoint, config, history, environment, validation metrics and plots.
- See PLAN.md for the predefined settings and status.json for pipeline completion.
- Raw checkpoints, training logs and reference arrays are saved locally. No GitHub upload is performed by this experiment script.

import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path
import torch

sys.path.insert(0,str(Path('outputs/deepreach').resolve()))
from deepreach import sample, train, load_checkpoint

c=json.loads(Path('outputs/deepreach/configs/cpu.json').read_text())
torch.set_num_threads(2)
spec=importlib.util.spec_from_file_location('original_training',Path('outputs/deepreach/runs/air3d_cpu_20261022/source/deepreach.py'))
old=importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
torch.manual_seed(12); a=old.sample(c,4096,.5,256,'cpu')
torch.manual_seed(12); b=sample(c,4096,.5,256,'cpu',focus=True)
assert torch.equal(a,b)
focused=dict(c,focus_fraction=.5,focus_radius=1.)
torch.manual_seed(12); q=sample(focused,4096,.5,256,'cpu',focus=True)
nf=(4096-256)//2
r2=(q[:nf,1:3]**2).sum(-1)
assert float(r2.max())<=1. and abs(float(r2.mean())-.5)<.03
assert torch.equal(q[-256:],a[-256:]) and torch.equal(q[:,0],a[:,0]) and torch.equal(q[:,3],a[:,3])
torch.manual_seed(12); pre=sample(focused,4096,0,4096,'cpu',focus=False)
torch.manual_seed(12); pre0=old.sample(c,4096,0,4096,'cpu')
assert torch.equal(pre,pre0)
tiny=dict(c,width=16,samples=64,terminal_samples=8,pretrain_steps=2,curriculum_steps=3,log_every=20,save_every=20)
with tempfile.TemporaryDirectory(dir='work',prefix='exp2_checks_') as temp:
    root=Path(temp)
    train(tiny,root/'base')
    saved=hashlib.sha256((root/'base/checkpoint.pt').read_bytes()).hexdigest()
    hold=dict(tiny,full_horizon_steps=2)
    full=train(hold,root/'continuous')
    split=train(hold,root/'extended',extend_from=root/'base/checkpoint.pt')
    difference=max(float((x-y).abs().max()) for x,y in zip(full.parameters(),split.parameters()))
    assert difference==0
    _,ck=load_checkpoint(root/'extended/checkpoint.pt')
    assert ck['step']==7 and ck['curriculum_step']==3 and ck['full_horizon_step']==2
    assert ck['inherited_training_seconds']>0 and ck['additional_training_seconds']>0
    assert hashlib.sha256((root/'base/checkpoint.pt').read_bytes()).hexdigest()==saved
    try:
        train(dict(hold,lr=.001),root/'bad',extend_from=root/'base/checkpoint.pt')
        raise AssertionError('Extension accepted a different optimizer learning rate')
    except ValueError:
        pass
    train(tiny,root/'weight1',stop_after=3)
    train(dict(tiny,terminal_weight_factor=.1),root/'weight01',stop_after=3)
    _,w1=load_checkpoint(root/'weight1/checkpoint.pt'); _,w01=load_checkpoint(root/'weight01/checkpoint.pt')
    assert abs(w01['terminal_weight']/w1['terminal_weight']-.1)<1e-12
result=dict(default_sampler_matches_experiment1=True,terminal_sampling_unchanged=True,focused_disk_r2_mean=float(r2.mean()),
            focused_support_max_radius=float(r2.max().sqrt()),extension_equals_continuous_parameter_max_abs=difference,
            extension_rejects_other_config_changes=True,baseline_checkpoint_unchanged=True,terminal_weight_factor_verified=True,
            note='Tiny optimizer schedule tests only; these are not the candidate experiment runs.')
Path('outputs/deepreach/experiments/experiment_2/checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

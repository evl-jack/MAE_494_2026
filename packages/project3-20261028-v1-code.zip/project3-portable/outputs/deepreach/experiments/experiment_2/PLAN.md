# Experiment 2 — predefined controlled comparison

Authorized 22 October 2026: test all three candidates and compare their data, using VS Code. No paper-scale run and no combined variant are included.

Common settings: Air3D as Experiment 1, seed 7, three sine hidden layers of width 64, 2048 inputs per step, lr=1e-4, .5 s horizon, [-2,2] m box, two CPU threads. Reuse Experiment 1's checked grid and exactly the same held-out distributions. No reference labels enter training. Preserve Experiment 1's checkpoint and grid and verify their hashes afterward.

1. A — Loss weighting: fresh 2000 + 10000 step run; initial terminal multiplier divided by 10, then fixed. This tests one lower terminal weight, not adaptive weighting or a sweep.
2. B — Focused sampling: fresh 2000 + 10000 step run; 50% of nonterminal physics points drawn uniformly by area within radius 1 m and 50% uniformly in the original box. Terminal/pretraining samples stay uniform. The disk radius follows R+2*v*T=1 m. This changes the physics-training distribution deliberately, without importance correction.
3. C — Full-horizon hold: fork the exact Experiment 1 model, Adam and RNG state; add 10000 updates with time sampled uniformly over [0,.5] s. Preserve the original loss weight and uniform sampling. Counts are 10000 new steps / 22000 cumulative. Additional and inherited training costs are recorded separately.

Before running, check backward-compatible sampling, focus support/distribution, extension/restart behavior on tiny configs, and reproduction of baseline metrics with the cache. Numerical diagnostics and code checks do not substitute for accuracy comparisons.

Record each config, checkpoint, optimizer state, history, runtime, source hashes, held-out terminal/VI/value errors, BRT IoU, false-safe and false-unsafe rates, and plots at 0/.25/.5 s. Compare all three with Experiment 1. Lower false-safe alone is not sufficient if false-unsafe or value errors worsen. Results are single-seed exploratory evidence, not safety guarantees.

# Conclusions from the small-scale Air3D study

Consolidated 28 October 2026. This summary groups the work into **Experiment 1: baseline**, **Experiment 2: initial controlled modifications**, and **Experiment 3: constrained formulation, diagnostics and refinements (3A–3E)**. Individual saved experiment IDs are retained. The final evaluation is a separate confirmation of fixed models, not another training experiment.

## Overall finding

We implemented and evaluated a small, physics-trained neural reachability model for Air3D on a laptop. We substantially improved the original baseline by changing loss balance, building known conditions into the output, and later increasing the training budget. The final improvement carried over to previously unused states. We reproduced the core neural-reachability workflow, **not paper-scale DeepReach performance or a certified drone controller**.

The strongest conclusion is that **formulation, optimization progress and evaluation design all matter**. Additional steps and capacity helped in the tested runs, but neither lower physics loss nor an appealing mathematical modification reliably predicted better value accuracy on its own.

The game is planar motion with three relative states, x, y and heading difference; time-to-go is an additional network input. It is not a full 3D-flight quadrotor model. Dynamics enter the HJI physics loss. Numerical-reference values guide evaluation and experimental interpretation, but were not supervised targets or reference-derived value bounds in training.

## Experiment 1 — Establishing the reduced baseline

**Question:** Could a small CPU model implement the Air3D neural-reachability workflow, and how accurate would it be?

We trained a three-hidden-layer sine network of width 64, with 8,705 parameters, 2,000 terminal-only steps and 10,000 curriculum physics steps. An independently implemented grid solver supplied an approximate evaluation reference; derivative, Hamiltonian, reference-refinement and checkpoint checks were retained.

At .5 s, development value MAE was **.09150 m**, unsafe-set IoU **.478**, and **46.42% of reference-unsafe states were predicted safe**. Error increased substantially with look-ahead: MAE was .04230 m at .25 s and .09150 m at .5 s.

**Conclusion:** The implementation and reproducible training/evaluation pipeline worked, but successful execution and falling training loss did not establish an accurate reachability solution. The reduced baseline was inadequate for safety decisions. Longer-horizon approximation was particularly difficult.

This experiment did not isolate whether network capacity, sample budget, loss balance or another factor was the dominant cause. The PINN queries the value directly at each horizon; the horizon-error curve is not numerical integration error accumulating inside the network. [Experiment 1 evidence](experiment_1/README.md).

## Experiment 2 — Three initial modifications

**Question:** Could we improve the baseline without immediately moving to paper-scale training?

| Candidate | Tested change | MAE at .5 s [m] | False-safe / reference-unsafe | Finding |
|---|---|---:|---:|---|
| Original baseline | Unchanged | .09150 | 46.42% | Starting point |
| 2A | Terminal-loss multiplier divided by 10 | **.04477** | **10.82%** | Strongest of the three |
| 2B | Spatially focused physics sampling | .07189 | 20.00% | Improved baseline, less than 2A |
| 2C | 10,000 extra full-horizon steps | .06048 | 22.80% | Improved baseline, less than 2A |

**2A: Loss balance mattered.** With the same update schedule and architecture, reducing the terminal multiplier cut value MAE by **51.1%**. However, terminal error rose from .00891 to .01457 m, and false-unsafe/reference-safe rose from 3.43% to 8.33%. We improved overall reference agreement while changing the balance of optimistic and conservative errors. The lower terminal weight was not a universal improvement to every metric.

**2B: Focused sampling helped this baseline, but was not the strongest intervention.** MAE fell 21.4%. Changing its first physics batch also changed the automatically calibrated terminal multiplier from 106.43 to 125.35. The outcome therefore does not isolate sampling independently of that induced loss-weight change.

**2C: More training helped, but did not compensate for the original formulation as well as 2A.** MAE fell 33.9% after doubling the physics steps from 10,000 to 20,000 (22,000 total updates including pretraining). This was an additional-compute trial, not a fixed-budget improvement.

**Conclusion:** A useful improvement was available without more optimizer steps: loss balance deserved attention before scaling. More training and spatial focus also improved the original baseline, but neither was universally superior. A/B had matched update budgets, not controlled equal wall time. These were separate candidates, not a combined method. [Experiment 2 evidence](experiment_2/README.md).

## Experiment 3 — Formulation, diagnostics and refinement

### 3A: Build known terminal and obstacle conditions into the output

We changed the output to `V = l - .25*(tau/T)*g²`. This enforces V(0)=l and V<=l, so initially collided states cannot be labeled safe. Terminal-only pretraining becomes unnecessary; zero-time physics samples remain in the loss.

With the same 10,000 physics updates as 2A, development MAE fell **.04477 to .02602 m**, a **41.87% reduction**. IoU increased .688 to .799, false-unsafe rate decreased 8.33% to 7.10%, and no false-safe cases were observed.

**Conclusion:** The constraint-enforcing formulation was our strongest tested improvement without increasing physics-update count. Known analytic structure can remove specific violations and make the remaining learning problem more effective. The comparison also changes initialization and removes 2,000 terminal-pretraining steps, so it does not isolate the output formula independently of every training-history effect.

Part of the classification benefit is guaranteed by construction for already-collided states; zero observed false-safe cases are not independent proof of global boundary or control accuracy. The construction does not enforce V>=-R, heading periodicity or horizon monotonicity. [3A evidence](experiment_3_a/RESULTS.md).

### 3B: Periodic heading fixed one defect but worsened overall accuracy

Sine/cosine heading features reduced equivalent-heading mismatch to numerical precision, and the fixed old worst-240 cohort improved **26.02%**. However, overall MAE rose **.02602 to .03517 m**, a **35.14% regression**, and false-unsafe rate rose to 9.52%.

**Conclusion:** Enforcing the correct periodic representation does not automatically yield a more accurate learned value function at a fixed budget. Improving selected outliers is not enough to establish an overall improvement. This single run does not show periodic encoding is generally inferior; initialization/features and optimization interact. [3B evidence](experiment_3_b/RESULTS.md).

### 3C: More late-horizon exposure was not sufficient

A 50/50 full-horizon/curriculum time mixture increased late-time exposure without adding updates. Overall MAE rose **.02602 to .02996 m**, **15.14% worse**, at the final horizon; all 20 nonzero horizons worsened. The old worst-240 cohort improved 10.35%, but the new model's own worst tail worsened.

**Conclusion:** The chosen late-time mixture was not an effective fixed-budget fix. Horizon-dependent error cannot simply be equated with insufficient late-time samples. It does not establish that every time-sampling strategy would fail. [3C evidence](experiment_3_c/RESULTS.md).

### 3D: Local diagnostics exposed limitations of loss and optimizer-based decisions

The short refinement comparison favored ordinary **Adam +200**, with MAE **.02282 m**, 12.31% below 3A. Controlled plain/scaled directions reduced audit physics loss about 32%, but improved MAE only 3–4%. Adam +800 had lower physics loss than +200 but worse value accuracy.

Further diagnosis showed:

- The original worst outliers had strong parameter-learning signals; vanishing gradients were not established as their main bottleneck.
- Errors were highly uneven: in 3A, the pursuer-ahead half contained 96.96% of squared error. This is a conditional pattern, not proof that x alone causes the error.
- About 94% of the controlled audit-loss reduction came from outside the smaller value-comparison region. Inside it, residuals improved too, but less.
- At Adam +200, focused geometry/time weighting lowered selected physics losses but **none of 72 weighted probes improved final-time MAE**. Unweighted controls also failed there.
- At fixed Adam +200 parameters, all **160 optimizer-history probes** lowered audit physics loss while none improved final-time MAE. Suppressing momentum, fresh Adam and plain gradients did not remove the local conflict.

**Conclusion:** Physics residual is necessary training information, but its sampled magnitude is not a direct value-error bound or a reliable model-selection score by itself. Region/time coverage matters, yet distribution differences do not explain every local mismatch. Stale Adam momentum alone was not a sufficient explanation.

These probes concern **gradients with respect to network parameters**, not the accuracy of state-value gradients used to steer drones. They were not a controller-gradient evaluation. No trust-region or L-BFGS training result was established. The finite probes do not exhaust possible directions or predict a long changing optimization trajectory. [3D evidence](experiment_3_d_refinement/RESULTS.md), [geometry/time probe](experiment_3_d_refinement/geometry_horizon_probe/README.md), [optimizer-history probe](experiment_3_d_refinement/optimizer_history_probe/README.md).

### 3E: Additional duration and capacity both helped

We compared a width-64 continuation to **22,000 total steps** with a fresh width-96 network at **10,000 steps**. The wider model's physical sampling sequence matches original 3A throughout its curriculum. Final development outcomes were:

| Candidate | MAE at .5 s [m] | Improvement over Adam +200 |
|---|---:|---:|
| Adam +200, width 64 | .02281836 | — |
| Width 64, 22,000 steps | **.01985405** | **12.99%** |
| Width 96, 10,000 steps | .02126600 | 6.80% |

The duration trajectory was not monotonic: MAE was .025648 at 12,000 steps and .023200 at 16,000, before reaching .019854 at 22,000. The early local probes did not predict this later improvement.

**Conclusion:** Additional compute helped in both tested forms, and the longer narrow run won this comparison. The earlier local mismatch did not establish a training ceiling. This supports deliberate budget increases, not the stronger claim that more training is strictly necessary or always improves accuracy.

The two main new runs were within 1% by a nominal linear MAC proxy, **not exact training FLOPs or wall time**. Cumulative times were approximately 418 s for Long64 (including historical 3A training) and 604 s for Wide96. Width changes initialization, and the longer run adds full-horizon exposure. One seed cannot prove that capacity alone explains the wider model's improvement. [3E evidence](experiment_3_e_capacity_budget/RESULTS.md).

## Final evaluation — The selected improvement carried over

After fixing the three checkpoint hashes and protocol, we evaluated **24,000 previously unused states** at all 21 horizons, without training or tuning.

| Fixed model | Final-set MAE at .5 s [m] | Unsafe-set IoU | False-unsafe / reference-safe |
|---|---:|---:|---:|
| Original 3A | .02628533 | .79701 | 7.008% |
| Adam +200 | .02297716 | .81636 | 6.190% |
| Long22000 | **.02008032** | **.84239** | **5.149%** |

Long22000 improves final-time MAE **12.61%** versus Adam +200, with a paired 95% bootstrap interval of **11.93%–13.25%**. It improves MAE at all 20 nonzero horizons. Its improvement over original 3A is 23.61%. These final-set values must not be mixed into the development table as though they used the same states.

No false-safe cases were observed at the nonzero horizons against the approximate reference. The maximum final-time error remains **.26455 m**, and the model retains conservative errors, lower-value-bound violations and horizon-monotonicity defects. The bootstrap quantifies state-sampling uncertainty conditional on these trained models and reference, not training-seed or numerical-reference uncertainty.

**Conclusion:** The development improvement carried over to new states in this same Air3D domain and horizon. It is not merely a gain on the original development points. The final set is now consumed and cannot serve as untouched evidence after further tuning. [Frozen final evaluation](../evaluation/final_evaluation_20261028/README.md).

## Conclusions we can defend

1. A small CPU network can learn a useful approximation of this Air3D reachability problem, but the first working implementation was inaccurate.
2. Loss balance and analytic output constraints produced substantial gains before increasing the physics-update budget.
3. Mathematical consistency, selected-outlier improvements and lower sampled residuals must be checked against overall value and classification metrics; none alone establishes a better model.
4. Short local optimization results cannot establish an accuracy ceiling. A longer trajectory eventually improved after intermediate regressions.
5. Both longer training and increased width improved this study's development accuracy; the selected longer model's advantage survived the reserved final evaluation.
6. The resulting value approximation remains imperfect. Accurate classification on sampled states does not establish reliable gradient-derived controls or guaranteed safety.

## Questions this study has not resolved

- Which findings repeat across training seeds, other budgets or different game parameters?
- Would periodic features work better with different initialization, capacity or training duration?
- What weightings or objectives reliably align residual reduction with value accuracy across an entire trajectory?
- How accurate are state-value gradients, and do their resulting control decisions work in closed-loop games?
- Which methods transfer to a separately specified/trained 6D game?
- Can physical bounds or uncertainty/error certification improve reliability without excessive conservatism?

Hybrid reference-supervised training, a two-network safe/direction architecture, formal trust-region training and a 6D experiment were discussed but not established by the saved experiments. We should not present them as implemented results.

All headline method comparisons are single-seed development results unless explicitly labeled final evaluation. The numerical grid is an approximate independent comparator. We did not establish paper-scale DeepReach accuracy, a guaranteed uniform value bound, certified control directions or real-world drone safety.

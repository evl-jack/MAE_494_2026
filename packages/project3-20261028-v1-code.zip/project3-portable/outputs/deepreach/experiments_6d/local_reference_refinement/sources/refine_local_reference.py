"""Fixed reference-resolution audit on the consumed shared development failure.

No training, model changes, new rollout policies or final-test queries.
"""
import argparse
import gc
import json
import shutil
import time
from pathlib import Path

import numpy as np
import torch
import evaluate as ev
import rollouts as ro
import diagnose_shared_failure as diag

HERE=Path(__file__).resolve().parent
OUT=HERE/'local_reference_refinement'
GRIDS=[(129,96),(161,120),(193,144)]
SOURCES=[Path(__file__),HERE/'diagnose_shared_failure.py',HERE/'rollouts.py',HERE/'evaluate.py',
         HERE/'network.py',ev.ROOT/'reference.py',ev.ROOT/'joint6d.py',ev.ROOT/'deepreach.py']


def prepare():
    if OUT.exists():raise FileExistsError('Reference refinement already prepared')
    OUT.mkdir();(OUT/'sources').mkdir()
    protected={str(p.relative_to(ev.ROOT)):ev.sha(p) for p in ev.ROOT.rglob('checkpoint*.pt')}
    for path in [diag.OUT/'trace_4C_0.005_learned.npz',diag.OUT/'initial_state.npz',
        diag.OUT/'initial_gradients.json',ev.ROOT/'evaluation/reserved_final_states/states.npz']:
        protected[str(path.relative_to(ev.ROOT))]=ev.sha(path)
    protocol=dict(status='frozen before refined solves and new neighborhood queries',date='2026-10-28',
        case='Group 603 only, selected after earlier development failure; not independent validation',
        grids=[list(g) for g in GRIDS],domain=2.,times=np.linspace(0,.5,21).tolist(),
        solver='Unchanged first-order local Lax-Friedrichs; CFL .8; jointly refine spatial, angular and CFL-limited time discretization',
        physical_config=dict(domain=2.,horizon=.5,speed=.75,turn=3.,radius=.25),
        baseline='Rebuild 129x129x96 and match saved early trajectory fine values and coefficients within 1e-12',
        path='Saved unassisted 4C canonical-pose trajectory, elapsed 0:.005:.1; actual states fixed across grids',
        heading_offsets=np.linspace(-.2,.2,201).tolist(),
        heading_perturbation='Change only physical evader heading; keep pursuer and both positions fixed, then reduce to relative coordinates',
        primary='Initial evader coefficient sign and magnitude versus grid; report disagreement rather than claiming convergence from one comparison',
        secondary=['Early matched-state coefficient/value traces','Heading-offset by elapsed-time local switching map',
                   'Initial learned 4C/3D_Long coefficients across equivalent poses',
                   'Derivative of interpolated values at eps 1e-5 and 1e-6; distinct from interpolated central-grid gradients',
                   'Left/right value secants at heading offsets .002,.005,.01,.02,.04'],
        derivative_epsilons=[1e-5,1e-6],secant_widths=[.002,.005,.01,.02,.04],
        coefficient_margins=[.005,.01,.02],
        interpolation='Same spatial trilinear and time-linear interpolation as prior reference policy; no new policy rollout',
        prohibited='No adaptive grid search, changing the solver scheme, training, model selection, new rollout intervention or final data use',
        execution='Managed process with main project interpreter; no claim of VS Code debugger execution',
        source_hashes={p.name:ev.sha(p) for p in SOURCES},protected_inputs=protected,
        training=False,optimizer_created=False,threads=2,full_reference_grids_retained=False)
    ev.dump(OUT/'protocol.json',protocol)
    for p in SOURCES:shutil.copy2(p,OUT/'sources'/p.name)
    print('Three reference levels and fixed neighborhood frozen; no new queries generated.',flush=True)


def shifted(z,delta):
    out=np.repeat(z[None,:],len(delta),axis=0)
    out[:,5]+=delta
    return out


def query(ref,path,times,offsets):
    feedback=ro.ReferenceControl(ref);value=diag.ReferenceValue(ref)
    values=[];coefficients=[]
    for z,elapsed in zip(path,times):
        joints=shifted(z,offsets);r=ro.relative(joints);tau=.5-float(elapsed)
        g=feedback.gradient(tau,r)
        coefficients.append(np.stack([r[:,1]*g[:,0]-r[:,0]*g[:,1]-g[:,2],g[:,2]],axis=-1))
        values.append(value.value(tau,r))
    initial=path[0];value0=float(value.value(.5,ro.relative(initial[None]))[0])
    derivative_rows=[]
    for h in [1e-5,1e-6,.002,.005,.01,.02,.04]:
        rr=ro.relative(shifted(initial,np.array([-h,h])))
        vm,vp=value.value(.5,rr)
        derivative_rows.append(dict(width=h,value_minus=float(vm),value_center=value0,value_plus=float(vp),
            left_secant=float((value0-vm)/h),right_secant=float((vp-value0)/h),central_secant=float((vp-vm)/(2*h))))
    feedback.plane.cache_clear();value.plane.cache_clear()
    return np.stack(values),np.stack(coefficients),derivative_rows


def helper_checks():
    # Analytic affine function verifies the nonlinear joint-to-relative direction.
    x=np.linspace(-2,2,9);th=np.linspace(-np.pi,np.pi,16,endpoint=False)
    xx,yy,hh=np.meshgrid(x,x,th,indexing='ij')
    v=2*xx-3*yy+4*hh
    # No angle-cut query: the affine theta fixture is local, not periodic globally.
    ref=dict(x=x,theta=th,dx=.5,dtheta=2*np.pi/16,values={0.:v,.5:v})
    z=np.array([.4,.2,.3,0,0,.1]);r=ro.relative(z[None])[0]
    values,co,rows=query(ref,z[None],np.array([0.]),np.array([0.]))
    expected=2*r[1]+3*r[0]-4
    assert abs(co[0,0,0]-expected)<1e-12
    assert abs(rows[0]['central_secant']-expected)<1e-8
    assert abs(rows[1]['central_secant']-expected)<1e-8
    return dict(status='passed',directional_coefficient_error=float(abs(co[0,0,0]-expected)),
                value_interpolant_fd_error=float(abs(rows[1]['central_secant']-expected)))


def run(resume=False):
    p=json.loads((OUT/'protocol.json').read_text())
    if (OUT/'manifest.json').exists():raise FileExistsError('Completed reference audit is immutable')
    if (OUT/'status.json').exists() and not resume:raise FileExistsError('Use explicit resume for unchanged fixed audit')
    assert p['source_hashes']=={s.name:ev.sha(s) for s in SOURCES}
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    torch.set_num_threads(2);start=time.perf_counter();checks=helper_checks()
    with np.load(diag.OUT/'trace_4C_0.005_learned.npz') as old:
        mask=old['times']<=.100000001
        times=old['times'][mask];path=old['states'][mask,0]
        old_values=old['fine_values'][mask,0];old_co=old['fine_coefficients'][mask,0]
    with np.load(diag.OUT/'initial_state.npz') as f:initial=f['joint']
    offsets=np.array(p['heading_offsets']);zero=int(np.argmin(abs(offsets)))
    assert offsets[zero]==0
    np.savez_compressed(OUT/'fixed_queries.npz',elapsed_times=times,joint_path=path,heading_offsets=offsets,initial_poses=initial)
    # Numerical region dependency bound on these fixed early-state neighborhoods.
    maximum_bound=max(float(np.linalg.norm(ro.relative(shifted(z,offsets))[:,:2],axis=1).max())+1.5*(.5-t)
                      for z,t in zip(path,times))
    assert maximum_bound<2
    summaries=[]
    for n,nh in GRIDS:
        artifact=OUT/f'reference_{n}_{nh}.npz';metadata=OUT/f'reference_{n}_{nh}.json'
        if artifact.exists() and metadata.exists():
            info=json.loads(metadata.read_text());assert ev.sha(artifact)==info['queried_output_sha256']
            summaries.append(info);print(f'Reusing verified completed grid {n}x{n}x{nh}.',flush=True);continue
        ev.dump(OUT/'status.json',dict(status='solving fixed reference level',grid=[n,n,nh],training=False))
        print(f'Solving fixed level {n}x{n}x{nh}; no training.',flush=True)
        clock=time.perf_counter();ref=ev.solve(p['physical_config'],n,nh,p['times'])
        seconds=time.perf_counter()-clock
        values,coefficients,secants=query(ref,path,times,offsets)
        if n==129:
            value_error=float(abs(values[:,zero]-old_values).max())
            coefficient_error=float(abs(coefficients[:,zero]-old_co).max())
            assert value_error<1e-12 and coefficient_error<1e-12
        else:value_error=None;coefficient_error=None
        np.savez_compressed(artifact,elapsed_times=times,heading_offsets=offsets,values=values,coefficients=coefficients)
        info=dict(grid=[n,n,nh],seconds=seconds,steps=ref['steps'],dx=ref['dx'],dtheta=ref['dtheta'],dtmax=ref['dtmax'],
            initial_value=float(values[0,zero]),initial_evader_coefficient=float(coefficients[0,zero,0]),
            initial_pursuer_coefficient=float(coefficients[0,zero,1]),
            initial_value_secants=secants,old_value_max_abs=value_error,old_coefficient_max_abs=coefficient_error,
            queried_output_sha256=ev.sha(artifact))
        ev.dump(metadata,info);summaries.append(info)
        print(json.dumps(dict(grid=info['grid'],seconds=seconds,value=info['initial_value'],
            evader_coefficient=info['initial_evader_coefficient'],interpolant_derivative=secants[1]['central_secant'])),flush=True)
        del ref;gc.collect()
    ev.dump(OUT/'status.json',dict(status='querying fixed trained models',training=False))
    models=ro.load_models();learned=[]
    for name in ['4C','3D_Long']:
        original={k:v.clone() for k,v in models[name].state_dict().items()}
        for pose,z in enumerate(initial):
            joints=shifted(z,offsets);v,co=diag.model_diagnostics(name,models[name],.5,joints)
            np.savez_compressed(OUT/f'learned_heading_cut_{name}_{pose}.npz',heading_offsets=offsets,values=v,coefficients=co)
            learned.append(dict(model=name,pose=pose,initial_value=float(v[zero]),initial_evader_coefficient=float(co[zero,0])))
        assert all(torch.equal(v,models[name].state_dict()[k]) for k,v in original.items())
        assert all(p.grad is None for p in models[name].parameters())
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    assert p['source_hashes']=={s.name:ev.sha(s) for s in SOURCES}
    ev.dump(OUT/'manifest.json',dict(status='completed fixed local reference refinement',training=False,parameter_updates=0,
        optimizer_created=False,models_unchanged=True,protected_inputs_unchanged=True,old_final_states_queried=False,
        grids=summaries,learned=learned,protocol_sha256=ev.sha(OUT/'protocol.json'),helper_checks=checks,
        maximum_radius_dependency_bound=maximum_bound,seconds_this_execution=time.perf_counter()-start,
        execution=p['execution']))
    ev.dump(OUT/'status.json',dict(status='completed',training=False))
    print('All fixed levels completed; no model update or policy rollout.',flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--evaluate',action='store_true');ap.add_argument('--resume',action='store_true')
    args=ap.parse_args()
    if args.prepare==args.evaluate:ap.error('Choose exactly one of --prepare or --evaluate')
    prepare() if args.prepare else run(args.resume)

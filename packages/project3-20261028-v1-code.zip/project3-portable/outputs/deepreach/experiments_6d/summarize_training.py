"""Summarize completed fixed-budget runs; no training or reference evaluation."""
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch

HERE = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def summarize():
    torch.set_num_threads(2)
    records = {}
    physics_states = {}
    frozen = json.loads((HERE/'training_manifest.json').read_text())
    for name, expected in frozen['files'].items():
        assert sha(Path(name)) == expected
    fig, ax = plt.subplots(figsize=(9, 5))
    for label in ('4A', '4B', '4C'):
        folder = HERE/'runs'/label
        ck = torch.load(folder/'checkpoint.pt', map_location='cpu', weights_only=True)
        c = json.loads((HERE/f'configs/{label}.json').read_text())
        assert ck['config'] == c
        total = c['pretrain_steps']+c['curriculum_steps']+c['full_horizon_steps']
        assert ck['step'] == total
        physics_states[label] = ck['sampler']['physics']
        for name, expected in ck['sources'].items():
            assert sha(folder/'sources'/name) == expected
        assert all(torch.isfinite(v).all() for v in ck['model'].values())
        with (folder/'history.csv').open() as f:
            rows = list(csv.DictReader(f))
        assert int(rows[-1]['step']) == total
        for row in rows:
            for name in ('tmax', 'terminal_mae', 'vi_mae', 'loss', 'elapsed_seconds'):
                assert torch.isfinite(torch.tensor(float(row[name])))
        physics = [r for r in rows if r['phase'] != 'terminal']
        if label == '4C':
            physics = [r for r in physics if int(r['step']) > 10000]
        ax.plot([int(r['step'])-c['pretrain_steps'] for r in physics],
                [float(r['vi_mae']) for r in physics], label=label, linewidth=1.2)
        parent = ck['parent']
        if label == '4C':
            assert parent['sha256'] == sha(HERE/'runs/4B/checkpoint.pt')
            assert parent['step'] == 10000
        records[label] = dict(completed_updates=total, terminal_only_updates=c['pretrain_steps'],
            cumulative_physics_updates=total-c['pretrain_steps'],
            cumulative_update_seconds=ck['elapsed_seconds'],
            additional_update_seconds=ck['elapsed_seconds']-(parent['elapsed_seconds'] if parent else 0),
            fixed_terminal_weight=ck['terminal_weight'], final_batch=ck['last_metrics'], parent=parent,
            checkpoint_sha256=sha(folder/'checkpoint.pt'),
            checkpoint_bytes=(folder/'checkpoint.pt').stat().st_size,
            execution=json.loads((folder/'execution.json').read_text()),
            environment=ck['environment'], source_hashes=ck['sources'])
    ax.set(xlabel='Cumulative physics updates', ylabel='Sampled batch VI mean absolute residual',
           title='6D training histories — accuracy evaluation remains separate', yscale='log')
    ax.legend(); ax.grid(alpha=.25); fig.tight_layout()
    fig.savefig(HERE/'training_history.png', dpi=160); plt.close(fig)
    protected = json.loads((HERE/'protected_before_training.json').read_text())
    assert all(sha(Path(name)) == expected for name, expected in protected.items())
    assert torch.equal(physics_states['4A'], physics_states['4B'])
    result = dict(status='all three fixed-budget runs completed', runs=records,
        previous_checkpoints_and_final_states_unchanged=True,
        numerical_reference_evaluation_performed=False, new_evaluation_data_generated=False,
        final_states_used=False, hardware=json.loads((HERE/'hardware_before_training.json').read_text()),
        matched_4a_4b_physics_stream_end_states=True, frozen_sources_and_configs_unchanged=True,
        summary_source_sha256=sha(Path(__file__)))
    (HERE/'training_results.json').write_text(json.dumps(result, indent=2)+'\n')
    lines = ['# Experiment 4 — 6D training completed', '',
             'The three predefined runs completed in VS Code using the main project interpreter and output folders. No numerical-reference evaluation, control evaluation or new evaluation dataset was created in this training phase.', '',
             '| Run | Completed updates | Cumulative physics updates | Added update time | Last sampled VI MAE |',
             '|---|---:|---:|---:|---:|']
    for label, r in records.items():
        lines.append(f"| {label} | {r['completed_updates']:,} | {r['cumulative_physics_updates']:,} | {r['additional_update_seconds']:.1f} s | {r['final_batch']['vi_mae']:.6f} |")
    lines += ['', '4C inherits 4B, so their cumulative update counts must not be added as independent training. Update times exclude checkpoint/log I/O, debugger startup and process setup; they are not full wall-clock timings. Last-batch residuals describe training batches and are not prediction-error or safety metrics. 4A has a soft terminal penalty; 4B/4C enforce terminal and obstacle constraints through their output.', '',
              '![Training histories](training_history.png)', '',
              'Checkpoint hashes, parent identity, configurations, execution descriptions and environments are in [training_results.json](training_results.json). Source/configuration hashes were frozen before training. The parent 4B checkpoint and all protected 3D checkpoints/final-state bytes remain unchanged.', '',
              'Next: check and freeze a grouped development evaluation, then measure value accuracy, coordinate invariance and gradient/control quality against the reduced numerical reference. Training loss alone does not establish transfer quality from the 3D study.', '']
    (HERE/'TRAINING_RESULTS.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({k:{n:r[n] for n in ('completed_updates','additional_update_seconds','fixed_terminal_weight','final_batch')} for k,r in records.items()}, indent=2))


if __name__ == '__main__':
    summarize()

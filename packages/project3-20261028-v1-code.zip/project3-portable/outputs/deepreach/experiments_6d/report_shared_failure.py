"""Verify saved traces and report the fixed single-case interventions."""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import diagnose_shared_failure as diag
import rollouts as ro
import evaluate as ev


def verify_geometry(data):
    z=data['states'][0].copy()
    upper=np.linalg.norm(z[:,:2]-z[:,3:5],axis=-1);lower=upper.copy()
    first=np.where(upper<=.25,0.,np.inf);state_error=0.
    for i,action in enumerate(data['actions']):
        h=data['times'][i+1]-data['times'][i]
        u=action[:,0].astype(np.float64);d=action[:,1].astype(np.float64)
        m,lo,hit=ro.step_minimum(z,u,d,h)
        upper=np.minimum(upper,m);lower=np.minimum(lower,lo);first=np.minimum(first,data['times'][i]+hit)
        z=ro.advance(z,u,d,h)
        state_error=max(state_error,float(abs(z-data['states'][i+1]).max()))
    # Learned sign arrays can be float32 in the original diagnostic. Check exact
    # float64 arc replay separately rather than promising bitwise equivalence.
    assert state_error<1e-6
    assert np.array_equal(upper<=.25,data['definite_collision'])
    assert np.array_equal(lower<=.25,data['possible_collision'])
    return dict(maximum_state_replay_difference=state_error,
                maximum_minimum_distance_difference=float(abs(upper-data['minimum_distance_upper']).max()),
                contact_flags_match=True,minimum_distance_upper_float64=upper.tolist(),
                minimum_distance_lower_float64=lower.tolist())


def load_trace(name,dt,variant):
    path=diag.OUT/f'trace_{name}_{dt:.3f}_{variant}.npz'
    with np.load(path) as f:return {k:f[k].copy() for k in f.files}


def summarize(reuse_geometry=False):
    out=diag.OUT;p=json.loads((out/'protocol.json').read_text())
    assert p['source_hashes']=={src.name:ev.sha(src) for src in diag.SOURCES}
    rows=json.loads((out/'metrics.json').read_text());initial=json.loads((out/'initial_gradients.json').read_text())
    traces={};checks=[];handbacks=[]
    previous=None;previous_hashes=None
    if reuse_geometry:
        previous_hashes=json.loads((out/'output_manifest.json').read_text())['outputs']
        assert ev.sha(out/'geometry_replay.json')==previous_hashes['geometry_replay.json']
        previous=json.loads((out/'geometry_replay.json').read_text())
    for name in p['models']:
        for dt in p['control_time_steps']:
            for variant in p['variants']:
                data=load_trace(name,dt,variant['id']);traces[name,dt,variant['id']]=data
                if reuse_geometry:
                    filename=f"trace_{name}_{dt:.3f}_{variant['id']}.npz"
                    assert ev.sha(out/filename)==previous_hashes[filename]
                    check=next(c for c in previous if c['model']==name and c['dt']==dt and c['variant']==variant['id'])
                    checks.append(check)
                else:
                    check=verify_geometry(data);checks.append(dict(model=name,dt=dt,variant=variant['id'],**check))
                for pose in range(4):
                    stop=min(.5,float(data['first_sampled_collision_time'][pose]))
                    elapsed=data['times'][:-1]
                    width=np.maximum(0,np.minimum(data['times'][1:],stop)-elapsed)
                    fg=data['fine_coefficients'][:-1,pose,0];cg=data['coarse_coefficients'][:-1,pose,0]
                    mg=data['model_coefficients'][:-1,pose,0]
                    stable=(np.sign(fg)==np.sign(cg))&(abs(fg)>.01)&(abs(cg)>.01)
                    wrong=stable&(np.sign(mg)!=np.sign(fg))
                    after=(elapsed>=variant['duration']-1e-12)&(elapsed<stop)
                    wrong_after=np.flatnonzero(wrong&after)
                    hand_index=int(np.argmin(abs(data['times']-variant['duration'])))
                    both_negative=np.flatnonzero((data['fine_values'][:,pose]<0)&(data['coarse_values'][:,pose]<0))
                    handbacks.append(dict(model=name,dt=dt,variant=variant['id'],pose=pose,
                        pre_contact_reference_stable_wrong_sign_duration=float(width[wrong].sum()),
                        first_stable_wrong_sign_after_handback=float(elapsed[wrong_after[0]]) if len(wrong_after) else None,
                        learned_coefficient_at_handback=float(data['model_coefficients'][hand_index,pose,0]),
                        fine_coefficient_at_handback=float(data['fine_coefficients'][hand_index,pose,0]),
                        coarse_coefficient_at_handback=float(data['coarse_coefficients'][hand_index,pose,0]),
                        first_both_reference_values_negative=float(data['times'][both_negative[0]]) if len(both_negative) else None))
    for row in rows:
        data=traces[row['model'],row['dt'],row['variant']];pose=row['pose']
        assert row['definite_collision']==bool(data['definite_collision'][pose])
        assert row['possible_collision']==bool(data['possible_collision'][pose])
        assert row['sampled_minimum_distance']==float(data['minimum_distance_upper'][pose])
    ev.dump(out/'geometry_replay.json',checks)
    ev.dump(out/'handback_diagnostics.json',handbacks);ev.write_csv(out/'handback_diagnostics.csv',handbacks)
    # Same-state comparisons along the two baseline trajectories.
    fig,axes=plt.subplots(2,3,figsize=(14,8),layout='constrained')
    for row,name in enumerate(p['models']):
        data=traces[name,.005,'learned'];t=data['times'];pose=0
        first=float(data['first_sampled_collision_time'][pose])
        ax=axes[row,0]
        for key,label in [('model_values',name),('fine_values','fine reference'),('coarse_values','coarse reference')]:
            ax.plot(t,data[key][:,pose],label=label)
        ax.axhline(0,color='black',linestyle=':',linewidth=1)
        ax.set(title=name+': values on learned trajectory',xlabel='Elapsed time [s]',ylabel='Value [m]')
        ax=axes[row,1]
        for key,label in [('model_coefficients',name),('fine_coefficients','fine reference'),('coarse_coefficients','coarse reference')]:
            ax.plot(t,data[key][:,pose,0],label=label)
        ax.axhline(0,color='black',linestyle=':',linewidth=1)
        ax.set(title='Evader switching coefficient, same states',xlabel='Elapsed time [s]',ylabel='m/rad')
        ax=axes[row,2]
        for variant,label in [('learned','learned'),('initial_turn_5ms','5 ms initial turn'),('initial_turn_10ms','10 ms initial turn'),('initial_turn_25ms','25 ms initial turn'),('initial_turn_50ms','50 ms initial turn'),('reference_all','reference throughout')]:
            other=traces[name,.005,variant];z=other['states'][:,pose]
            ax.plot(other['times'],np.linalg.norm(z[:,:2]-z[:,3:5],axis=-1),label=label)
        ax.axhline(.25,color='red',linestyle='--',label='contact distance')
        ax.set(title='Fixed initial-turn interventions',xlabel='Elapsed time [s]',ylabel='Separation [m]')
        for ax in axes[row,:2]:
            if np.isfinite(first):ax.axvspan(first,.5,color='gray',alpha=.12)
        for ax in axes[row]:ax.grid(alpha=.2);ax.legend(fontsize=7)
    fig.savefig(out/'matched_state_and_interventions.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(2,1,figsize=(9,6),layout='constrained')
    for ax,name in zip(axes,p['models']):
        data=traces[name,.005,'learned'];t=data['times']
        ax.step(t[:-1],data['actions'][:,0,0],where='post',label='Applied learned turn')
        ax.step(t[:-1],3*np.sign(data['fine_coefficients'][:-1,0,0]),where='post',label='Reference turn at same state',alpha=.8)
        ax.set(title=name+' baseline, canonical pose',xlabel='Elapsed time [s]',ylabel='Turn [rad/s]',ylim=(-3.5,3.5))
        ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.savefig(out/'turning_trace.png',dpi=160);plt.close(fig)
    summary=[]
    for name in p['models']:
        for variant in p['variants']:
            subset=[r for r in rows if r['model']==name and r['dt']==.005 and r['variant']==variant['id']]
            summary.append(dict(model=name,variant=variant['id'],mode=variant['mode'],duration=variant['duration'],
                definite_contacts=sum(r['definite_collision'] for r in subset),
                possible_contacts=sum(r['possible_collision'] for r in subset),
                worst_sampled_minimum_distance=min(r['sampled_minimum_distance'] for r in subset)))
    ev.dump(out/'summary.json',summary)
    lines=['# Shared failure — fixed initial-turn diagnostic','',
        'This deliberately selected development encounter is group 603, already known to fail 4C and 3D_Long. Both models and all four poses were tested without training. The protocol fixed intervention durations before new traces or reference queries. This case study does not establish a general controller improvement.','',
        'The learned derivative computation passed finite differences: maximum discrepancy is 7.34e-11 for 4C and 5.23e-10 for 3D_Long. The models nevertheless choose the opposite initial evader turn from both reference grids. This is a discrepancy in the learned value surface relative to the references, rather than a detected autodiff implementation error.','',
        'A 5 ms initial-reference-turn correction fails for both models. Among the tested durations, 3D_Long first avoids contact after a 10 ms correction, whereas 4C first avoids contact after 50 ms. All four poses give the same contact outcomes, and those outcomes persist at both control intervals. Constant-initial-turn and reference-feedback prefixes give the same contact outcomes at every tested duration. These are the shortest successful tested durations, not measured exact thresholds.','',
        'Shorter assistance can worsen the outcome: for 4C the worst sampled minimum distance falls from 0.20127 m without assistance to 0.19121 m after 5 ms, 0.18127 m after 10 ms and 0.15246 m after 25 ms. At 50 ms it instead remains above 0.28724 m. The 3D model also worsens to 0.19121 m with 5 ms before escaping with 10 ms. Briefly applying a reference action is not a generally safe controller patch.','',
        'Reference resolution is a material limitation. The initial coarse/fine evader coefficients are -0.009707/-0.103665 m/rad: their signs agree but magnitudes differ by more than tenfold. The initial state passes the .005 margin and fails the .01 and .02 coarse/fine margins, so it was excluded from the earlier .01-margin turning-sign agreement statistic. On the unassisted trajectory, the two reference signs disagree at elapsed times .005, .010 and .015 s. We therefore cannot call this a fully resolved true-gradient comparison or infer a precise optimal switching boundary from these two grids.','',
        'Initial evader switching coefficients (positive selects +3 rad/s, negative selects -3 rad/s):','',
        '| Model | Pose | Learned coefficient | Coarse reference | Fine reference |',
        '|---|---:|---:|---:|---:|']
    for r in initial:
        lines.append(f"| {r['model']} | {r['pose']} | {r['learned_evader_coefficient']:.6f} | {r['coarse_evader_coefficient']:.6f} | {r['fine_evader_coefficient']:.6f} |")
    lines += ['',
        'The reference coefficients are approximate grid derivatives. Their coarse/fine agreement and magnitudes should be judged against the previously used 0.005, 0.01 and 0.02 m/rad margins; they are not an exact optimal-direction certificate. The separately saved double-precision finite-difference checks test the derivative of each learned function, rather than its agreement with the game solution.','',
        'Fixed interventions at dt=.005, over the same four posed initial states. Initial-turn prefixes hold the original reference initial turn; feedback prefixes recompute reference feedback during the prefix. The pursuer always reevaluates the same fine-reference feedback rule on the actual trajectory. After the prefix the original learned controller resumes.','',
        '| Model | Variant | Definite contacts / 4 | Possible contacts / 4 | Worst sampled minimum distance |',
        '|---|---|---:|---:|---:|']
    for r in summary:
        lines.append(f"| {r['model']} | {r['variant']} | {r['definite_contacts']} | {r['possible_contacts']} | {r['worst_sampled_minimum_distance']:.6f} m |")
    lines += ['',
        'At handback in the canonical pose, the corrected-path coefficients explain how the learned decision changes. Positive means the learned evader selects +3 rad/s; negative means -3 rad/s. These rows query all functions at the same corrected-path state.','',
        '| Model | Prefix | Learned coefficient at handback | Coarse reference | Fine reference |',
        '|---|---|---:|---:|---:|']
    for r in handbacks:
        if r['dt']==.005 and r['pose']==0 and r['variant'] in ['initial_turn_5ms','initial_turn_10ms','initial_turn_25ms','initial_turn_50ms']:
            lines.append(f"| {r['model']} | {r['variant']} | {r['learned_coefficient_at_handback']:.6f} | {r['coarse_coefficient_at_handback']:.6f} | {r['fine_coefficient_at_handback']:.6f} |")
    lines += ['',
        'For example, 4C returns to +3 rad/s after 25 ms (learned coefficient +0.07122) despite both references remaining negative (-0.13420/-0.17544), and contact follows. After 50 ms its coefficient is -0.02182, agreeing in sign with both references, and contact is avoided in this matchup. 3D_Long makes this sign transition by the tested 10 ms handback. The learned control transition is therefore misplaced relative to this reference-assisted path; the experiment does not yet identify why training produced that value surface.','',
        'Along the unassisted canonical trajectories, both reference values first become negative at elapsed time .145 s, before sampled contact near .39375 s. This is consistent with an early loss of estimated recoverability, but numerical value bias and the short-time reference-gradient disagreement limit any stronger claim.','']
    lines += ['',
        '![Values, matched-state coefficients and interventions](matched_state_and_interventions.png)','',
        'Each value/coefficient comparison uses the same actual learned-trajectory states, not different states from already diverged rollouts. Gray shading marks mathematical continuation after the baseline first contact. Separation plots show the canonical pose; the table retains all four poses.','',
        '![Applied turn and same-state reference turn](turning_trace.png)','',
        'The prefix-end event is inserted exactly when it falls between nominal updates. The primary 5 ms intervention aligns with dt=.005. Results at dt=.01 are also saved, including this event handling. The reference feedback and numerical resolution remain approximations; neither a successful assisted prefix nor full-reference success constitutes a new learned capability.','',
        'Raw controls were replayed with float64 arc geometry. The original trace can use float32 learned-sign arrays, so bitwise state equality is not assumed: the largest state difference was 3.36e-8, and all definite/possible contact flags matched. Per-trace differences and replayed minimum-distance bounds are saved. The old baseline minimum separations reproduce within 4.79e-9 m and contact flags match. Existing model weights and previous output records remain unchanged.','',
        'Next, resolve the local numerical switching behavior more carefully before selecting a training change. A local comparison of reference refinement, value shape and physics residual around the learned control transition can distinguish reference smoothing from a persistent learned error. No new training or permanent reference-assisted controller was introduced here.','',
        'See [methodology](METHODOLOGY.md), [frozen protocol](protocol.json), [initial coefficients](initial_gradients.json), [finite differences](derivative_checks.json), [all intervention metrics](metrics.csv), [handback diagnostics](handback_diagnostics.csv), [baseline reproduction](baseline_reproduction.json), and [geometry replay](geometry_replay.json).','']
    (out/'README.md').write_text('\n'.join(lines),encoding='utf-8')
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    ev.dump(out/'output_manifest.json',dict(status='verified single-case development diagnostic',
        outputs={str(f.relative_to(out)):ev.sha(f) for f in sorted(out.rglob('*')) if f.is_file() and f.name!='output_manifest.json'},
        report_source_sha256=ev.sha(Path(__file__)),parameter_updates=0))
    print(json.dumps(dict(summary=summary,initial_gradients=initial,
        maximum_state_replay_difference=max(c['maximum_state_replay_difference'] for c in checks)),indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--reuse-geometry',action='store_true')
    summarize(parser.parse_args().reuse_geometry)

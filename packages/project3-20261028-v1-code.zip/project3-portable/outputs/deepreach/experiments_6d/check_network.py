"""Pre-training checks. Initializes disposable models; never updates parameters."""
import hashlib
import json
import tempfile
from pathlib import Path

import torch
from network import (JointSiren, PairedSampler, config, value_grad, residual,
                     save_components, load_components, scales)
from joint6d import target, dynamics, hamiltonian, optimal_inputs

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rejects(fn):
    try:
        fn()
    except (ValueError, RuntimeError, KeyError):
        return
    raise AssertionError('Expected invalid input to be rejected')


def run():
    torch.set_num_threads(2)
    protected = list(ROOT.glob('**/checkpoint*.pt')) + [ROOT/'evaluation/reserved_final_states/states.npz']
    before = {str(p.relative_to(ROOT)): sha(p) for p in protected}
    results = {}
    for formulation in ('soft_terminal', 'terminal_obstacle_square'):
        c = config(formulation)
        global_rng = torch.get_rng_state().clone()
        model = JointSiren(c).double()
        assert torch.equal(global_rng, torch.get_rng_state())
        assert sum(p.numel() for p in model.parameters()) == 8897
        weights = {k: v.clone() for k, v in model.state_dict().items()}
        sampler = PairedSampler(c)
        q = sampler.sample(128, c['horizon'], 16, dtype=torch.float64)
        assert q.shape == (128, 7) and (q[-16:, 0] == 0).all()
        assert (q[:-16, 0] > 0).all() and (q[:, 0] <= c['horizon']).all()
        assert (q[:, 1:].abs() <= torch.tensor(scales(c)[1:])).all()
        assert torch.isfinite(model(q)).all()
        v, dv = value_grad(model, q)
        # Independent central differences of all seven physical inputs.
        eps = 1e-6
        fd = []
        for j in range(7):
            dq = torch.zeros_like(q); dq[:, j] = eps
            fd.append((model(q+dq)-model(q-dq))/(2*eps))
        fd_error = float((torch.stack(fd, dim=-1)-dv).abs().max().detach())
        assert fd_error < 1e-6
        # Direct normalized-coordinate derivative versus physical chain rule.
        normalized = (q/model.scales).detach().requires_grad_(True)
        vn = model(normalized*model.scales)
        dn = torch.autograd.grad(vn.sum(), normalized)[0]/model.scales
        chain_error = float((dn-dv).abs().max())
        assert chain_error < 1e-10
        r, v, p = residual(model, q, create_graph=True)
        assert torch.isfinite(r).all()
        expected = torch.maximum(p[:, 0]-hamiltonian(q[:, 1:], p[:, 1:], c),
                                 v-target(q[:, 1:], c))
        assert torch.equal(r, expected)
        loss = r.abs().mean()
        loss.backward()
        grads = [p.grad for p in model.parameters()]
        assert all(g is not None and torch.isfinite(g).all() for g in grads)
        norm = float(sum(g.square().sum() for g in grads).sqrt())
        assert norm > 0
        u, d = optimal_inputs(p[:, 1:].detach(), c)
        selected = (dynamics(q[:, 1:], u, d, c)*p[:, 1:].detach()).sum(-1)
        control_error = float((selected-hamiltonian(q[:, 1:], p[:, 1:].detach(), c)).abs().max())
        assert control_error < 1e-12
        terminal_error = None
        if formulation == 'terminal_obstacle_square':
            terminal_error = float((model(q[-16:])-target(q[-16:, 1:], c)).abs().max().detach())
            assert terminal_error == 0
            assert (model(q) <= target(q[:, 1:], c)).all()
            colliding = q.clone(); colliding[:, 1:3] = colliding[:, 4:6]+.01
            assert (model(colliding) <= 0).all()
        # Component snapshots have no optimizer/training progress; roundtrip only.
        temporary_root = ROOT.parents[1]/'work'
        temporary_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=temporary_root, prefix='joint6d_check_') as tmp:
            path = Path(tmp)/'components.pt'
            # Save float32 model as the supported initial component snapshot.
            fresh = JointSiren(c)
            save_components(path, fresh, sampler)
            restored, replay = load_components(path)
            assert torch.equal(fresh(q.float()), restored(q.float()))
            assert torch.equal(sampler.sample(64, .3, 8), replay.sample(64, .3, 8))
            torch.save({'config': {'problem': 'Air3D'}, 'model': {}}, path)
            rejects(lambda: load_components(path))
        assert all(torch.equal(weights[k], val) for k, val in model.state_dict().items())
        rejects(lambda: model(torch.zeros(2, 4, dtype=torch.float64)))
        rejects(lambda: PairedSampler(dict(c, problem='Air3D')))
        rejects(lambda: sampler.sample(8, .6, 2))
        rejects(lambda: sampler.sample(8, .5, 9))
        results[formulation] = dict(parameters=8897, physical_fd_max_abs=fd_error,
            normalization_chain_max_abs=chain_error, terminal_max_abs=terminal_error,
            physics_loss=float(loss.detach()), parameter_gradient_norm=norm,
            neural_control_hamiltonian_max_abs=control_error, snapshot_roundtrip=True,
            parameter_updates=0)

    a = PairedSampler(config('soft_terminal'))
    b = PairedSampler(config())
    # Different pretraining activity and initialization must not shift physics RNG.
    for _ in range(9):
        a.sample(64, 0., 64, stream='terminal')
    JointSiren(config(), seed=119)
    for t in (.001, .1, .25, .5):
        assert torch.equal(a.sample(2048, t, 256), b.sample(2048, t, 256))
    state = a.state_dict()
    next_q = a.sample(128, .5, 16)
    a.load_state_dict(state)
    assert torch.equal(next_q, a.sample(128, .5, 16))
    assert before == {str(p.relative_to(ROOT)): sha(p) for p in protected}
    result = dict(status='passed', experimental_training=False, optimizer_created=False,
        parameter_updates=0, threads=2, synthetic_checks_only=True,
        new_evaluation_data_generated=False, old_final_states_used=False,
        paired_physics_stream=True, sampler_state_replay=True, variants=results,
        protected_inputs_unchanged=True, protected_inputs=before,
        sources={p.name: sha(p) for p in [HERE/'network.py', HERE/'check_network.py', ROOT/'joint6d.py']})
    (HERE/'implementation_checks.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('protected_inputs','sources')}, indent=2))


if __name__ == '__main__':
    run()

"""Audit saved local refinement queries and report numerical stability."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import refine_local_reference as study
import evaluate as ev
import diagnose_shared_failure as diag


def crossings(x,y):
    result=[]
    for i in range(len(x)-1):
        if y[i]==0:
            result.append(dict(bracket=[float(x[i]),float(x[i])],linear_estimate=float(x[i])))
        elif y[i]*y[i+1]<0:
            root=x[i]-y[i]*(x[i+1]-x[i])/(y[i+1]-y[i])
            result.append(dict(bracket=[float(x[i]),float(x[i+1])],linear_estimate=float(root)))
    if y[-1]==0:
        result.append(dict(bracket=[float(x[-1]),float(x[-1])],linear_estimate=float(x[-1])))
    return result


def report():
    out=study.OUT;p=json.loads((out/'protocol.json').read_text())
    manifest=json.loads((out/'manifest.json').read_text())
    assert p['source_hashes']=={s.name:ev.sha(s) for s in study.SOURCES}
    with np.load(out/'fixed_queries.npz') as f:
        times=f['elapsed_times'];offsets=f['heading_offsets'];path=f['joint_path']
    zero=int(np.argmin(abs(offsets)));data={};initial=[];roots=[];differences=[];estimator_rows=[]
    for n,nh in study.GRIDS:
        key=str(n)
        metadata=json.loads((out/f'reference_{n}_{nh}.json').read_text())
        file=out/f'reference_{n}_{nh}.npz'
        assert ev.sha(file)==metadata['queried_output_sha256']
        with np.load(file) as f:d={k:f[k].copy() for k in f.files}
        assert np.array_equal(times,d['elapsed_times']) and np.array_equal(offsets,d['heading_offsets'])
        assert d['values'].shape==(len(times),len(offsets))
        assert d['coefficients'].shape==(len(times),len(offsets),2)
        assert np.isfinite(d['values']).all() and np.isfinite(d['coefficients']).all()
        assert float(d['values'][0,zero])==metadata['initial_value']
        assert float(d['coefficients'][0,zero,0])==metadata['initial_evader_coefficient']
        data[key]=d
        fd1=next(r for r in metadata['initial_value_secants'] if r['width']==1e-5)
        fd2=next(r for r in metadata['initial_value_secants'] if r['width']==1e-6)
        initial.append(dict(grid=f'{n}x{n}x{nh}',n=n,initial_value=metadata['initial_value'],
            central_grid_evader_coefficient=metadata['initial_evader_coefficient'],
            relative_heading_derivative=metadata['initial_pursuer_coefficient'],
            projected_spatial_derivative=metadata['initial_evader_coefficient']+metadata['initial_pursuer_coefficient'],
            value_interpolant_derivative_eps_1e_minus5=fd1['central_secant'],
            value_interpolant_derivative_eps_1e_minus6=fd2['central_secant'],
            fd_epsilon_sensitivity=abs(fd1['central_secant']-fd2['central_secant']),
            derivative_estimator_difference=abs(metadata['initial_evader_coefficient']-fd2['central_secant'])))
        for item in metadata['initial_value_secants']:
            estimator_rows.append(dict(grid=key,**item))
        roots.append(dict(source=key,kind='initial_heading_offset',crossings=crossings(offsets,d['coefficients'][0,:,0])))
        roots.append(dict(source=key,kind='early_fixed_path_time',crossings=crossings(times,d['coefficients'][:,zero,0])))
    learned={}
    for name in ['4C','3D_Long']:
        for pose in range(4):
            with np.load(out/f'learned_heading_cut_{name}_{pose}.npz') as f:
                ld={k:f[k].copy() for k in f.files}
            assert np.array_equal(offsets,ld['heading_offsets'])
            learned[name,pose]=ld
            roots.append(dict(source=name,pose=pose,kind='initial_heading_offset',crossings=crossings(offsets,ld['coefficients'][:,0])))
    for old,new in [('129','161'),('161','193')]:
        a=data[old];b=data[new]
        differences.append(dict(old=old,new=new,
            initial_value_change=float(b['values'][0,zero]-a['values'][0,zero]),
            initial_coefficient_change=float(b['coefficients'][0,zero,0]-a['coefficients'][0,zero,0]),
            heading_cut_coefficient_mae=float(abs(b['coefficients'][0,:,0]-a['coefficients'][0,:,0]).mean()),
            fixed_path_coefficient_mae=float(abs(b['coefficients'][:,zero,0]-a['coefficients'][:,zero,0]).mean()),
            fixed_path_sign_disagreements=int(np.sum(np.sign(b['coefficients'][:,zero,0])!=np.sign(a['coefficients'][:,zero,0]))),
            local_map_sign_disagreement_fraction=float(np.mean(np.sign(b['coefficients'][:,:,0])!=np.sign(a['coefficients'][:,:,0])))))
    signs=[np.sign(r['central_grid_evader_coefficient']) for r in initial]+[np.sign(r['value_interpolant_derivative_eps_1e_minus6']) for r in initial]
    initial_direction_consistent=bool(all(s==signs[0] and s!=0 for s in signs))
    initial_direction='negative (-3 rad/s)' if signs[-1]<0 else 'positive (+3 rad/s)' if signs[-1]>0 else 'zero'
    last=differences[-1]
    stability=dict(initial_sign_consistent_across_three_levels_and_both_estimators=initial_direction_consistent,
        initial_reference_direction=initial_direction,
        latest_initial_coefficient_absolute_change=abs(last['initial_coefficient_change']),
        latest_initial_coefficient_relative_change_percent=100*abs(last['initial_coefficient_change'])/max(abs(initial[-1]['central_grid_evader_coefficient']),1e-30),
        latest_fixed_path_sign_disagreements=last['fixed_path_sign_disagreements'],
        fixed_path_points=len(times),latest_local_map_sign_disagreement_fraction=last['local_map_sign_disagreement_fraction'],
        exact_solution_convergence_certified=False)
    ev.dump(out/'initial_comparison.json',initial);ev.write_csv(out/'initial_comparison.csv',initial)
    ev.dump(out/'refinement_changes.json',differences);ev.write_csv(out/'refinement_changes.csv',differences)
    ev.dump(out/'sampled_zero_crossings.json',roots);ev.write_csv(out/'value_secants.csv',estimator_rows)
    ev.dump(out/'stability_summary.json',stability)
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    for key,d in data.items():
        axes[0,0].plot(offsets,d['coefficients'][0,:,0],label=key+' reference')
        axes[0,1].plot(offsets,d['values'][0],label=key+' reference')
        axes[1,0].plot(times,d['coefficients'][:,zero,0],label=key+' reference')
    for name in ['4C','3D_Long']:
        axes[0,0].plot(offsets,learned[name,0]['coefficients'][:,0],linestyle='--',label=name)
        axes[0,1].plot(offsets,learned[name,0]['values'],linestyle='--',label=name)
    pose_values=np.stack([learned['4C',i]['coefficients'][:,0] for i in range(4)])
    axes[0,0].fill_between(offsets,pose_values.min(axis=0),pose_values.max(axis=0),alpha=.12,label='4C pose range')
    with np.load(diag.OUT/'trace_4C_0.005_learned.npz') as previous:
        mask=previous['times']<=.100000001
        axes[1,0].plot(times,previous['model_coefficients'][mask,0,0],linestyle='--',label='4C, same path')
    axes[1,1].plot([r['n'] for r in initial],[r['central_grid_evader_coefficient'] for r in initial],marker='o',label='Interpolated central-grid derivative')
    axes[1,1].plot([r['n'] for r in initial],[r['value_interpolant_derivative_eps_1e_minus6'] for r in initial],marker='s',label='Derivative of value interpolant')
    axes[0,0].set(title='Initial evader-heading cut: switching coefficient',xlabel='Evader heading offset [rad]',ylabel='m/rad')
    axes[0,1].set(title='Initial evader-heading cut: value',xlabel='Evader heading offset [rad]',ylabel='Value [m]')
    axes[1,0].set(title='Same saved baseline states: first 100 ms',xlabel='Elapsed time [s]',ylabel='Evader coefficient [m/rad]')
    axes[1,1].set(title='Initial derivative estimates by reference level',xlabel='Spatial grid nodes per axis',ylabel='m/rad')
    for ax in axes.flat:ax.axhline(0,color='black',linestyle=':',linewidth=1);ax.grid(alpha=.2);ax.legend(fontsize=7)
    fig.savefig(out/'local_reference_comparison.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(14,4),layout='constrained')
    limit=max(float(abs(d['coefficients'][:,:,0]).max()) for d in data.values())
    for ax,(key,d) in zip(axes,data.items()):
        field=d['coefficients'][:,:,0].T
        im=ax.pcolormesh(times,offsets,field,cmap='coolwarm',vmin=-limit,vmax=limit,shading='auto')
        if field.min()<0<field.max():ax.contour(times,offsets,field,levels=[0],colors='black',linewidths=.8)
        ax.axhline(0,color='black',linestyle='--',linewidth=.8)
        ax.set(title=key+' reference',xlabel='Elapsed time on fixed path [s]',ylabel='Evader heading offset [rad]')
    fig.colorbar(im,ax=axes,label='Evader coefficient [m/rad]')
    fig.savefig(out/'switching_neighborhood.png',dpi=160);plt.close(fig)
    # Report raw differences, not an invented convergence certificate.
    rows=['# Local numerical-reference refinement','',
        'This audit refines the deliberately selected development failure without training, new policies or new encounters. All grids query the same saved early trajectory and physical heading perturbations. The unchanged solver refines space, heading and CFL-limited time integration together.','',
        (f"The audited initial reference turn remains **{initial_direction}** across all three levels and both derivative estimators. Both unchanged PINNs choose +3 rad/s at this starting state. This strengthens the numerical evidence for an initial learned-direction mismatch, while the magnitude and nearby switching location still require separate assessment." if initial_direction_consistent else
         'The initial direction still depends on reference level or derivative estimator. This audit does not resolve a unique numerical turning label; a training change should not assume that label is established.'),'',
        '| Reference grid | Initial value | Interpolated central-grid evader derivative | Derivative of value interpolant (eps=1e-6) |',
        '|---|---:|---:|---:|']
    for r in initial:
        rows.append(f"| {r['grid']} | {r['initial_value']:.8f} m | {r['central_grid_evader_coefficient']:.8f} | {r['value_interpolant_derivative_eps_1e_minus6']:.8f} |")
    rows += ['',
        'A positive evader coefficient selects +3 rad/s and a negative coefficient selects -3 rad/s. The two derivative columns estimate different derivatives of an approximate numerical solution; agreement or disagreement must be assessed rather than treating either as exact. Epsilon sensitivity for the interpolant derivative is saved separately from grid-refinement sensitivity.','',
        'The central-grid coefficient decomposes as `a = (ry*V_rx - rx*V_ry) - V_psi`:','',
        '| Grid | Projected spatial contribution | Relative-heading derivative | Their difference: evader coefficient |',
        '|---|---:|---:|---:|']
    for r in initial:
        rows.append(f"| {r['n']} | {r['projected_spatial_derivative']:.8f} | {r['relative_heading_derivative']:.8f} | {r['central_grid_evader_coefficient']:.8f} |")
    rows += ['',
        'This algebra identifies which estimated contributions change. Because spatial, angular and time resolution change together, it does not isolate a single numerical source. Agreement between estimators of the same numerical solution is a consistency check, not independent ground truth.','',
        '| Refinement | Initial value change | Initial central-grid coefficient change | Mean absolute coefficient difference along path | Sign disagreements on 21 fixed path states |',
        '|---|---:|---:|---:|---:|']
    for r in differences:
        rows.append(f"| {r['old']} → {r['new']} | {r['initial_value_change']:.8f} m | {r['initial_coefficient_change']:.8f} | {r['fixed_path_coefficient_mae']:.8f} | {r['fixed_path_sign_disagreements']} |")
    rows += ['',
        f"Between the two finest levels, the initial grid-gradient coefficient changes by {stability['latest_initial_coefficient_absolute_change']:.8f} m/rad ({stability['latest_initial_coefficient_relative_change_percent']:.2f}% of the finest magnitude). Signs differ on {last['fixed_path_sign_disagreements']} of the 21 fixed path queries; {100*last['local_map_sign_disagreement_fraction']:.2f}% of the full sampled local map changes sign. These raw sign counts include near-zero coefficients. They are descriptions of this sampled neighborhood, not convergence bounds.",'',
        'Approximate zero locations from the fixed samples:','',
        '| Source | Nearest initial-heading-offset zero | First early-path time zero |',
        '|---|---:|---:|']
    for source in ['129','161','193','4C','3D_Long']:
        heading=next(r['crossings'] for r in roots if r['source']==source and r['kind']=='initial_heading_offset' and r.get('pose',0)==0)
        time_roots=next((r['crossings'] for r in roots if r['source']==source and r['kind']=='early_fixed_path_time'),[])
        hc=min(heading,key=lambda c:abs(c['linear_estimate'])) if heading else None
        tc=time_roots[0] if time_roots else None
        htext=f"{hc['linear_estimate']:.6f} rad, bracket [{hc['bracket'][0]:.3f}, {hc['bracket'][1]:.3f}]" if hc else 'None in fixed cut'
        ttext=f"{tc['linear_estimate']:.6f} s, bracket [{tc['bracket'][0]:.3f}, {tc['bracket'][1]:.3f}]" if tc else ('Not queried' if source in ['4C','3D_Long'] else 'None in fixed window')
        rows.append(f'| {source} | {htext} | {ttext} |')
    rows += ['',
        '![Reference and learned local comparisons](local_reference_comparison.png)','',
        'On the fixed initial heading cut, the nearest reference zero moves from +0.04230 to +0.06232 to +0.07430 rad as the grid refines. The canonical 4C zero is at -0.17237 rad, and 3D_Long at -0.02407 rad. Thus all audited references place the change of turn on the positive side of the starting heading, while both learned surfaces place it on the negative side. This explains their opposite initial decisions within these approximate comparisons. The 4C zeros also vary across equivalent poses (-0.17571 to -0.13196 rad), but every pose remains on the negative side.','',
        'The heading cut changes only the evader heading at fixed positions and fixed pursuer heading. The band shows 4C variation over the four existing equivalent poses. Reference comparisons use the canonical pose, which has the same relative state. The time trace uses identical saved states for every grid and for the plotted 4C coefficients; it does not resimulate a refined controller.','',
        '![Sampled local switching maps](switching_neighborhood.png)','',
        'Black contours are zeros of the sampled/interpolated numerical coefficient field. Dashed horizontal lines mark the original saved path. The maps describe this fixed neighborhood; they are not certified optimal switching surfaces. Sampled zero-crossing brackets and linear estimates are saved in `sampled_zero_crossings.json`, without adaptive root searches.','',
        'The 129×129×96 rebuild reproduces the previous early value and coefficient queries within 1e-12. A local affine fixture checks the physical joint-heading direction and the value-interpolant finite difference. Original network weights, earlier evaluation outputs and final-state bytes remain unchanged. No policy was updated or rolled out in this audit.','',
        'Three finite grids do not prove convergence of the true value or its derivative. First-order numerical diffusion, angular/spatial discretization, interpolation and possible nonsmoothness remain relevant. The reference resolution check is a development diagnostic on one deliberately selected failure; it does not establish a general PINN or controller improvement.','',
        'The initial direction mismatch survives every refinement and both numerical derivative estimators. The two finest grids still differ in coefficient magnitude by about 15.4%, and in switching time on two of the 21 path queries; initial-direction evidence is stronger than a claim of a fully resolved boundary. Next, audit the learned HJI residual around the displaced local switching transition, using physics-only queries, before choosing a training modification. This can test whether the existing loss exposes the local error. No further training or new refined-policy rollout was performed here.','',
        'See [methodology](METHODOLOGY.md), [frozen protocol](protocol.json), [initial comparison](initial_comparison.csv), [refinement changes](refinement_changes.csv), [value secants](value_secants.csv), [sampled zero crossings](sampled_zero_crossings.json), and [execution manifest](manifest.json).','']
    (out/'README.md').write_text('\n'.join(rows),encoding='utf-8')
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    ev.dump(out/'output_manifest.json',dict(status='verified saved local-reference queries',
        outputs={str(f.relative_to(out)):ev.sha(f) for f in sorted(out.rglob('*')) if f.is_file() and f.name!='output_manifest.json'},
        report_source_sha256=ev.sha(Path(__file__)),parameter_updates=0))
    print(json.dumps(dict(initial=initial,changes=differences),indent=2))


if __name__=='__main__':report()

# Experiment 5 — training completed

[Completed training and next evaluation](experiment_5_sampling/TRAINING_RESULTS.md). Both arms reached their fixed 2,000-update endpoint in VS Code. Accuracy and control comparisons remain pending.

The preparation record below describes the state before training.

# Experiment 5 prepared â€” training paused

[Review the fixed sampling rule, budgets and evaluation plan](experiment_5_sampling/PROTOCOL.md)

Two arms start from the same 4C weights, Adam moments and base sampling stream. Each adds 2,000 full-horizon updates. 5U stays uniform; 5R replaces 448 of 1,792 nonterminal points using a bank of the 1,024 highest-residual candidates from pools of 8,192, refreshed every 50 updates.

Both reach 24,000 cumulative physics updates. Candidate scoring adds compute to 5R and is accounted for separately. The comparison isolates sampling under matched additional update counts; it does not claim zero-extra-training improvement or equal wall time. No numerical labels, bounds or known failure points enter the candidate pool.

Sampler/optimizer resume checks passed with tiny disposable fixtures. The trained 4C dry check only scored points; its weights stayed unchanged. At preparation, no Experiment 5 run or fresh evaluation dataset had started. Explicit VS Code start/resume entries are prepared; verification remains separate.

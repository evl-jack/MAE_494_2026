"""Single consumed-development-case diagnosis; fixed initial-action interventions.

No training, production controller modification or final-test queries.
"""
import argparse
import copy
import functools
import json
import time
from pathlib import Path
import shutil

import numpy as np
import torch
from scipy.interpolate import RegularGridInterpolator
import evaluate as ev
import rollouts as ro
from network import value_grad

HERE=Path(__file__).resolve().parent
OUT=HERE/'shared_failure_diagnostic'
DURATIONS=[.005,.01,.025,.05,.1]
MODELS=['4C','3D_Long']
SOURCES=[Path(__file__),HERE/'rollouts.py',HERE/'evaluate.py',HERE/'network.py',
         ev.ROOT/'deepreach.py',ev.ROOT/'reference.py',ev.ROOT/'joint6d.py']


class CachedReference(ro.ReferenceControl):
    # Both reference resolutions, 21 planes each. Reuse across intervention arms.
    @functools.lru_cache(maxsize=42)
    def plane(self,index):
        return super().plane(index)


class ReferenceValue:
    def __init__(self,ref):
        self.ref=ref;self.times=np.array(list(ref['values']))

    @functools.lru_cache(maxsize=42)
    def plane(self,index):
        ref=self.ref;v=ref['values'][float(self.times[index])]
        return RegularGridInterpolator((ref['x'],ref['x'],np.r_[ref['theta'],np.pi]),
            np.concatenate([v,v[:,:,:1]],axis=2),bounds_error=True)

    def value(self,tau,r):
        hi=min(len(self.times)-1,max(1,int(np.searchsorted(self.times,tau,side='left'))))
        lo=hi-1;a=(tau-self.times[lo])/(self.times[hi]-self.times[lo])
        return (1-a)*self.plane(lo)(r)+a*self.plane(hi)(r)


def variants():
    return ([dict(id='learned',mode='learned',duration=0.)]+
        [dict(id=f'initial_turn_{round(t*1000)}ms',mode='initial_turn',duration=t) for t in DURATIONS]+
        [dict(id=f'feedback_prefix_{round(t*1000)}ms',mode='feedback_prefix',duration=t) for t in DURATIONS]+
        [dict(id='reference_all',mode='reference_all',duration=.5)])


def prepare():
    if OUT.exists():raise FileExistsError('Shared-failure diagnostic already exists')
    OUT.mkdir();(OUT/'sources').mkdir()
    protected={str(p.relative_to(ev.ROOT)):ev.sha(p) for p in ev.ROOT.rglob('checkpoint*.pt')}
    extras=[ev.ROOT/'evaluation/reserved_final_states/states.npz',
        ev.OUT/'development_states.npz',ev.OUT/'reference_values.npz',ev.OUT/'reference_gradients.npz',
        ro.OUT/'initial_states.npz',ro.OUT/'rollouts_dt_0.005.npz',ro.OUT/'rollouts_dt_0.010.npz']
    for p in extras:protected[str(p.relative_to(ev.ROOT))]=ev.sha(p)
    p=dict(status='frozen before new reference solves, trace queries or interventions',date='2026-10-28',
        case='Development group 603, selected because it failed both 4C and 3D_Long; post-hoc diagnostic, not independent validation',
        group_id=603,poses=4,models=MODELS,control_time_steps=[.01,.005],variants=variants(),
        primary='At dt=.005 compare learned baseline with a 5ms constant initial-reference-turn prefix; then return to unchanged learned policy',
        secondary='All fixed prefix durations, reference-feedback prefixes, four poses and dt sensitivity; no adaptive duration search',
        pursuer='Same fine-reference feedback throughout each actual trajectory, reevaluated at every control event',
        prefix_initial_turn='Hold u equal to the fine reference initial sign at the original state, not recomputed within prefix',
        prefix_feedback='Use fine reference evader feedback on current state within prefix, then learned feedback',
        full_reference='Reference feedback throughout; diagnostic network values still recorded on its trajectory',
        reference_grids=[[97,97,72],[129,129,96]],reference_times=np.linspace(0,.5,21).tolist(),
        time_interpolation='Central grid gradients and values spatially interpolated, linearly blended between time planes; approximate reference',
        events='Add the exact prefix-end time to the controller grid if needed; the primary 5ms prefix is aligned with dt=.005',
        integration='Unchanged exact constant-turn arc and nine within-interval samples plus relative-speed lower distance bound',
        derivatives='Initial learned evader/pursuer coefficients checked with double-precision central finite differences at eps 1e-5 on physical joint headings',
        traces='Time, time remaining, joint state, learned/coarse/fine values and both switching coefficients, actual controls, separation and contact bounds',
        coefficient_margins=[.005,.01,.02],
        limitations='One deliberately selected failure, fixed approximate pursuer, not a learned correction or causal identification of a training defect',
        training=False,parameter_updates=0,old_final_states_queried=False,future_final_seed_used=False,threads=2,
        source_hashes={p.name:ev.sha(p) for p in SOURCES},protected_inputs=protected)
    ev.dump(OUT/'protocol.json',p)
    for src in SOURCES:shutil.copy2(src,OUT/'sources'/src.name)
    print('Single-case intervention protocol frozen; no intervention run yet.',flush=True)


def reference_coefficients(policy,tau,z):
    r=ro.relative(z);g=policy.gradient(tau,r)
    return np.stack([r[:,1]*g[:,0]-r[:,0]*g[:,1]-g[:,2],g[:,2]],axis=-1)


def model_diagnostics(name,model,tau,z):
    states=ro.relative(z) if name=='3D_Long' else z
    q=np.column_stack([np.full(len(z),tau),states])
    v,g=ev.model_grad(model,q)
    if name=='3D_Long':
        a=states[:,1]*g[:,1]-states[:,0]*g[:,2]-g[:,3];b=g[:,3]
    else:a=g[:,6];b=g[:,3]
    return v,np.stack([a,b],axis=-1)


def derivative_checks(name,model,initial):
    md=copy.deepcopy(model).double();eps=1e-5
    qstates=ro.relative(initial) if name=='3D_Long' else initial
    q=torch.tensor(np.column_stack([np.full(len(initial),.5),qstates]),dtype=torch.float64)
    _,g=value_grad(md,q)
    if name=='3D_Long':
        automatic=np.stack([qstates[:,1]*g[:,1].numpy()-qstates[:,0]*g[:,2].numpy()-g[:,3].numpy(),g[:,3].numpy()],axis=-1)
    else:automatic=g[:,[6,3]].numpy()
    finite=[]
    for heading in [5,2]:
        zp=initial.copy();zm=initial.copy();zp[:,heading]+=eps;zm[:,heading]-=eps
        sp=ro.relative(zp) if name=='3D_Long' else zp
        sm=ro.relative(zm) if name=='3D_Long' else zm
        with torch.no_grad():
            plus=md(torch.tensor(np.column_stack([np.full(len(sp),.5),sp]),dtype=torch.float64)).numpy()
            minus=md(torch.tensor(np.column_stack([np.full(len(sm),.5),sm]),dtype=torch.float64)).numpy()
        finite.append((plus-minus)/(2*eps))
    finite=np.stack(finite,axis=-1)
    assert np.max(abs(finite-automatic))<1e-7
    return dict(model=name,eps=eps,max_abs_error=float(np.max(abs(finite-automatic))),
                double_autodiff_coefficients=automatic.tolist(),finite_difference_coefficients=finite.tolist())


def trace(name,model,initial,dt,variant,coarse,fine,coarse_value,fine_value):
    edges=np.unique(np.round(np.r_[np.linspace(0,.5,round(.5/dt)+1),variant['duration']],12))
    z=initial.copy();initial_co=reference_coefficients(fine,.5,z)
    prefix_u=3*np.sign(initial_co[:,0])
    upper=np.linalg.norm(z[:,:2]-z[:,3:5],axis=-1);lower=upper.copy()
    first=np.where(upper<=.25,0.,np.inf)
    data={k:[] for k in ['states','model_values','model_coefficients','coarse_values','fine_values',
                         'coarse_coefficients','fine_coefficients']}
    actions=[]
    for k,elapsed in enumerate(edges):
        tau=.5-elapsed;r=ro.relative(z)
        value,coef=model_diagnostics(name,model,tau,z)
        cg=reference_coefficients(coarse,tau,z);fg=reference_coefficients(fine,tau,z)
        for key,v in [('states',z.copy()),('model_values',value),('model_coefficients',coef),
            ('coarse_values',coarse_value.value(tau,r)),('fine_values',fine_value.value(tau,r)),
            ('coarse_coefficients',cg),('fine_coefficients',fg)]:data[key].append(v)
        if k==len(edges)-1:break
        learned=3*np.sign(coef[:,0]);u=learned
        prefix=elapsed<variant['duration']-1e-12
        if variant['mode']=='reference_all' or (variant['mode']=='feedback_prefix' and prefix):
            u=3*np.sign(fg[:,0])
        elif variant['mode']=='initial_turn' and prefix:u=prefix_u
        d=-3*np.sign(fg[:,1]);actions.append(np.stack([u,d],axis=-1))
        h=edges[k+1]-elapsed
        m,lo,hit=ro.step_minimum(z,u,d,h)
        upper=np.minimum(upper,m);lower=np.minimum(lower,lo);first=np.minimum(first,elapsed+hit)
        z=ro.advance(z,u,d,h)
    return dict(times=edges,actions=np.stack(actions).astype(np.int8),
        minimum_distance_upper=upper,minimum_distance_lower=lower,first_sampled_collision_time=first,
        definite_collision=upper<=.25,possible_collision=lower<=.25,
        **{k:np.stack(v) for k,v in data.items()})


def evaluate():
    p=json.loads((OUT/'protocol.json').read_text())
    if (OUT/'status.json').exists():raise FileExistsError('Diagnostic already started; preserve its record')
    assert p['source_hashes']=={src.name:ev.sha(src) for src in SOURCES}
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    torch.set_num_threads(2);start=time.perf_counter()
    ev.dump(OUT/'status.json',dict(status='building two reference resolutions',training=False))
    with np.load(ev.OUT/'development_states.npz') as f:
        initial=f['joint'][p['group_id']];relative=f['relative'][p['group_id']]
    np.savez_compressed(OUT/'initial_state.npz',joint=initial,relative=relative)
    refs=[];builds=[]
    for n,nh in [(97,72),(129,96)]:
        print(f'Reference {n}x{n}x{nh} for matched-state diagnostic traces.',flush=True)
        clock=time.perf_counter();ref=ev.solve(dict(domain=2.,horizon=.5,speed=.75,turn=3.,radius=.25),n,nh,p['reference_times'])
        refs.append(ref);builds.append(dict(grid=[n,n,nh],seconds=time.perf_counter()-clock))
    coarse,fine=[CachedReference(r) for r in refs]
    cv,fv=[ReferenceValue(r) for r in refs]
    # Check that this reference rebuild matches saved development values.
    with np.load(ev.OUT/'reference_values.npz') as old:
        for ref,key in zip(refs,['coarse','fine']):
            assert abs(ev.interpolate(ref,.5,relative[None])[0]-old[key][-1,p['group_id']])<1e-12
    models=ro.load_models();original={name:{k:v.clone() for k,v in models[name].state_dict().items()} for name in MODELS}
    derivatives=[derivative_checks(name,models[name],initial) for name in MODELS]
    ev.dump(OUT/'derivative_checks.json',derivatives)
    initial_rows=[]
    for name in MODELS:
        value,co=model_diagnostics(name,models[name],.5,initial)
        cg=reference_coefficients(coarse,.5,initial);fg=reference_coefficients(fine,.5,initial)
        for pose in range(4):
            initial_rows.append(dict(model=name,pose=pose,value=float(value[pose]),
                learned_evader_coefficient=float(co[pose,0]),learned_pursuer_coefficient=float(co[pose,1]),
                fine_evader_coefficient=float(fg[pose,0]),coarse_evader_coefficient=float(cg[pose,0]),
                fine_pursuer_coefficient=float(fg[pose,1]),coarse_pursuer_coefficient=float(cg[pose,1])))
    ev.dump(OUT/'initial_gradients.json',initial_rows);ev.write_csv(OUT/'initial_gradients.csv',initial_rows)
    rows=[];baseline_checks=[]
    for dt in p['control_time_steps']:
        with np.load(ro.OUT/f'rollouts_dt_{dt:.3f}.npz') as old,np.load(ro.OUT/'initial_states.npz') as old_initial:
            local=int(np.flatnonzero(old_initial['group_ids']==p['group_id'])[0])
            for name in MODELS:
                for variant in p['variants']:
                    data=trace(name,models[name],initial,dt,variant,coarse,fine,cv,fv)
                    filename=f"trace_{name}_{dt:.3f}_{variant['id']}.npz"
                    np.savez_compressed(OUT/filename,**data)
                    for pose in range(4):
                        coefficient=data['model_coefficients'][:-1,pose,0]
                        fg=data['fine_coefficients'][:-1,pose,0];cg=data['coarse_coefficients'][:-1,pose,0]
                        stable=(np.sign(fg)==np.sign(cg))&(abs(fg)>.01)&(abs(cg)>.01)
                        widths=np.diff(data['times'])
                        rows.append(dict(model=name,dt=dt,variant=variant['id'],mode=variant['mode'],
                            prefix_seconds=variant['duration'],pose=pose,
                            definite_collision=bool(data['definite_collision'][pose]),possible_collision=bool(data['possible_collision'][pose]),
                            sampled_minimum_distance=float(data['minimum_distance_upper'][pose]),
                            lower_minimum_distance_bound=float(data['minimum_distance_lower'][pose]),
                            first_sampled_contact_time=float(data['first_sampled_collision_time'][pose]) if np.isfinite(data['first_sampled_collision_time'][pose]) else None,
                            reference_stable_duration=float(widths[stable].sum()),
                            stable_wrong_learned_sign_duration=float(widths[stable&(np.sign(coefficient)!=np.sign(fg))].sum()),
                            evader_control_switches=int(np.count_nonzero(np.diff(data['actions'][:,pose,0])))))
                    if variant['id']=='learned':
                        pair=ro.POLICIES.index(name)*8+ro.POLICIES.index('reference')
                        prior=old['minimum_distance_upper'][pair,local*4:(local+1)*4]
                        prior_hits=old['definite_collision'][pair,local*4:(local+1)*4]
                        baseline_checks.append(dict(model=name,dt=dt,
                            max_minimum_distance_difference=float(abs(prior-data['minimum_distance_upper']).max()),
                            contact_flags_match=bool(np.array_equal(prior_hits,data['definite_collision']))))
                    print(f"{name}, dt={dt}, {variant['id']}: contacts {int(data['definite_collision'].sum())}/4",flush=True)
    ev.dump(OUT/'metrics.json',rows);ev.write_csv(OUT/'metrics.csv',rows)
    ev.dump(OUT/'baseline_reproduction.json',baseline_checks)
    for name in MODELS:
        assert all(torch.equal(v,models[name].state_dict()[k]) for k,v in original[name].items())
        assert all(param.grad is None for param in models[name].parameters())
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    assert p['source_hashes']=={src.name:ev.sha(src) for src in SOURCES}
    result=dict(status='completed single-case development diagnosis',training=False,optimizer_created=False,
        parameter_updates=0,old_final_states_queried=False,models_unchanged=True,
        protocol_sha256=ev.sha(OUT/'protocol.json'),protected_inputs_unchanged=True,
        reference_builds=builds,trajectory_count=2*2*12*4,seconds=time.perf_counter()-start,
        execution='managed process, main project interpreter; not VS Code debugger',
        primary=[r for r in rows if r['dt']==.005 and r['variant'] in ['learned','initial_turn_5ms']])
    ev.dump(OUT/'manifest.json',result);ev.dump(OUT/'status.json',dict(status='completed',training=False))
    print(json.dumps(dict(initial_gradients=initial_rows,baseline_checks=baseline_checks),indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--evaluate',action='store_true')
    args=ap.parse_args()
    if args.prepare==args.evaluate:ap.error('Choose exactly one action')
    prepare() if args.prepare else evaluate()

"""CPU joint-coordinate PINN components; no training entry point.

Sine initialization follows the existing project implementation; see
../THIRD_PARTY_NOTICES.md. Physical inputs are differentiated before scaling.
"""
import copy
import math
import sys
from pathlib import Path

import torch
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from joint6d import target, hamiltonian

INPUT_ORDER = ('tau', 'xp', 'yp', 'heading_p', 'xe', 'ye', 'heading_e')
SCHEMA = 'joint6d-components-v1'


def config(formulation='terminal_obstacle_square'):
    return dict(problem='JointAir3D6D', input_order=list(INPUT_ORDER),
                formulation=formulation, speed=.75, turn=3., radius=.25,
                horizon=.5, domain=2., angle_factor=1.2, width=64,
                sine_layers=3, value_scale=25., value_mean=.25,
                constraint_scale=.25, constraint_initial_bias=1.)


def validate(c):
    if c.get('problem') != 'JointAir3D6D' or c.get('input_order') != list(INPUT_ORDER):
        raise ValueError('Expected the seven ordered JointAir3D6D inputs')
    if c.get('formulation') not in ('soft_terminal', 'terminal_obstacle_square'):
        raise ValueError('Unsupported output formulation')
    for key in ('horizon', 'domain', 'radius', 'value_scale', 'constraint_scale'):
        if not math.isfinite(c[key]) or c[key] <= 0:
            raise ValueError(f'{key} must be positive and finite')
    for key in ('speed', 'turn'):
        if not math.isfinite(c[key]) or c[key] < 0:
            raise ValueError(f'{key} must be nonnegative and finite')
    for key in ('value_mean', 'constraint_initial_bias', 'angle_factor'):
        if not math.isfinite(c[key]):
            raise ValueError(f'{key} must be finite')
    if c['angle_factor'] < 1 or c['constraint_initial_bias'] == 0:
        raise ValueError('Require angle coverage >= pi and nonzero square-head bias')
    for key in ('width', 'sine_layers'):
        if type(c[key]) is not int or c[key] <= 0:
            raise ValueError(f'{key} must be a positive integer')


def scales(c):
    return [c['horizon'], c['domain'], c['domain'], c['angle_factor']*math.pi,
            c['domain'], c['domain'], c['angle_factor']*math.pi]


class JointSiren(nn.Module):
    def __init__(self, c, seed=7):
        super().__init__()
        validate(c)
        self.c = copy.deepcopy(c)
        self.layers = nn.ModuleList()
        # Initialization neither consumes global RNG nor touches sampler streams.
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed)
            dims = [7]+[c['width']]*c['sine_layers']+[1]
            for i, (ni, no) in enumerate(zip(dims[:-1], dims[1:])):
                layer = nn.Linear(ni, no)
                bound = 1/ni if i == 0 else math.sqrt(6/ni)/30
                nn.init.uniform_(layer.weight, -bound, bound)
                self.layers.append(layer)
            if c['formulation'] == 'terminal_obstacle_square':
                with torch.no_grad():
                    self.layers[-1].bias.add_(c['constraint_initial_bias'])
        self.register_buffer('scales', torch.tensor(scales(c)))

    def raw(self, z):
        for layer in self.layers[:-1]:
            z = torch.sin(30*layer(z))
        return self.layers[-1](z).squeeze(-1)

    def forward(self, q):
        if q.shape[-1] != 7:
            raise ValueError('Expected seven physical inputs in declared order')
        z = q/self.scales
        if self.c['formulation'] == 'terminal_obstacle_square':
            return target(q[..., 1:], self.c)-self.c['constraint_scale']*z[..., 0]*self.raw(z).square()
        return self.c['value_scale']*self.raw(z)+self.c['value_mean']


def value_grad(model, q, create_graph=False):
    q = q.detach().requires_grad_(True)
    v = model(q)
    return v, torch.autograd.grad(v.sum(), q, create_graph=create_graph)[0]


def residual(model, q, create_graph=False):
    v, dv = value_grad(model, q, create_graph)
    r = torch.maximum(dv[:, 0]-hamiltonian(q[:, 1:], dv[:, 1:], model.c),
                      v-target(q[:, 1:], model.c))
    return r, v, dv


class PairedSampler:
    """Independent terminal/physics CPU streams, shared across formulations.

    Physics stream position is unaffected by pretraining or model construction.
    Caller supplies curriculum tmax; terminal rows are the last nterminal rows.
    """
    def __init__(self, c, terminal_seed=991745, physics_seed=991746):
        validate(c)
        self.c = copy.deepcopy(c)
        self.generators = {name: torch.Generator(device='cpu').manual_seed(seed)
                           for name, seed in [('terminal', terminal_seed), ('physics', physics_seed)]}

    def sample(self, n, tmax, nterminal, stream='physics', dtype=torch.float32):
        if type(n) is not int or n <= 0 or type(nterminal) is not int or not 0 <= nterminal <= n:
            raise ValueError('Invalid sample or terminal count')
        if not math.isfinite(tmax) or not 0 <= tmax <= self.c['horizon']:
            raise ValueError('tmax must lie in the configured horizon')
        if stream not in self.generators:
            raise ValueError('Unknown sampling stream')
        q = (2*torch.rand(n, 7, generator=self.generators[stream], dtype=dtype)-1)
        q *= torch.tensor(scales(self.c), dtype=dtype)
        q[:, 0] = torch.rand(n, generator=self.generators[stream], dtype=dtype)*tmax
        if nterminal:
            q[-nterminal:, 0] = 0
        return q

    def state_dict(self):
        return {k: g.get_state().clone() for k, g in self.generators.items()}

    def load_state_dict(self, state):
        if set(state) != set(self.generators):
            raise ValueError('Expected terminal and physics sampler states')
        for k, g in self.generators.items():
            g.set_state(state[k])


def save_components(path, model, sampler):
    """Float32 CPU component snapshot, NOT a resumable training checkpoint."""
    if model.c != sampler.c:
        raise ValueError('Model and sampler configurations differ')
    if any(p.dtype != torch.float32 or p.device.type != 'cpu' for p in model.parameters()):
        raise ValueError('Component snapshots currently require float32 CPU parameters')
    torch.save(dict(schema=SCHEMA, config=model.c, model=model.state_dict(),
                    sampler=sampler.state_dict()), path)


def load_components(path):
    ck = torch.load(path, map_location='cpu', weights_only=True)
    if ck.get('schema') != SCHEMA:
        raise ValueError('Incompatible component snapshot (including old 3D checkpoints)')
    validate(ck['config'])
    model = JointSiren(ck['config'])
    model.load_state_dict(ck['model'], strict=True)
    expected = torch.tensor(scales(model.c), dtype=model.scales.dtype)
    if not torch.equal(model.scales, expected):
        raise ValueError('Snapshot scales conflict with physical configuration')
    sampler = PairedSampler(ck['config'])
    sampler.load_state_dict(ck['sampler'])
    return model, sampler

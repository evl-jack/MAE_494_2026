"""Fixed closed-loop development comparison. No training or final-set queries."""
import argparse
import functools
import json
import math
import shutil
import time
from pathlib import Path

import numpy as np
import torch
from scipy.interpolate import RegularGridInterpolator
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import evaluate as ev
from network import JointSiren, value_grad
from deepreach import load_checkpoint
from reference import solve, interpolate

HERE=Path(__file__).resolve().parent
OUT=HERE/'closed_loop_evaluation'
POLICIES=['4A','4B','4C','3D_Long','reference','straight','left','right']
SOURCES=[Path(__file__),HERE/'network.py',HERE/'evaluate.py',HERE.parent/'joint6d.py',
         HERE.parent/'deepreach.py',HERE.parent/'reference.py']
DT=[.01,.005]
RADIUS=.25
SPEED=.75
TURN=3.
HORIZON=.5
SUBSTEPS=8


def relative(z):
    delta=z[...,0:2]-z[...,3:5];co=np.cos(z[...,5]);si=np.sin(z[...,5])
    return np.stack([co*delta[...,0]+si*delta[...,1],-si*delta[...,0]+co*delta[...,1],
                     (z[...,2]-z[...,5]+np.pi)%(2*np.pi)-np.pi],axis=-1)


def advance(z,u,d,dt):
    """Exact independent constant-turn arcs for one sample-and-hold interval."""
    out=z.copy()
    for x,y,h,w in [(0,1,2,d),(3,4,5,u)]:
        half=w*dt/2
        distance=SPEED*dt*np.sinc(half/np.pi)
        out[...,x]+=distance*np.cos(z[...,h]+half)
        out[...,y]+=distance*np.sin(z[...,h]+half)
        out[...,h]=(z[...,h]+w*dt+np.pi)%(2*np.pi)-np.pi
    return out


def step_minimum(z,u,d,dt):
    minimum=np.full(z.shape[:-1],np.inf)
    first=np.full(z.shape[:-1],np.inf)
    for j in range(SUBSTEPS+1):
        timepoint=dt*j/SUBSTEPS
        state=advance(z,u,d,timepoint)
        dist=np.linalg.norm(state[...,0:2]-state[...,3:5],axis=-1)
        minimum=np.minimum(minimum,dist)
        first=np.where((dist<=RADIUS)&np.isinf(first),timepoint,first)
    # Relative speed <= 2v; nearest sampled time is <= dt/(2*SUBSTEPS) away.
    lower=np.maximum(0,minimum-SPEED*dt/SUBSTEPS-1e-12)
    return minimum,lower,first


def mechanics_checks():
    rng=np.random.default_rng(991755)
    z=rng.uniform(-.7,.7,(64,6));u=rng.uniform(-3,3,64);d=rng.uniform(-3,3,64)
    full=advance(z,u,d,.01);half=advance(advance(z,u,d,.005),u,d,.005)
    assert np.max(abs(full-half))<1e-12
    shifted=z.copy();shifted[:,[0,3]]+=.3;shifted[:,[1,4]]-=.2
    alpha=.7;rot=np.array([[np.cos(alpha),-np.sin(alpha)],[np.sin(alpha),np.cos(alpha)]])
    rotated=z.copy();rotated[:,:2]=z[:,:2]@rot.T;rotated[:,3:5]=z[:,3:5]@rot.T;rotated[:,[2,5]]+=alpha
    assert np.max(abs(relative(advance(shifted,u,d,.01))-relative(full)))<1e-12
    assert np.max(abs(relative(advance(rotated,u,d,.01))-relative(full)))<1e-12
    # Endpoints are separated but the two vehicles cross between them.
    crossing=np.array([[-.3,0,0,.3,0,np.pi]])
    m,lo,hit=step_minimum(crossing,np.zeros(1),np.zeros(1),.8)
    assert m[0]<1e-12 and np.isfinite(hit[0]) and lo[0]==0
    straight=advance(crossing,np.zeros(1),np.zeros(1),.01)
    assert np.allclose(straight[0,[0,3]],[-.2925,.2925])
    return dict(status='passed',arc_semigroup_max_abs=float(np.max(abs(full-half))),
                translation_and_rotation=True,within_step_crossing_detected=True,
                zero_turn_limit=True,lipschitz_distance_gap_at_fine_dt=SPEED*.005/SUBSTEPS)


def prepare():
    checks=mechanics_checks()
    checks['policy_actor_accounting']=control_accounting_check()
    if OUT.exists():
        raise FileExistsError('Rollout protocol already exists')
    OUT.mkdir();(OUT/'sources').mkdir()
    ids=np.random.default_rng(991754).choice(6000,200,replace=False)
    protected={str(p.relative_to(ev.ROOT)):ev.sha(p) for p in ev.ROOT.rglob('checkpoint*.pt')}
    for p in [ev.OUT/'development_states.npz',ev.OUT/'reference_values.npz',ev.ROOT/'evaluation/reserved_final_states/states.npz']:
        protected[str(p.relative_to(ev.ROOT))]=ev.sha(p)
    protocol=dict(status='frozen before selecting/loading rollout states and simulating policies',
        purpose='Closed-loop development diagnostic; not final evaluation or exhaustive adversarial verification',
        subset_seed=991754,relative_group_ids=ids.tolist(),groups=200,poses_each=4,
        policies=POLICIES,ordered_pair_count=len(POLICIES)**2,time_steps=DT,
        speed=SPEED,turn_bound=TURN,collision_distance=RADIUS,horizon=HORIZON,
        integration='Exact constant-turn arc per vehicle, sample-and-hold controls; heading canonically wrapped at every update',
        collision='Nine exact-arc samples per interval; definite collision if any distance <= R; ambiguous if speed-bound lower estimate <=R but no sampled collision',
        collision_subintervals=SUBSTEPS,minimum_distance_bound='Sampled minimum minus v*dt/8 (and 1e-12 numerical guard) <= true minimum <= sampled minimum',
        ties='sign(0)=0; no deadband, smoothing, learning or adaptive policy selection',
        reference_policy='Unchanged 129x129x96 solver, 21 time planes. Central grid gradients, spatial trilinear and temporal linear interpolation; H=max_u min_d.',
        reference_controls='u=3 sign(ry*gx-rx*gy-gpsi); d=-3 sign(gpsi)',
        learned_controls='Joint u=3 sign(V_heading_e), d=-3 sign(V_heading_p); relative model uses its chain-rule coefficients.',
        primary='4C evader versus reference pursuer at dt=.005, initially separated groups with both coarse and fine initial V > .01 m',
        subsets=['all','initially_separated','reference_safe_margin_0.01'],
        tests='Full 8x8 ordered policy matrix for each dt; finite-policy worst observed outcomes also reported.',
        after_contact='Continue mathematical trajectories through horizon; collision flag remains absorbing. Switch counts summarize entire horizon, including after contact.',
        trajectory_examples='First four selected relative groups, all their poses, every policy pair; no outcome-based example selection',
        state='Existing development groups only. Old final states and future final seed are not queried.',
        source_hashes={p.name:ev.sha(p) for p in SOURCES},protected_inputs=protected,
        checkpoint_paths={k:str(ev.MODELS[k].relative_to(ev.ROOT)) for k in ['4A','4B','4C','3D_Long']},
        mechanics_checks=checks,training=False,optimizer_created=False,threads=2)
    ev.dump(OUT/'protocol.json',protocol)
    for p in SOURCES:
        shutil.copy2(p,OUT/'sources'/p.name)
    print('Rollout mechanics checks passed; policy matrix and subset frozen.',flush=True)


class ReferenceControl:
    def __init__(self,ref):
        self.ref=ref;self.times=np.array(list(ref['values']))

    @functools.lru_cache(maxsize=2)
    def plane(self,index):
        ref=self.ref;v=ref['values'][float(self.times[index])]
        gradients=np.stack([np.gradient(v,ref['dx'],axis=0),np.gradient(v,ref['dx'],axis=1),
            (np.roll(v,-1,axis=2)-np.roll(v,1,axis=2))/(2*ref['dtheta'])],axis=-1)
        periodic=np.concatenate([gradients,gradients[:,:,:1]],axis=2)
        return RegularGridInterpolator((ref['x'],ref['x'],np.r_[ref['theta'],np.pi]),periodic,bounds_error=True)

    def gradient(self,tau,r):
        hi=min(len(self.times)-1,max(1,int(np.searchsorted(self.times,tau,side='left'))))
        lo=hi-1;weight=(tau-self.times[lo])/(self.times[hi]-self.times[lo])
        return (1-weight)*self.plane(lo)(r)+weight*self.plane(hi)(r)


def load_models():
    models={}
    for name in ['4A','4B','4C','3D_Long']:
        if name=='3D_Long':
            model,_=load_checkpoint(ev.MODELS[name])
        else:
            ck=torch.load(ev.MODELS[name],map_location='cpu',weights_only=True)
            model=JointSiren(ck['config']);model.load_state_dict(ck['model'],strict=True)
        models[name]=model.eval()
    return models


def controls(z,tau,models,reference):
    # Pair axis precedes state/pose axis; each trajectory evolves independently.
    pairs=len(POLICIES)**2;n=z.shape[1]
    eids=np.repeat(np.arange(len(POLICIES)),len(POLICIES))
    pids=np.tile(np.arange(len(POLICIES)),len(POLICIES))
    u=np.zeros((pairs,n));d=np.zeros((pairs,n))
    for name in POLICIES:
        policy=POLICIES.index(name);emask=eids==policy;pmask=pids==policy;mask=emask|pmask
        selected=z[mask].reshape(-1,6)
        if name in ['straight','left','right']:
            v={'straight':0.,'left':TURN,'right':-TURN}[name]
            u[emask]=v;d[pmask]=v;continue
        r=relative(selected)
        if name=='reference':
            g=reference.gradient(tau,r)
            uc=TURN*np.sign(r[:,1]*g[:,0]-r[:,0]*g[:,1]-g[:,2]);dc=-TURN*np.sign(g[:,2])
        else:
            states=r if name=='3D_Long' else selected
            q=np.column_stack([np.full(len(states),tau),states])
            _,g=ev.model_grad(models[name],q)
            if name=='3D_Long':
                uc=TURN*np.sign(r[:,1]*g[:,1]-r[:,0]*g[:,2]-g[:,3]);dc=-TURN*np.sign(g[:,3])
            else:
                uc=TURN*np.sign(g[:,6]);dc=-TURN*np.sign(g[:,3])
        uc=uc.reshape(-1,n);dc=dc.reshape(-1,n)
        # Within selected pair rows, choose only the actor assigned this policy.
        u[emask]=uc[emask[mask]];d[pmask]=dc[pmask[mask]]
    assert np.isfinite(u).all() and np.isfinite(d).all()
    assert max(abs(u).max(),abs(d).max())<=TURN
    return u,d


def control_accounting_check():
    class Analytic(torch.nn.Module):
        def forward(self,q):
            return q[:,6]-q[:,3] if q.shape[1]==7 else q[:,3]
    class AnalyticReference:
        def gradient(self,tau,r):
            return np.tile([0.,0.,1.],(len(r),1))
    models={name:Analytic() for name in ['4A','4B','4C','3D_Long']}
    z=np.zeros((len(POLICIES)**2,2,6));z[:,:,0]=.5
    u,d=controls(z,.5,models,AnalyticReference())
    expected=[3.,3.,3.,-3.,-3.,0.,3.,-3.]
    assert np.array_equal(u[:,0],np.repeat(expected,len(POLICIES)))
    assert np.array_equal(d[:,0],np.tile(expected,len(POLICIES)))
    assert np.array_equal(u[:,0],u[:,1]) and np.array_equal(d[:,0],d[:,1])
    return 'all 64 evader/pursuer assignments match analytic switching coefficients'


def simulate(initial,dt,models,reference):
    pair_count=len(POLICIES)**2
    z=np.repeat(initial[None,:,:],pair_count,axis=0)
    upper=np.linalg.norm(z[:,:,:2]-z[:,:,3:5],axis=-1)
    lower=upper.copy();first=np.where(upper<=RADIUS,0.,np.inf)
    steps=round(HORIZON/dt);hist=[];examples=[z[:,:16].copy()]
    for step in range(steps):
        tau=HORIZON-step*dt
        u,d=controls(z,tau,models,reference)
        m,lo,hit=step_minimum(z,u,d,dt)
        upper=np.minimum(upper,m);lower=np.minimum(lower,lo)
        first=np.minimum(first,step*dt+hit)
        hist.append(np.stack([u,d],axis=-1).astype(np.int8))
        z=advance(z,u,d,dt);examples.append(z[:,:16].copy())
        assert np.isfinite(z).all() and np.max(abs(z[:,:,[0,1,3,4]]))<2
        if (step+1)%20==0 or step+1==steps:
            print(f'dt={dt}: {step+1}/{steps} control updates across {pair_count} policy pairs',flush=True)
    history=np.stack(hist)
    return dict(minimum_distance_upper=upper,minimum_distance_lower=lower,first_sampled_collision_time=first,
                definite_collision=upper<=RADIUS,possible_collision=lower<=RADIUS,
                switch_counts=np.count_nonzero(np.diff(history,axis=0),axis=0),
                controls=history,example_states=np.stack(examples).astype(np.float32),final_states=z)


def summarize(results,initial,subsets):
    rows=[];worst=[]
    n=len(POLICIES)
    for dt,data in results.items():
        for i,ep in enumerate(POLICIES):
            for j,dp in enumerate(POLICIES):
                k=i*n+j
                for subset,mask in subsets.items():
                    count=int(mask.sum())
                    if not count:continue
                    definite=data['definite_collision'][k,mask];possible=data['possible_collision'][k,mask]
                    lower=data['minimum_distance_lower'][k,mask];upper=data['minimum_distance_upper'][k,mask]
                    rows.append(dict(dt=dt,evader=ep,pursuer=dp,subset=subset,joint_queries=count,
                        relative_groups=int(mask.reshape(-1,4).any(axis=1).sum()),
                        definite_collision_count=int(definite.sum()),possible_collision_count=int(possible.sum()),
                        ambiguous_collision_count=int((possible&~definite).sum()),collision_fraction=float(definite.mean()),
                        mean_minimum_separation=float(upper.mean()),worst_minimum_separation=float(upper.min()),
                        mean_evader_switches=float(data['switch_counts'][k,mask,0].mean()),
                        mean_pursuer_switches=float(data['switch_counts'][k,mask,1].mean()),
                        pose_collision_disagreement_group_fraction=float(np.mean(data['definite_collision'][k].reshape(-1,4).any(axis=1)!=data['definite_collision'][k].reshape(-1,4).all(axis=1))) if subset=='all' else None))
            block=slice(i*n,(i+1)*n)
            for subset,mask in subsets.items():
                if not mask.any():continue
                hit=data['definite_collision'][block][:,mask].any(axis=0)
                possible=data['possible_collision'][block][:,mask].any(axis=0)
                worst.append(dict(dt=dt,evader=ep,subset=subset,joint_queries=int(mask.sum()),
                    tested_pursuer_policy_count=n,any_tested_pursuer_collision_count=int(hit.sum()),
                    any_tested_pursuer_possible_collision_count=int(possible.sum()),
                    any_tested_pursuer_collision_fraction=float(hit.mean())))
    ev.write_csv(OUT/'policy_pair_metrics.csv',rows);ev.dump(OUT/'policy_pair_metrics.json',rows)
    ev.write_csv(OUT/'finite_policy_worst.csv',worst);ev.dump(OUT/'finite_policy_worst.json',worst)
    differences=[]
    coarse=results[.01];fine=results[.005]
    for i,ep in enumerate(POLICIES):
        for j,dp in enumerate(POLICIES):
            k=i*n+j
            for subset,mask in subsets.items():
                if not mask.any():continue
                differences.append(dict(evader=ep,pursuer=dp,subset=subset,
                    collision_outcome_changes=int(np.sum(coarse['definite_collision'][k,mask]!=fine['definite_collision'][k,mask])),
                    joint_queries=int(mask.sum()),
                    minimum_separation_mean_abs_change=float(abs(coarse['minimum_distance_upper'][k,mask]-fine['minimum_distance_upper'][k,mask]).mean()),
                    minimum_separation_max_abs_change=float(abs(coarse['minimum_distance_upper'][k,mask]-fine['minimum_distance_upper'][k,mask]).max())))
    ev.write_csv(OUT/'time_step_sensitivity.csv',differences);ev.dump(OUT/'time_step_sensitivity.json',differences)
    fig,axes=plt.subplots(1,2,figsize=(13,5),layout='constrained')
    mask=subsets['reference_safe_margin_0.01']
    for ax,dt in zip(axes,DT):
        matrix=results[dt]['definite_collision'][:,mask].mean(axis=1).reshape(n,n)*100
        im=ax.imshow(matrix,vmin=0,vmax=100,cmap='magma')
        ax.set(xticks=range(n),xticklabels=POLICIES,yticks=range(n),yticklabels=POLICIES,
               xlabel='Pursuer policy',ylabel='Evader policy',title=f'Collision % on reference-safe subset, dt={dt}')
        ax.tick_params(axis='x',rotation=60)
        for i in range(n):
            for j in range(n):
                ax.text(j,i,f'{matrix[i,j]:.1f}',ha='center',va='center',fontsize=7,color='white' if matrix[i,j]<60 else 'black')
    fig.colorbar(im,ax=axes,label='Observed definite collision [%]');fig.savefig(OUT/'collision_matrix.png',dpi=160);plt.close(fig)
    return rows,worst,differences


def evaluate():
    protocol=json.loads((OUT/'protocol.json').read_text())
    if (OUT/'status.json').exists():raise FileExistsError('Rollout evaluation already started; preserve its record')
    assert protocol['source_hashes']=={p.name:ev.sha(p) for p in SOURCES}
    assert all(ev.sha(ev.ROOT/n)==h for n,h in protocol['protected_inputs'].items())
    torch.set_num_threads(2);start=time.perf_counter()
    ev.dump(OUT/'status.json',dict(status='building reference policy',training=False))
    ids=np.array(protocol['relative_group_ids'])
    with np.load(ev.OUT/'development_states.npz') as f:
        r=f['relative'][ids];joint=f['joint'][ids]
    with np.load(ev.OUT/'reference_values.npz') as f:
        vf=f['fine'][-1,ids];vc=f['coarse'][-1,ids]
    separated=np.linalg.norm(r[:,:2],axis=1)>RADIUS
    safe=separated&(vf>.01)&(vc>.01)
    subsets={key:np.repeat(mask,4) for key,mask in [('all',np.ones(len(r),dtype=bool)),
              ('initially_separated',separated),('reference_safe_margin_0.01',safe)]}
    np.savez_compressed(OUT/'initial_states.npz',relative=r,joint=joint,group_ids=ids,
        fine_value=vf,coarse_value=vc,**subsets)
    print('Building unchanged fine reference for time-dependent feedback.',flush=True)
    c=dict(domain=2.,horizon=HORIZON,speed=SPEED,turn=TURN,radius=RADIUS)
    clock=time.perf_counter();ref=solve(c,129,96,np.linspace(0,.5,21))
    assert np.max(abs(interpolate(ref,.5,r)-vf))<1e-12
    reference_seconds=time.perf_counter()-clock
    reference=ReferenceControl(ref);models=load_models();results={}
    original={name:{k:v.clone() for k,v in m.state_dict().items()} for name,m in models.items()}
    for dt in DT:
        ev.dump(OUT/'status.json',dict(status='simulating closed-loop matrix',dt=dt,training=False))
        results[dt]=simulate(joint.reshape(-1,6),dt,models,reference)
        np.savez_compressed(OUT/f'rollouts_dt_{dt:.3f}.npz',**results[dt])
    rows,worst,differences=summarize(results,joint,subsets)
    for name,model in models.items():
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in original[name].items())
        assert all(p.grad is None for p in model.parameters())
    assert all(ev.sha(ev.ROOT/n)==h for n,h in protocol['protected_inputs'].items())
    assert protocol['source_hashes']=={p.name:ev.sha(p) for p in SOURCES}
    primary=next(r for r in rows if r['dt']==.005 and r['evader']=='4C' and r['pursuer']=='reference' and r['subset']=='reference_safe_margin_0.01')
    result=dict(status='completed closed-loop development matrix',training=False,optimizer_created=False,parameter_updates=0,
        protocol_sha256=ev.sha(OUT/'protocol.json'),protected_inputs_unchanged=True,old_final_states_queried=False,
        future_final_seed_used=False,primary=primary,relative_groups=len(ids),poses_each=4,
        trajectory_count=2*len(POLICIES)**2*len(ids)*4,reference_seconds=reference_seconds,
        execution='managed process with main project interpreter; not VS Code debugger',
        seconds=time.perf_counter()-start,source_hashes=protocol['source_hashes'],
        collision_checks='Definite and possible counts bound geometric contacts for each fixed sample-and-hold trajectory; policy feedback discretization is checked separately.')
    ev.dump(OUT/'manifest.json',result);ev.dump(OUT/'status.json',dict(status='completed',training=False))
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--evaluate',action='store_true')
    args=ap.parse_args()
    if args.prepare==args.evaluate:ap.error('Choose exactly one of --prepare or --evaluate')
    prepare() if args.prepare else evaluate()

"""Frozen grouped development evaluation. No training or final-set queries."""
import argparse
import csv
import hashlib
import json
import math
import shutil
import time
from pathlib import Path

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from network import JointSiren, value_grad
from joint6d import lift_relative, relative_state, lift_covector
from reference import solve, interpolate
from deepreach import load_checkpoint
from validate import classification, error, predict

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE/'development_evaluation'
MODELS = {**{k: HERE/f'runs/{k}/checkpoint.pt' for k in ('4A','4B','4C')},
          '3D_3A': ROOT/'runs/experiment_3_a_constraints/checkpoint.pt',
          '3D_Long': ROOT/'runs/experiment_3_e_long64/checkpoint_22000.pt'}
SOURCES = [Path(__file__), HERE/'network.py', ROOT/'joint6d.py', ROOT/'reference.py', ROOT/'deepreach.py', ROOT/'validate.py']


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def write_csv(path, rows):
    if not rows:
        return
    with path.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def prepare():
    if OUT.exists():
        raise FileExistsError('Development evaluation exists; do not replace its fixed protocol')
    OUT.mkdir(); (OUT/'sources').mkdir()
    protected = {str(p.relative_to(ROOT)): sha(p) for p in ROOT.rglob('checkpoint*.pt')}
    final = ROOT/'evaluation/reserved_final_states/states.npz'
    protected[str(final.relative_to(ROOT))] = sha(final)
    protocol = dict(status='frozen before generating development states or labels',
        date='2026-10-28',purpose='Development only; not an independent final test',
        relative_groups=6000,poses_per_group=4,relative_seed=991747,pose_seed=991749,
        poses=['canonical','translation_only','rotation_only','translation_and_rotation'],
        relative_half_width=.6,midpoint_half_width=.5,times=np.linspace(0,.5,21).tolist(),
        fine_grid=[129,129,96],coarse_grid=[97,97,72],reference_domain=2.,
        reference_gradient='Central grid differences (periodic heading), then trilinear interpolation; approximate derivatives, not exact labels.',
        gradient_times=[.25,.5],switching_margins=[.005,.01,.02],
        stable_subset='For each switching coefficient: coarse/fine signs agree and both absolute magnitudes exceed margin. All poses share relative-group membership.',
        alias_test='Each heading separately shifted by +/-2pi only where both representations fit +/-1.2pi; final horizon.',
        primary='Final-time grouped mean absolute value error of 4C versus 4B; report every fixed model.',
        secondary=['21-horizon errors and unsafe-set classification','relative-configuration pose spread and transformation gaps',
                   'terminal, obstacle, lower physical bound and temporal increase checks',
                   'mapped reference gradients and reference-stable switching sign agreement at .25/.5 s',
                   'comparison to fixed 3D_3A and 3D_Long on the same fresh relative groups'],
        bootstrap=dict(draws=2000,seed=991753,unit='relative group; average its four pose errors first',
                       pairs=[['4A','4B'],['4B','4C'],['3D_Long','4C']]),
        threads=2,device='cpu',training=False,optimizer_created=False,
        future_final_seed_991748_used=False,old_final_states_queried=False,
        rollouts='Not part of this value/gradient diagnostic; no closed-loop safety claim.',
        models={k:dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for k,p in MODELS.items()},
        source_hashes={p.name:sha(p) for p in SOURCES},protected_inputs=protected)
    dump(OUT/'protocol.json', protocol)
    for p in SOURCES:
        shutil.copy2(p, OUT/'sources'/p.name)
    print('Frozen development protocol; no states or reference labels generated.', flush=True)


def grid_gradient(ref, t, states):
    v = ref['values'][float(t)]
    dx = ref['dx']; dh = ref['dtheta']
    gradients = [np.gradient(v, dx, axis=0), np.gradient(v, dx, axis=1),
                 (np.roll(v,-1,axis=2)-np.roll(v,1,axis=2))/(2*dh)]
    return np.stack([interpolate(dict(ref, values={float(t):g}),t,states) for g in gradients], axis=-1)


def check_gradient_helper():
    x=np.linspace(-2,2,129); th=np.linspace(-np.pi,np.pi,96,endpoint=False)
    xx,yy,hh=np.meshgrid(x,x,th,indexing='ij')
    ref=dict(x=x,theta=th,dx=x[1]-x[0],dtheta=2*np.pi/96,values={.5:2*xx-3*yy+np.sin(hh)})
    states=np.array([[.13,-.22,.2],[-.4,.5,np.pi-.01],[.1,.1,-np.pi+.02]])
    g=grid_gradient(ref,.5,states)
    assert np.max(abs(g[:,:2]-[2,-3])) < 1e-12
    assert np.max(abs(g[:,2]-np.cos(states[:,2]))) < .002
    return dict(affine_spatial_error=float(np.max(abs(g[:,:2]-[2,-3]))),
                periodic_heading_error=float(np.max(abs(g[:,2]-np.cos(states[:,2])))))


def generate_states(p):
    rng=np.random.default_rng(p['relative_seed'])
    relative=rng.uniform(-1,1,(p['relative_groups'],3))*[.6,.6,np.pi]
    poses=np.random.default_rng(p['pose_seed'])
    n=len(relative); zero=np.zeros((n,2)); angle0=np.zeros(n)
    mids=[zero,poses.uniform(-.5,.5,(n,2)),zero,poses.uniform(-.5,.5,(n,2))]
    angles=[angle0,angle0,poses.uniform(-np.pi,np.pi,n),poses.uniform(-np.pi,np.pi,n)]
    joint=np.stack([lift_relative(torch.tensor(relative),torch.tensor(m),torch.tensor(a)).numpy()
                    for m,a in zip(mids,angles)],axis=1)
    recovered=relative_state(torch.tensor(joint),wrap=True).numpy()
    assert np.max(abs(recovered-relative[:,None,:])) < 1e-12
    bound=.5+np.sqrt(2)*.6/2
    assert abs(joint[:,:,[0,1,3,4]]).max() <= bound
    assert np.sqrt(2)*.6+2*.75*.5 < 2
    assert bound+.75*.5 < 2
    np.savez_compressed(OUT/'development_states.npz',relative=relative,joint=joint,
                        group_id=np.arange(n),pose_names=np.array(p['poses']))
    return relative,joint


def model_grad(model,q):
    values=[]; gradients=[]
    for batch in np.array_split(q, max(1,math.ceil(len(q)/2048))):
        v,g=value_grad(model,torch.tensor(batch,dtype=torch.float32))
        values.append(v.detach().numpy());gradients.append(g.detach().numpy())
    return np.concatenate(values),np.concatenate(gradients)


def metric_row(name,t,pred,truth):
    diff=pred-truth
    unsafe=pred<=0; actual=truth<=0
    return dict(model=name,time=float(t),**error(pred,truth),**classification(pred.ravel(),truth.ravel()),
        false_safe_count=int((~unsafe&actual).sum()),false_unsafe_count=int((unsafe&~actual).sum()),
        bias=float(diff.mean()),p99_abs=float(np.quantile(abs(diff),.99)),
        relative_l2=float(np.linalg.norm(diff)/np.linalg.norm(truth)))


def gradient_metrics(name,t,joint,pred_grad,coarse,fine,c,margins):
    z=torch.tensor(joint.reshape(-1,6))
    fine6=lift_covector(z,torch.tensor(np.repeat(fine,4,axis=0))).numpy()
    coarse6=lift_covector(z,torch.tensor(np.repeat(coarse,4,axis=0))).numpy()
    p=pred_grad[:,1:]; lengths=np.linalg.norm(p,axis=1)*np.linalg.norm(fine6,axis=1)
    valid=lengths>1e-10
    cosine=(p*fine6).sum(-1)[valid]/lengths[valid]
    shift=np.linalg.norm(p[:,:2]+p[:,3:5],axis=1)
    rotation=-z[:,1].numpy()*p[:,0]+z[:,0].numpy()*p[:,1]+p[:,2]-z[:,4].numpy()*p[:,3]+z[:,3].numpy()*p[:,4]+p[:,5]
    result=dict(model=name,time=float(t),six_gradient_component_mae=float(abs(p-fine6).mean()),
        reference_coarse_fine_component_mae=float(abs(coarse6-fine6).mean()),
        mean_gradient_cosine=float(cosine.mean()) if valid.any() else None,
        nonzero_cosine_count=int(valid.sum()),translation_identity_mean_norm=float(shift.mean()),
        rotation_identity_mean_abs=float(abs(rotation).mean()))
    controls=[]
    separated=np.repeat(np.linalg.norm(relative_state(z).numpy()[:,:2],axis=1)>c['radius'],1)
    # Input to both joint and relative control laws is the lifted covector.
    for label,index in [('evader',5),('pursuer',2)]:
        f=fine6[:,index]; co=coarse6[:,index]; approx=p[:,index]
        for margin in margins:
            stable=(np.sign(f)==np.sign(co))&(abs(f)>margin)&(abs(co)>margin)
            for subset,mask in [('all',stable),('initially_separated',stable&separated)]:
                controls.append(dict(model=name,time=float(t),actor=label,margin=margin,subset=subset,
                    stable_count=int(mask.sum()),total_joint_queries=len(mask),
                    stable_relative_groups=int(mask.reshape(-1,4).any(axis=1).sum()),
                    sign_agreement=float(np.mean(np.sign(approx[mask])==np.sign(f[mask]))) if mask.any() else None))
    return result,controls,fine6,coarse6


def evaluate():
    if (OUT/'manifest.json').exists() or (OUT/'status.json').exists():
        raise FileExistsError('Evaluation already started/completed; preserve its record')
    p=json.loads((OUT/'protocol.json').read_text())
    assert p['source_hashes']=={f.name:sha(f) for f in SOURCES}
    assert all(sha(ROOT/n)==h for n,h in p['protected_inputs'].items())
    torch.set_num_threads(2);start=time.perf_counter()
    dump(OUT/'status.json',dict(status='generating development reference',training=False))
    helper=check_gradient_helper();relative,joint=generate_states(p)
    times=np.array(p['times']);c=dict(domain=2.,horizon=.5,speed=.75,turn=3.,radius=.25)
    refs=[];reference_rows=[]
    for n,nh in [(97,72),(129,96)]:
        print(f'Numerical reference {n}x{n}x{nh}; 21 horizons; no training.',flush=True)
        clock=time.perf_counter();ref=solve(c,n,nh,times)
        refs.append(ref)
        reference_rows.append(dict(grid=[n,n,nh],seconds=time.perf_counter()-clock,steps=ref['steps'],dtmax=ref['dtmax']))
    reference=np.stack([interpolate(refs[-1],float(t),relative) for t in times])
    coarse_values=np.stack([interpolate(refs[0],float(t),relative) for t in times])
    reference_diff=[dict(time=float(t),**error(coarse_values[i],reference[i])) for i,t in enumerate(times)]
    # Reuse only the old solver-grid outputs as a consistency check, never old final-state queries.
    with np.load(ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz') as old:
        shared=[float(abs(refs[-1]['values'][float(t)]-v).max()) for t,v in zip(old['times'],old['values'])]
    assert max(shared)<.001
    reference_grad={float(t):[grid_gradient(ref,float(t),relative) for ref in refs] for t in p['gradient_times']}
    np.savez_compressed(OUT/'reference_values.npz',times=times,fine=reference,coarse=coarse_values)
    np.savez_compressed(OUT/'reference_gradients.npz',times=p['gradient_times'],
        fine=np.stack([reference_grad[t][1] for t in p['gradient_times']]),
        coarse=np.stack([reference_grad[t][0] for t in p['gradient_times']]))
    dump(OUT/'reference_checks.json',dict(helper=helper,builds=reference_rows,
         coarse_fine_value_errors=reference_diff,old_fine_snapshot_max_abs=shared,
         approximate_reference=True,old_final_states_queried=False))
    del refs
    predictions={};metrics=[];invariance=[];gradient_rows=[];control_rows=[];constraints=[];aliases=[]
    for name,path in MODELS.items():
        print('Evaluating fixed model '+name,flush=True)
        dump(OUT/'status.json',dict(status='evaluating models',model=name,training=False))
        if name.startswith('3D_'):
            model,ck=load_checkpoint(path)
        else:
            ck=torch.load(path,map_location='cpu',weights_only=True)
            model=JointSiren(ck['config']); model.load_state_dict(ck['model'],strict=True)
        model.eval();original={k:v.clone() for k,v in model.state_dict().items()}
        all_values=[]
        for i,t in enumerate(times):
            states=relative if name.startswith('3D_') else joint.reshape(-1,6)
            q=np.column_stack([np.full(len(states),t),states])
            if float(t) in reference_grad:
                values,g=model_grad(model,q)
                if name.startswith('3D_'):
                    # Map learned relative gradient to joint covectors for equal units/comparison.
                    z=torch.tensor(joint.reshape(-1,6))
                    gp=lift_covector(z,torch.tensor(np.repeat(g[:,1:],4,axis=0))).numpy()
                    g=np.column_stack([np.repeat(g[:,0],4),gp])
                row,controls,_,_=gradient_metrics(name,float(t),joint,g,*reference_grad[float(t)],c,p['switching_margins'])
                gradient_rows.append(row);control_rows.extend(controls)
                np.savez_compressed(OUT/f'gradients_{name}_{t:.2f}.npz',state_gradients=g[:,1:].reshape(-1,4,6))
            else:
                values=predict(model,q)
            pred=np.repeat(values[:,None],4,axis=1) if name.startswith('3D_') else values.reshape(-1,4)
            assert np.isfinite(pred).all();all_values.append(pred)
            truth=np.repeat(reference[i,:,None],4,axis=1)
            metrics.append(metric_row(name,t,pred,truth))
            spread=np.ptp(pred,axis=1)
            invariance.append(dict(model=name,time=float(t),mean_pose_spread=float(spread.mean()),
                p99_pose_spread=float(np.quantile(spread,.99)),max_pose_spread=float(spread.max()),
                translation_gap_mae=float(abs(pred[:,1]-pred[:,0]).mean()),
                rotation_gap_mae=float(abs(pred[:,2]-pred[:,0]).mean()),
                combined_gap_mae=float(abs(pred[:,3]-pred[:,0]).mean()),
                classification_inconsistent_group_fraction=float(np.mean((pred<=0).any(axis=1)!=(pred<=0).all(axis=1)))))
        pp=np.stack(all_values);predictions[name]=pp
        target=np.repeat((np.linalg.norm(relative[:,:2],axis=1)-c['radius'])[:,None],4,axis=1)
        constraints.append(dict(model=name,terminal_max_abs=float(abs(pp[0]-target).max()),
            maximum_obstacle_violation=float(max(0,(pp-target).max())),
            below_minus_radius_fraction=float(np.mean(pp[-1]<-c['radius']-1e-4)),
            temporal_increase_fraction=float(np.mean(np.diff(pp,axis=0)>1e-4))))
        if not name.startswith('3D_'):
            flat=joint.reshape(-1,6)
            for index,actor in [(2,'pursuer'),(5,'evader')]:
                mask=abs(flat[:,index])>=.8*np.pi
                shifted=flat[mask].copy()
                shifted[:,index]-=np.sign(shifted[:,index])*2*np.pi
                assert np.max(abs(shifted[:,index]))<=1.2*np.pi+1e-12
                alias=predict(model,np.column_stack([np.full(len(shifted),.5),shifted]))
                original_v=pp[-1].reshape(-1)[mask]
                aliases.append(dict(model=name,actor=actor,count=int(mask.sum()),
                    mean_abs_alias_gap=float(abs(alias-original_v).mean()),max_abs_alias_gap=float(abs(alias-original_v).max()),
                    classification_disagreement=float(np.mean((alias<=0)!=(original_v<=0)))))
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in original.items())
        assert all(param.grad is None for param in model.parameters())
    np.savez_compressed(OUT/'predictions.npz',times=times,**predictions)
    write_csv(OUT/'metrics.csv',metrics);dump(OUT/'metrics.json',metrics)
    final=[r for r in metrics if r['time']==.5]
    write_csv(OUT/'final_metrics.csv',final);dump(OUT/'final_metrics.json',final)
    for name,rows in [('invariance',invariance),('gradients',gradient_rows),('switching_signs',control_rows),('constraints',constraints),('heading_aliases',aliases)]:
        write_csv(OUT/(name+'.csv'),rows);dump(OUT/(name+'.json'),rows)
    # Pose samples are correlated: bootstrap group-averaged absolute errors.
    group_error={name:abs(v[-1]-reference[-1,:,None]).mean(axis=1) for name,v in predictions.items()}
    rng=np.random.default_rng(p['bootstrap']['seed']);intervals=[]
    indices=[rng.integers(0,len(relative),size=(50,len(relative))) for _ in range(40)]
    for old,new in p['bootstrap']['pairs']:
        a=group_error[old];b=group_error[new]
        reductions=np.concatenate([(a[ix].mean(axis=1)-b[ix].mean(axis=1)) for ix in indices])
        relative_changes=np.concatenate([100*(a[ix].mean(axis=1)-b[ix].mean(axis=1))/a[ix].mean(axis=1) for ix in indices])
        intervals.append(dict(old=old,new=new,mae_reduction=float(a.mean()-b.mean()),
            relative_improvement_percent=float(100*(a.mean()-b.mean())/a.mean()),
            mae_reduction_95_interval=np.quantile(reductions,[.025,.975]).tolist(),
            relative_improvement_percent_95_interval=np.quantile(relative_changes,[.025,.975]).tolist(),
            scope='Group sampling only; conditional on trained models and approximate reference. No training-seed or reference-grid uncertainty.'))
    dump(OUT/'grouped_bootstrap.json',intervals)
    fig,axes=plt.subplots(2,2,figsize=(11,8),layout='constrained')
    for name in MODELS:
        rows=[r for r in metrics if r['model']==name]
        axes[0,0].plot(times,[r['mae'] for r in rows],label=name)
        axes[0,1].plot(times,[r['iou'] for r in rows])
        axes[1,0].plot(times,[100*r['false_safe_fraction_of_reference_unsafe'] for r in rows])
        inv=[r for r in invariance if r['model']==name]
        axes[1,1].plot(times,[r['mean_pose_spread'] for r in inv])
    titles=[('Value MAE','m'),('Unsafe-set IoU','IoU'),('False-safe / reference-unsafe','%'),('Equivalent-pose prediction spread','m')]
    for ax,(title,ylabel) in zip(axes.flat,titles):
        ax.set(title=title,xlabel='Horizon [s]',ylabel=ylabel);ax.grid(alpha=.2)
    axes[0,0].legend();fig.savefig(OUT/'comparison.png',dpi=160);plt.close(fig)
    assert all(sha(ROOT/n)==h for n,h in p['protected_inputs'].items())
    assert p['source_hashes']=={f.name:sha(f) for f in SOURCES}
    result=dict(status='completed grouped development evaluation',training=False,optimizer_created=False,
        parameter_updates=0,old_final_states_queried=False,future_final_seed_used=False,
        protected_inputs_unchanged=True,protocol_sha256=sha(OUT/'protocol.json'),
        source_hashes=p['source_hashes'],seconds=time.perf_counter()-start,
        execution='managed process with main project interpreter; not VS Code debugger',
        relative_groups=len(relative),joint_queries_per_horizon=int(np.prod(joint.shape[:2])),
        final_metrics=final,bootstrap=intervals,closed_loop_rollouts_performed=False)
    dump(OUT/'manifest.json',result)
    dump(OUT/'status.json',dict(status='completed',training=False))
    print(json.dumps(dict(final=final,bootstrap=intervals),indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--evaluate',action='store_true')
    args=ap.parse_args()
    if args.prepare==args.evaluate:
        ap.error('Choose exactly one of --prepare or --evaluate')
    prepare() if args.prepare else evaluate()

"""Verify saved physics audit arrays and report; no new model queries."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm,ListedColormap,BoundaryNorm
import audit_local_physics as audit
import evaluate as ev


def report():
    out=audit.OUT;p=json.loads((out/'protocol.json').read_text())
    assert p['source_hashes']=={s.name:ev.sha(s) for s in audit.SOURCES}
    summaries=json.loads((out/'summaries.json').read_text())
    align=json.loads((out/'gradient_alignments.json').read_text())
    with np.load(out/'local_queries.npz') as f:context={k:f[k].copy() for k in f.files}
    shape=tuple(context['shape']);results={};margins=[];gradient_checks=0;term_checks=0
    base_mask=(np.sign(context['coarse_coefficient'])==np.sign(context['fine_coefficient']))&(abs(context['coarse_coefficient'])>.01)&(abs(context['fine_coefficient'])>.01)
    for name in audit.MODELS:
        with np.load(out/f'local_{name}.npz') as f:local={k:f[k].copy() for k in f.files}
        with np.load(out/f'global_{name}.npz') as f:global_={k:f[k].copy() for k in f.files}
        for data in [local,global_]:
            assert np.array_equal(data['residual'],np.maximum(data['pde'],data['obstacle']))
            assert np.array_equal(data['pde'],data['time_derivative']-data['hamiltonian'])
            assert np.max(abs(data['hamiltonian']-data['reflected_hamiltonian']))<1e-6
            assert all(np.isfinite(v).all() for v in data.values())
            term_checks+=len(data['residual'])
        summary=next(s for s in summaries if s['model']==name)
        wrong=base_mask&(np.sign(local['evader_coefficient'])!=np.sign(context['fine_coefficient']))
        assert int(wrong.sum())==summary['local_wrong_count']
        assert np.isclose(audit.stats(local,wrong)['vi_mae'],summary['local']['reference_stable_wrong']['vi_mae'],atol=1e-12)
        late=global_['q'][:,0]>=.4
        assert np.isclose(audit.stats(global_,late)['vi_mae'],summary['global_late']['vi_mae'],atol=1e-12)
        assert np.isclose(audit.auc(abs(local['residual'][base_mask]),wrong[base_mask]),summary['wrong_sign_auc_from_absolute_residual'],atol=1e-12)
        for margin in [.005,.01,.02]:
            stable=(np.sign(context['coarse_coefficient'])==np.sign(context['fine_coefficient']))&(abs(context['coarse_coefficient'])>margin)&(abs(context['fine_coefficient'])>margin)
            bad=stable&(np.sign(local['evader_coefficient'])!=np.sign(context['fine_coefficient']))
            good=stable&~bad
            margins.append(dict(model=name,margin=margin,stable_count=int(stable.sum()),wrong_count=int(bad.sum()),
                wrong_vi_mae=float(abs(local['residual'][bad]).mean()) if bad.any() else None,
                right_vi_mae=float(abs(local['residual'][good]).mean()) if good.any() else None,
                residual_wrong_sign_auc=audit.auc(abs(local['residual'][stable]),bad[stable])))
        with np.load(out/f'physics_parameter_gradients_{name}.npz') as f:vectors={k:f[k].copy() for k in f.files}
        for row in align:
            if row['model']!=name:continue
            a=vectors[row['left']];b=vectors[row['right']];den=np.linalg.norm(a)*np.linalg.norm(b)
            assert np.isclose(np.linalg.norm(a),row['left_norm'],atol=1e-10,rtol=1e-12)
            if den:assert np.isclose(np.dot(a,b)/den,row['cosine'],atol=1e-12)
            gradient_checks+=1
        results[name]=dict(local=local,global_=global_,wrong=wrong,right=base_mask&~wrong,late=late,vectors=vectors)
    ev.dump(out/'margin_sensitivity.json',margins);ev.write_csv(out/'margin_sensitivity.csv',margins)
    times=context['elapsed'].reshape(shape)[:,0,0];offsets=context['heading_offset'].reshape(shape)[0,:,0]
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    maxr=max(float(abs(r['local']['residual']).max()) for r in results.values())
    for i,name in enumerate(audit.MODELS):
        result=results[name];local=result['local']
        field=abs(local['residual']).reshape(shape)[:,:,0].T
        im=axes[i,0].pcolormesh(times,offsets,np.maximum(field,1e-7),shading='auto',norm=LogNorm(vmin=1e-4,vmax=maxr))
        category=np.full(len(base_mask),-1);category[result['right']]=0;category[result['wrong']]=1
        classes=category.reshape(shape)[:,:,0].T
        cm=axes[i,1].pcolormesh(times,offsets,classes,shading='auto',cmap=ListedColormap(['#aaaaaa','#4c9f70','#df644b']),norm=BoundaryNorm([-1.5,-.5,.5,1.5],3))
        for ax in axes[i]:
            ax.set(xlabel='Elapsed time on fixed path [s]',ylabel='Heading offset [rad]')
        axes[i,0].set_title(name+': native absolute VI residual')
        axes[i,1].set_title(name+': reference-stable turn agreement')
    fig.colorbar(im,ax=axes[:,0],label='Native |R|')
    cb=fig.colorbar(cm,ax=axes[:,1],ticks=[-1,0,1]);cb.ax.set_yticklabels(['Unstable reference','Same sign','Wrong sign'])
    fig.savefig(out/'residual_and_turn_maps.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4),layout='constrained')
    for ax,name in zip(axes,audit.MODELS):
        result=results[name]
        arrays=[('Global late audit',abs(result['global_']['residual'][result['late']])),
                ('Local wrong sign',abs(result['local']['residual'][result['wrong']])),
                ('Local right sign',abs(result['local']['residual'][result['right']]))]
        for label,v in arrays:
            ax.plot(np.maximum(np.sort(v),1e-7),np.arange(1,len(v)+1)/len(v),label=label)
        ax.set(title=name,xlabel='Native absolute VI residual',ylabel='Fraction of audit points',xscale='log')
        ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.savefig(out/'residual_distributions.png',dpi=160);plt.close(fig)
    names=list(results['4C']['vectors'])
    short=['global','global late','local','local wrong','local right','switch weight','heading weight','early weight']
    fig,axes=plt.subplots(1,2,figsize=(14,6),layout='constrained')
    for ax,name in zip(axes,audit.MODELS):
        matrix=np.array([[next(r['cosine'] for r in align if r['model']==name and r['left']==a and r['right']==b) for b in names] for a in names],dtype=float)
        im=ax.imshow(matrix,vmin=-1,vmax=1,cmap='coolwarm')
        ax.set(xticks=range(len(names)),xticklabels=short,yticks=range(len(names)),yticklabels=short,title=name+' physics-loss gradient cosines')
        ax.tick_params(axis='x',rotation=60)
        for i in range(len(names)):
            for j in range(len(names)):ax.text(j,i,f'{matrix[i,j]:.2f}',ha='center',va='center',fontsize=6)
    fig.colorbar(im,ax=axes,label='Cosine; no parameter step')
    fig.savefig(out/'physics_gradient_alignment.png',dpi=160);plt.close(fig)
    lines=['# Local physics-loss audit','',
        'The native physics loss exposes this failure region: its residuals and local parameter-gradient norms are large. In 4C, however, residual magnitude does not distinguish wrong from right turning signs within the local map. The broad-domain physics gradient is nearly orthogonal to the local wrong-region gradient. This motivates a controlled sampling/priority test, not a claim that the loss is satisfied or that reweighting is already a controller fix.','',
        'Both models remain unchanged. The fixed audit used 16,884 correlated local queries (21 times × 201 heading offsets × four poses) and 32,768 fresh global collocation points per model. Global distributions follow each model own training coordinates; they are not identical physical encounter distributions. Existing 161/193 reference queries identify diagnostic sign-agreement subsets. No reference solve, optimizer, parameter step, rollout or final-test query occurred.','',
        '| Model | Global native VI MAE | Global late-time VI MAE | Local wrong-sign VI MAE | Local right-sign VI MAE | Wrong-sign AUC from residual |',
        '|---|---:|---:|---:|---:|---:|']
    for s in summaries:
        lines.append(f"| {s['model']} | {s['global_all']['vi_mae']:.6f} | {s['global_late']['vi_mae']:.6f} | {s['local']['reference_stable_wrong']['vi_mae']:.6f} | {s['local']['reference_stable_right']['vi_mae']:.6f} | {s['wrong_sign_auc_from_absolute_residual']:.3f} |")
    lines += ['',
        'For 4C the wrong-sign region residual is about 12.1 times its global mean, or 6.4 times its global late-time mean. The four initial failure poses have absolute residuals from 0.11659 to 0.25783, placing them around the 96th–99th percentiles of its global late-time audit. The 3D initial residual is 0.41192, around the 99.88th percentile. The failure is therefore not hidden by a locally tiny residual.','',
        'On the selected wrong-sign subsets, the equation branch is active everywhere; the obstacle branch fraction is zero. Thus obstacle masking does not explain these particular wrong-sign points. Large raw equation error elsewhere in the global domain is not automatically a defect, because an HJI obstacle solution permits an inactive equation branch. Native residual scaling is the implementation existing PDE/obstacle scaling and is not a value-error distance or a probability.','',
        '![Residual versus turning maps](residual_and_turn_maps.png)','',
        'The maps show canonical-pose slices; the table includes all four poses. The reference-stable mask requires both 161/193 coefficients to have the same sign and absolute magnitude above .01 m/rad. Nearby points and poses are correlated. These local wrong-sign fractions are not collision rates or independent-encounter estimates.','',
        '![Residual distributions](residual_distributions.png)','',
        'For 3D_Long, larger residuals rank wrong-sign points reasonably well within this map (AUC .881). For 4C the local distributions overlap (AUC .482), so prioritizing the largest local residual alone does not selectively identify wrong directions. Residual size still flags the broader difficult region relative to the global sample. The .005/.02 margin sensitivity is saved separately; it does not create an independent validation set. Squaring a fixed nonnegative residual changes emphasis but preserves its rank ordering.','',
        'Physics-loss gradient comparisons at the fixed parameters:','',
        '| Model | Global vs local-wrong cosine | Global-late vs local-wrong | Local-uniform vs local-wrong | Local-wrong vs local-right |',
        '|---|---:|---:|---:|---:|']
    pairs=[('global_all','local_wrong'),('global_late','local_wrong'),('local_uniform','local_wrong'),('local_wrong','local_right')]
    for name in audit.MODELS:
        values=[next(r['cosine'] for r in align if r['model']==name and r['left']==a and r['right']==b) for a,b in pairs]
        lines.append('| '+name+' | '+' | '.join(f'{v:.4f}' for v in values)+' |')
    lines += ['',
        '![Physics-loss gradient directions](physics_gradient_alignment.png)','',
        'Local wrong-region gradient norms are about 134.7 (4C) and 192.4 (3D_Long), versus about 1.67 for their respective global mean objectives. There is a strong local parameter signal in these samples. The nearly orthogonal global/local gradients show that reducing a broad mean loss is not equivalent to concentrating on this region. These are ordinary objective gradients, not actual Adam update directions or proof that a step would correct a control sign.','',
        'The 3D local wrong/right physics gradients oppose one another (cosine -.850), illustrating a possible objective tradeoff. Fixed weighting toward the central heading region or the network switching region changes the physics-loss direction, but does not show a consistent advantage across both models. A weighting must be tested on broad value/control evaluations rather than selected from cosine alone. The reference-informed wrong/right masks here are diagnostic labels, not a proposed reference-free training sampler.','',
        'Neither fresh 32,768-point global sample placed a point inside the specified late-time intrinsic box around the failure. That is a small sampling snapshot, not evidence that the original training never visited it, and cannot establish sampling as the causal defect. The single local map was deliberately chosen after a failure.','',
        'The formal coefficient reflection `a -> -a` leaves the Hamiltonian magnitudes unchanged. This is correct max/min game algebra, not a sign bug or a realizable alternative network field. Terminal propagation, global consistency and value geometry determine the direction. The observed residual is nevertheless large here, so a sign-insensitive Hamiltonian argument is not evidence that this failure has zero loss.','',
        'A justified next experiment is a fixed-budget, physics-only residual-coverage test with explicit sampling/evaluation overhead recorded and fresh broad development comparisons. It should avoid using reference sign labels or value bounds in updates and retain checks for degraded correct regions, since local loss objectives can conflict. This audit does not establish that sampling alone will fix the displaced transition, and it introduces no new training or production-controller change.','',
        'See [methodology](METHODOLOGY.md), [fixed protocol](protocol.json), [all summaries](summaries.json), [margin sensitivity](margin_sensitivity.csv), [gradient alignments](gradient_alignments.csv), and [execution manifest](manifest.json).','']
    (out/'README.md').write_text('\n'.join(lines),encoding='utf-8')
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    ev.dump(out/'verification.json',dict(status='passed',saved_point_term_checks=term_checks,
        saved_parameter_gradient_alignment_checks=gradient_checks,new_model_queries=False,parameter_updates=0))
    ev.dump(out/'output_manifest.json',dict(status='verified saved local physics audit',
        outputs={str(f.relative_to(out)):ev.sha(f) for f in sorted(out.rglob('*')) if f.is_file() and f.name!='output_manifest.json'},
        report_source_sha256=ev.sha(Path(__file__)),parameter_updates=0))
    print(json.dumps(dict(term_checks=term_checks,gradient_alignments_verified=gradient_checks,margin_sensitivity=margins),indent=2))


if __name__=='__main__':report()

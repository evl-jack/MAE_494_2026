"""Physics-loss visibility audit, fixed networks, no parameter updates."""
import argparse
import json
import math
import shutil
import time
from pathlib import Path

import numpy as np
import torch
from scipy.stats import rankdata
import evaluate as ev
import rollouts as ro
import network
import deepreach
import joint6d

HERE=Path(__file__).resolve().parent
REF=HERE/'local_reference_refinement'
OUT=HERE/'local_physics_audit'
N=32768
MODELS=['4C','3D_Long']
SOURCES=[Path(__file__),HERE/'network.py',HERE/'evaluate.py',HERE/'rollouts.py',
         ev.ROOT/'deepreach.py',ev.ROOT/'joint6d.py',ev.ROOT/'reference.py']


def parts(model,q,graph=False):
    q=q.detach().requires_grad_(True)
    value=model(q);g=torch.autograd.grad(value.sum(),q,create_graph=graph)[0]
    c=model.c
    if c['problem']=='JointAir3D6D':
        z=q[:,1:];target=joint6d.target(z,c)
        a=g[:,6];b=g[:,3]
        drift=c['speed']*(z[:,2].cos()*g[:,1]+z[:,2].sin()*g[:,2]+z[:,5].cos()*g[:,4]+z[:,5].sin()*g[:,5])
        h=joint6d.hamiltonian(z,g[:,1:],c)
    else:
        r=q[:,1:];target=deepreach.target(r,c)
        a=r[:,1]*g[:,1]-r[:,0]*g[:,2]-g[:,3];b=g[:,3]
        drift=c['speed']*((r[:,2].cos()-1)*g[:,1]+r[:,2].sin()*g[:,2])
        h=deepreach.hamiltonian(r,g[:,1:],c)
    equation=g[:,0]-h;obstacle=value-target
    residual=torch.maximum(equation,obstacle)
    # Formal pointwise Hamiltonian arguments, not a realizable network change.
    reflected=drift+c['turn']*(-a).abs()-c['turn']*b.abs()
    return dict(value=value,time_derivative=g[:,0],hamiltonian=h,pde=equation,
        obstacle=obstacle,residual=residual,evader_coefficient=a,pursuer_coefficient=b,
        reflected_hamiltonian=reflected)


def fixtures():
    class Analytic(torch.nn.Module):
        def __init__(self,joint):
            super().__init__();self.joint=joint
            self.c=dict(problem='JointAir3D6D' if joint else 'Air3D',speed=.75,turn=3.,radius=.25)
        def forward(self,q):
            r=joint6d.relative_state(q[:,1:]) if self.joint else q[:,1:]
            return r[:,0]+2*r[:,1]+r[:,2].sin()-.4*q[:,0]
    gen=torch.Generator().manual_seed(991762)
    q6=torch.rand(64,7,generator=gen,dtype=torch.float64)-.5;q6[:,0]+=.5
    r=joint6d.relative_state(q6[:,1:]);q3=torch.cat([q6[:,:1],r],dim=-1)
    p6=parts(Analytic(True),q6);p3=parts(Analytic(False),q3)
    a=r[:,1]-2*r[:,0]-r[:,2].cos();b=r[:,2].cos()
    h=.75*((r[:,2].cos()-1)+2*r[:,2].sin())+3*a.abs()-3*b.abs()
    assert (p3['hamiltonian']-h).abs().max()<1e-12
    assert (p3['residual']-p6['residual']).abs().max()<1e-12
    native6=network.residual(Analytic(True),q6)[0]
    native3=deepreach.residual(Analytic(False),q3,Analytic(False).c)[0]
    assert (native6-p6['residual']).abs().max()==0 and (native3-p3['residual']).abs().max()==0
    assert (p6['hamiltonian']-p6['reflected_hamiltonian']).abs().max()<1e-12
    return dict(status='passed',analytic_hamiltonian_max_abs=float((p3['hamiltonian']-h).abs().max()),
        invariant_residual_max_abs=float((p3['residual']-p6['residual']).abs().max()),
        native_residuals_match=True,pointwise_formal_sign_reflection=True)


def prepare():
    check=fixtures()
    if OUT.exists():raise FileExistsError('Local physics audit already exists')
    OUT.mkdir();(OUT/'sources').mkdir()
    protected={str(p.relative_to(ev.ROOT)):ev.sha(p) for p in ev.ROOT.rglob('checkpoint*.pt')}
    inputs=[REF/'fixed_queries.npz',REF/'reference_161_120.npz',REF/'reference_193_144.npz',
            ev.ROOT/'evaluation/reserved_final_states/states.npz']
    for path in inputs:protected[str(path.relative_to(ev.ROOT))]=ev.sha(path)
    protocol=dict(status='frozen before new residual or parameter-gradient queries',date='2026-10-28',
        purpose='Post-hoc development loss-visibility audit of group 603; not independent final evaluation',
        models=MODELS,local='Saved 21 early times x 201 physical heading offsets, lifted to all four equivalent poses',
        reference='Existing 161/193 local queried maps only. No new solver run; labels used for diagnostics only.',
        local_reference_margin=.01,additional_margins=[.005,.02],
        stable='161/193 evader coefficients have same sign, both abs > margin',
        global_samples=N,global_zero_time=N//8,global_seeds={'4C':991760,'3D_Long':991761},
        global_distribution='Fresh full-horizon collocation audit from each model own training box; last 1/8 at time zero. Not a replay of training coverage.',
        late_global='time remaining >= .4 s',
        local_physics_terms=['V_tau','H','V_tau-H','V-l','max(V_tau-H,V-l)','actor coefficients'],
        summaries=['mean/quantiles/branch activity','wrong/right reference-stable subsets','absolute/squared residual rankings',
            'residual correlations with value/coefficient errors','descriptive wrong-sign ROC AUC and global percentiles',
            'global intrinsic-window occupancy (rx/ry within .1 and heading within .2 rad of initial case, tau>=.4)',
            'formal Hamiltonian argument reflection a -> -a; not a feasible model update'],
        gradient_objectives=['global_all','global_late','local_uniform','local_wrong','local_right',
            'local_network_switch_weighted','local_initial_heading_weighted','local_early_weighted'],
        weighting='Physics residual only. Fixed detached weights: network |a|<=.02 gets 5x; |heading offset|<=.05 gets 5x; elapsed<=.05 gets 2x. Normalize each objective to mean one.',
        wrong_right_weights='Reference-informed subset masks for diagnosis only, not a proposed reference-free training sampler',
        gradient_use='Parameter gradients, norms and cosines only. No optimizer, step, line search, checkpoint candidate or reference-error minimization.',
        limitations='Local points/poses are correlated; all regions selected from one known development failure. No inferential p-values or generalization claim.',
        source_hashes={s.name:ev.sha(s) for s in SOURCES},protected_inputs=protected,helper_checks=check,
        training=False,parameter_updates=0,optimizer_created=False,threads=2)
    ev.dump(OUT/'protocol.json',protocol)
    for src in SOURCES:shutil.copy2(src,OUT/'sources'/src.name)
    print('Analytic fixtures passed; physics audit protocol frozen.',flush=True)


def sample_global(c,seed):
    gen=torch.Generator().manual_seed(seed)
    joint=c['problem']=='JointAir3D6D';dim=7 if joint else 4
    q=2*torch.rand(N,dim,generator=gen)-1
    scales=network.scales(c) if joint else [c['horizon'],c['domain'],c['domain'],c['angle_factor']*math.pi]
    q*=torch.tensor(scales)
    q[:,0]=torch.rand(N,generator=gen)*c['horizon'];q[-N//8:,0]=0
    return q.numpy()


def local_queries():
    with np.load(REF/'fixed_queries.npz') as f:
        times=f['elapsed_times'];path=f['joint_path'];offsets=f['heading_offsets'];initial=f['initial_poses']
    poses=[]
    mid0=(initial[0,:2]+initial[0,3:5])/2
    for p in range(4):
        alpha=initial[p,5]-initial[0,5];co,si=np.cos(alpha),np.sin(alpha)
        rot=np.array([[co,-si],[si,co]])
        shift=(initial[p,:2]+initial[p,3:5])/2-mid0@rot.T
        base=path.copy();base[:,:2]=path[:,:2]@rot.T+shift;base[:,3:5]=path[:,3:5]@rot.T+shift
        base[:,[2,5]]=(path[:,[2,5]]+alpha+np.pi)%(2*np.pi)-np.pi
        z=np.repeat(base[:,None,:],len(offsets),axis=1);z[:,:,5]+=offsets[None,:];poses.append(z)
    z=np.stack(poses,axis=2)  # time, offset, pose, state
    expected=ro.relative(z[:,:,0,:])
    assert np.max(abs(ro.relative(z)-expected[:,:,None,:]))<1e-12
    tau=np.broadcast_to((.5-times)[:,None,None],z.shape[:-1])
    heading=np.broadcast_to(offsets[None,:,None],z.shape[:-1])
    elapsed=np.broadcast_to(times[:,None,None],z.shape[:-1])
    q6=np.column_stack([tau.ravel(),z.reshape(-1,6)])
    q3=np.column_stack([tau.ravel(),ro.relative(z).reshape(-1,3)])
    with np.load(REF/'reference_161_120.npz') as a,np.load(REF/'reference_193_144.npz') as b:
        coarse=np.repeat(a['coefficients'][:,:,0,None],4,axis=2).ravel()
        fine=np.repeat(b['coefficients'][:,:,0,None],4,axis=2).ravel()
        values=np.repeat(b['values'][:,:,None],4,axis=2).ravel()
    return q6,q3,dict(coarse_coefficient=coarse,fine_coefficient=fine,fine_value=values,
        heading_offset=heading.ravel(),elapsed=elapsed.ravel(),shape=np.array(z.shape[:-1]))


def query_parts(model,q):
    chunks={}
    for i in range(0,len(q),1024):
        result=parts(model,torch.tensor(q[i:i+1024],dtype=torch.float32))
        for key,value in result.items():chunks.setdefault(key,[]).append(value.detach().numpy())
    result={k:np.concatenate(v) for k,v in chunks.items()}
    assert all(np.isfinite(v).all() for v in result.values())
    return result


def stats(result,mask):
    if not mask.any():return dict(count=0)
    r=abs(result['residual'][mask]);eq=abs(result['pde'][mask]);b=result['obstacle'][mask]
    return dict(count=int(mask.sum()),vi_mae=float(r.mean()),vi_mse=float((r*r).mean()),
        vi_p50=float(np.quantile(r,.5)),vi_p90=float(np.quantile(r,.9)),vi_p99=float(np.quantile(r,.99)),
        vi_max=float(r.max()),pde_mae=float(eq.mean()),mean_obstacle_gap=float((-b).mean()),
        obstacle_branch_fraction=float(np.mean(result['obstacle'][mask]>=result['pde'][mask])))


def correlation(a,b):
    if len(a)<2 or np.std(a)<1e-15 or np.std(b)<1e-15:return None
    return float(np.corrcoef(a,b)[0,1])


def auc(scores,positive):
    np_=int(positive.sum());nn=len(positive)-np_
    if not np_ or not nn:return None
    ranks=rankdata(scores,method='average')
    return float((ranks[positive].sum()-np_*(np_+1)/2)/(np_*nn))


def parameter_gradients(model,q,objectives):
    params=list(model.parameters());size=sum(p.numel() for p in params)
    vectors={name:np.zeros(size,dtype=np.float64) for name in objectives}
    for i in range(0,len(q),1024):
        rr=parts(model,torch.tensor(q[i:i+1024],dtype=torch.float32),graph=True)['residual'].abs()
        active=[name for name,w in objectives.items() if np.any(w[i:i+1024])]
        for j,name in enumerate(active):
            w=torch.tensor(objectives[name][i:i+1024],dtype=torch.float32)
            loss=(rr*w).sum()
            grads=torch.autograd.grad(loss,params,retain_graph=j<len(active)-1,allow_unused=True)
            vector=np.concatenate([(torch.zeros_like(p) if g is None else g).detach().numpy().ravel() for p,g in zip(params,grads)])
            assert np.isfinite(vector).all();vectors[name]+=vector
    return vectors


def normalize(w):
    w=np.asarray(w,dtype=float)
    return w/w.sum() if w.sum() else w


def run():
    p=json.loads((OUT/'protocol.json').read_text())
    if (OUT/'status.json').exists():raise FileExistsError('Audit already started/completed')
    assert p['source_hashes']=={s.name:ev.sha(s) for s in SOURCES}
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    torch.set_num_threads(2);start=time.perf_counter()
    ev.dump(OUT/'status.json',dict(status='auditing fixed networks',training=False))
    q6,q3,context=local_queries();np.savez_compressed(OUT/'local_queries.npz',q6=q6,q3=q3,**context)
    stable=(np.sign(context['coarse_coefficient'])==np.sign(context['fine_coefficient']))&(abs(context['coarse_coefficient'])>.01)&(abs(context['fine_coefficient'])>.01)
    models=ro.load_models();summaries=[];alignments=[]
    for name in MODELS:
        print('Physics visibility and parameter-gradient audit: '+name,flush=True)
        model=models[name];original={k:v.clone() for k,v in model.state_dict().items()}
        qlocal=q6 if name=='4C' else q3
        qglobal=sample_global(model.c,p['global_seeds'][name])
        local=query_parts(model,qlocal);global_=query_parts(model,qglobal)
        np.savez_compressed(OUT/f'local_{name}.npz',**local)
        np.savez_compressed(OUT/f'global_{name}.npz',q=qglobal,**global_)
        wrong=stable&(np.sign(local['evader_coefficient'])!=np.sign(context['fine_coefficient']))
        right=stable&~wrong;late=qglobal[:,0]>=.4
        reference=np.sort(abs(global_['residual'][late]));local_rank=np.searchsorted(reference,abs(local['residual']),side='right')/len(reference)
        value_error=abs(local['value']-context['fine_value'])
        coeff_error=abs(local['evader_coefficient']-context['fine_coefficient'])
        magnitude_error=abs(abs(local['evader_coefficient'])-abs(context['fine_coefficient']))
        regret=3*abs(context['fine_coefficient'])-3*np.sign(local['evader_coefficient'])*context['fine_coefficient']
        local_masks=dict(all=np.ones(len(qlocal),dtype=bool),reference_stable_wrong=wrong,
            reference_stable_right=right,reference_unstable=~stable,
            network_switch=abs(local['evader_coefficient'])<=.02,
            initial_heading_window=abs(context['heading_offset'])<=.05)
        local_stats={key:stats(local,mask) for key,mask in local_masks.items()}
        for key,mask in local_masks.items():
            if mask.any():
                local_stats[key].update(value_mae=float(value_error[mask].mean()),
                    signed_coefficient_mae=float(coeff_error[mask].mean()),
                    mean_reference_hamiltonian_shortfall=float(regret[mask].mean()),
                    median_global_late_residual_percentile=float(100*np.median(local_rank[mask])))
        rstate=ro.relative(qglobal[:,1:]) if name=='4C' else qglobal[:,1:].copy()
        central=(context['elapsed']==0)&(abs(context['heading_offset'])<1e-12)
        anchor=ro.relative(q6[central,1:])[0]
        angle=(rstate[:,2]-anchor[2]+np.pi)%(2*np.pi)-np.pi
        window=late&(abs(rstate[:,0]-anchor[0])<=.1)&(abs(rstate[:,1]-anchor[1])<=.1)&(abs(angle)<=.2)
        consistency=float(abs(local['hamiltonian']-local['reflected_hamiltonian']).max())
        assert consistency<1e-6
        summary=dict(model=name,local=local_stats,
            global_all=stats(global_,np.ones(len(qglobal),dtype=bool)),global_late=stats(global_,late),
            snapshot_global_intrinsic_window_count=int(window.sum()),
            snapshot_global_count=len(qglobal),snapshot_late_count=int(late.sum()),
            local_reference_stable_count=int(stable.sum()),local_wrong_count=int(wrong.sum()),
            wrong_sign_auc_from_absolute_residual=auc(abs(local['residual'][stable]),wrong[stable]),
            residual_value_error_correlation=correlation(abs(local['residual']),value_error),
            residual_signed_coefficient_error_correlation=correlation(abs(local['residual']),coeff_error),
            residual_coefficient_magnitude_error_correlation=correlation(abs(local['residual']),magnitude_error),
            formal_sign_reflection_hamiltonian_max_abs=consistency,
            initial=[dict(pose=i,value=float(local['value'][j]),residual=float(local['residual'][j]),
                pde=float(local['pde'][j]),obstacle=float(local['obstacle'][j]),
                evader_coefficient=float(local['evader_coefficient'][j]),reference_coefficient=float(context['fine_coefficient'][j]),
                reference_value=float(context['fine_value'][j]),global_late_residual_percentile=float(local_rank[j]*100))
                for i,j in enumerate(np.flatnonzero(central))])
        ev.dump(OUT/f'summary_{name}.json',summary);summaries.append(summary)
        # All weights are fixed/detached; reference wrong/right masks are diagnostic only.
        global_weights=dict(global_all=normalize(np.ones(len(qglobal))),global_late=normalize(late))
        local_weights=dict(local_uniform=normalize(np.ones(len(qlocal))),local_wrong=normalize(wrong),local_right=normalize(right),
            local_network_switch_weighted=normalize(1+4*(abs(local['evader_coefficient'])<=.02)),
            local_initial_heading_weighted=normalize(1+4*(abs(context['heading_offset'])<=.05)),
            local_early_weighted=normalize(1+(context['elapsed']<=.05)))
        vectors=parameter_gradients(model,qglobal,global_weights)
        vectors.update(parameter_gradients(model,qlocal,local_weights))
        np.savez_compressed(OUT/f'physics_parameter_gradients_{name}.npz',**vectors)
        gradient_rows=[]
        for left in vectors:
            for right_name in vectors:
                a=vectors[left];b=vectors[right_name];den=np.linalg.norm(a)*np.linalg.norm(b)
                gradient_rows.append(dict(model=name,left=left,right=right_name,
                    left_norm=float(np.linalg.norm(a)),right_norm=float(np.linalg.norm(b)),
                    cosine=float(np.dot(a,b)/den) if den else None))
        alignments.extend(gradient_rows)
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in original.items())
        assert all(param.grad is None for param in model.parameters())
    ev.dump(OUT/'summaries.json',summaries);ev.dump(OUT/'gradient_alignments.json',alignments);ev.write_csv(OUT/'gradient_alignments.csv',alignments)
    assert all(ev.sha(ev.ROOT/n)==h for n,h in p['protected_inputs'].items())
    assert p['source_hashes']=={s.name:ev.sha(s) for s in SOURCES}
    ev.dump(OUT/'manifest.json',dict(status='completed local physics-loss audit',training=False,optimizer_created=False,
        parameter_updates=0,models_unchanged=True,protected_inputs_unchanged=True,old_final_states_queried=False,
        protocol_sha256=ev.sha(OUT/'protocol.json'),seconds=time.perf_counter()-start,
        execution='Managed process with main project interpreter; not VS Code debugger',
        reference_solve_performed=False,model_step_performed=False))
    ev.dump(OUT/'status.json',dict(status='completed',training=False))
    print(json.dumps(summaries,indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--evaluate',action='store_true')
    a=ap.parse_args()
    if a.prepare==a.evaluate:ap.error('Choose exactly one action')
    prepare() if a.prepare else run()

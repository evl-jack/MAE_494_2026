"""Replay saved controls and summarize closed-loop tests without model queries."""
import argparse
import json
import math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import rollouts as ro
import evaluate as ev


def check_reference_interpolation():
    x=np.linspace(-2,2,5);theta=np.linspace(-np.pi,np.pi,8,endpoint=False)
    xx,yy,hh=np.meshgrid(x,x,theta,indexing='ij')
    ref=dict(x=x,theta=theta,dx=1.,dtheta=np.pi/4,
             values={t:t*xx+2*yy+np.sin(hh) for t in [0.,.25,.5]})
    policy=ro.ReferenceControl(ref)
    observed=policy.gradient(.125,np.array([[.2,.3,0.]]))[0]
    expected=np.array([.125,2.,np.sin(np.pi/4)/(np.pi/4)])
    assert np.max(abs(observed-expected))<1e-12
    return dict(status='passed',linear_time_spatial_periodic_gradient_max_abs=float(np.max(abs(observed-expected))))


def replay(initial,dt,data):
    z=np.repeat(initial[None],len(ro.POLICIES)**2,axis=0)
    upper=np.linalg.norm(z[:,:,:2]-z[:,:,3:5],axis=-1)
    lower=upper.copy();first=np.where(upper<=ro.RADIUS,0.,np.inf)
    examples=[z[:,:16].astype(np.float32)]
    for step,action in enumerate(data['controls']):
        u=action[...,0].astype(float);d=action[...,1].astype(float)
        assert np.isin(action,[-3,0,3]).all()
        m,lo,hit=ro.step_minimum(z,u,d,dt)
        upper=np.minimum(upper,m);lower=np.minimum(lower,lo);first=np.minimum(first,step*dt+hit)
        z=ro.advance(z,u,d,dt);examples.append(z[:,:16].astype(np.float32))
    expected=dict(minimum_distance_upper=upper,minimum_distance_lower=lower,
        first_sampled_collision_time=first,definite_collision=upper<=ro.RADIUS,
        possible_collision=lower<=ro.RADIUS,switch_counts=np.count_nonzero(np.diff(data['controls'],axis=0),axis=0),
        final_states=z,example_states=np.stack(examples))
    for name,value in expected.items():
        assert np.array_equal(value,data[name]),name
    return len(data['controls'])*len(ro.POLICIES)**2*len(initial)


def report(reuse_replay=False):
    out=ro.OUT
    protocol=json.loads((out/'protocol.json').read_text())
    assert protocol['source_hashes']=={p.name:ev.sha(p) for p in ro.SOURCES}
    interpolation_check=check_reference_interpolation()
    with np.load(out/'initial_states.npz') as f:
        initial=f['joint'].reshape(-1,6);relative=f['relative'];ids=f['group_ids'];vf=f['fine_value']
        subsets={k:f[k] for k in protocol['subsets']}
    results={};replayed=0
    previous_checks=None
    if reuse_replay:
        saved=json.loads((out/'output_manifest.json').read_text())
        for name in ['initial_states.npz','protocol.json','rollouts_dt_0.010.npz','rollouts_dt_0.005.npz']:
            assert ev.sha(out/name)==saved['files'][name]
        previous_checks=json.loads((out/'replay_checks.json').read_text())
        assert previous_checks['status']=='passed'
    for dt in ro.DT:
        with np.load(out/f'rollouts_dt_{dt:.3f}.npz') as f:
            data={k:f[k].copy() for k in f.files}
        if not reuse_replay:
            print(f'Replaying saved controls at dt={dt}; no model queries.',flush=True)
            replayed+=replay(initial,dt,data)
        results[dt]=data
    if previous_checks:
        replayed=previous_checks['control_update_trajectories_replayed']
    rows=json.loads((out/'policy_pair_metrics.json').read_text())
    for row in rows:
        data=results[row['dt']];mask=subsets[row['subset']]
        k=ro.POLICIES.index(row['evader'])*len(ro.POLICIES)+ro.POLICIES.index(row['pursuer'])
        assert row['definite_collision_count']==int(data['definite_collision'][k,mask].sum())
        assert row['possible_collision_count']==int(data['possible_collision'][k,mask].sum())
        assert np.isclose(row['mean_minimum_separation'],data['minimum_distance_upper'][k,mask].mean(),atol=1e-12,rtol=1e-12)
    assert all(ev.sha(ev.ROOT/n)==h for n,h in protocol['protected_inputs'].items())
    selected=[r for r in rows if r['dt']==.005 and r['pursuer']=='reference' and r['subset']=='reference_safe_margin_0.01']
    worst=json.loads((out/'finite_policy_worst.json').read_text())
    diffs=json.loads((out/'time_step_sensitivity.json').read_text())
    n=int(subsets['reference_safe_margin_0.01'].sum());groups=n//4
    lines=['# Closed-loop development results','',
        'The formulation and duration improvements also helped in these closed-loop tests. Against the reference pursuer, 4A had 40 contacts, 4B had 9, and 4C had 4 on the reference-safe subset. The four 4C contacts are four poses of one encounter, also failed by 3D_Long. The reference evader avoided contact in every tested reference-safe state. These finite development results do not establish guaranteed safety.','',
        f'The frozen 8×8 policy matrix completed at both time steps: 102,400 mathematical trajectories across 200 development groups and four equivalent poses per group. No training, controller tuning or final-test queries occurred. The primary reference-safe subset contains {n} joint states from {groups} relative groups, with initial separation and both coarse/fine initial values above +0.01 m.','',
        'Results at a 0.005-second control interval, against the numerical-reference pursuer:','',
        '| Evader policy | Definite contacts | Relative groups with any contact | Possible contacts, including definite | Mean sampled minimum distance |',
        '|---|---:|---:|---:|---:|']
    for r in selected:
        k=ro.POLICIES.index(r['evader'])*len(ro.POLICIES)+ro.POLICIES.index('reference')
        h=results[.005]['definite_collision'][k]&subsets['reference_safe_margin_0.01']
        ng=int(h.reshape(-1,4).any(axis=1).sum())
        lines.append(f"| {r['evader']} | {r['definite_collision_count']}/{n} | {ng}/{groups} | {r['possible_collision_count']}/{n} | {r['mean_minimum_separation']:.4f} m |")
    lines += ['',
        'Collision distance is 0.25 m. Possible contacts use the geometric lower distance bound and include definite contacts. These are finite-policy development results, not guarantees for every allowed pursuer action. The reference pursuer itself is approximate numerical feedback. States with reference values near zero are excluded only from this margin subset; all and initially separated subsets are retained in the raw metrics.','',
        '![Fixed policy matrix](collision_matrix.png)','',
        'Across all eight tested pursuer policies, at dt=.005 on the same reference-safe subset:','',
        '| Evader policy | States with contact under at least one tested pursuer | States with possible contact under at least one tested pursuer |',
        '|---|---:|---:|']
    for r in worst:
        if r['dt']==.005 and r['subset']=='reference_safe_margin_0.01':
            lines.append(f"| {r['evader']} | {r['any_tested_pursuer_collision_count']}/{n} | {r['any_tested_pursuer_possible_collision_count']}/{n} |")
    lines += ['',
        'The tested set includes learned, reference, straight and constant maximum-turn policies. Taking the worst observed result across this set does not solve an exhaustive best-response problem. Rows should not be interpreted as independent samples: four poses share each underlying encounter.','',
        'Halving the control interval can change the feedback trajectory as well as its contact outcome:','',
        '| Evader vs reference pursuer | Definite-contact outcomes changed | Mean absolute change in minimum distance |',
        '|---|---:|---:|']
    for r in diffs:
        if r['pursuer']=='reference' and r['subset']=='reference_safe_margin_0.01':
            lines.append(f"| {r['evader']} | {r['collision_outcome_changes']}/{n} | {r['minimum_separation_mean_abs_change']:.5f} m |")
    lines += ['',
        'The learned policies and reference evader have no definite-contact outcome changes on this subset when dt is halved. The 4C contacts are unambiguous at both time steps; their sampled minimum distance reaches about 0.20127 m, well below the 0.25 m threshold. Constant-left changes four outcomes, demonstrating that time-step sensitivity is still relevant for the policy matrix.','']
    # Predetermined example groups, not chosen for their outcomes.
    fine=results[.005];t=np.arange(len(fine['example_states']))*.005
    fig,axes=plt.subplots(2,2,figsize=(10,7),layout='constrained')
    for i,ax in enumerate(axes.flat):
        for policy in ['4C','reference','straight']:
            pair=ro.POLICIES.index(policy)*len(ro.POLICIES)+ro.POLICIES.index('reference')
            z=fine['example_states'][:,pair,i*4]
            distance=np.linalg.norm(z[:,:2]-z[:,3:5],axis=-1)
            ax.plot(t,distance,label=policy+' evader')
        ax.axhline(.25,color='red',linestyle='--',label='contact distance')
        ax.set(title=f'Group {ids[i]}, canonical pose\nInitial reference V = {vf[i]:.3f} m',
               xlabel='Elapsed time [s]',ylabel='Center separation [m]');ax.grid(alpha=.2)
        ax.title.set_fontsize(11)
    axes[0,0].legend(fontsize=8)
    fig.savefig(out/'predetermined_examples.png',dpi=160);plt.close(fig)
    # Supplementary diagnosis of every primary 4C contact group, using saved data only.
    primary_pair=ro.POLICIES.index('4C')*8+ro.POLICIES.index('reference')
    hit=(fine['definite_collision'][primary_pair]&subsets['reference_safe_margin_0.01']).reshape(-1,4)
    contact_cases=[]
    devmanifest=json.loads((ev.OUT/'output_manifest.json').read_text())
    assert ev.sha(ev.OUT/'predictions.npz')==devmanifest['outputs']['predictions.npz']
    with np.load(out/'initial_states.npz') as state_file,np.load(ev.OUT/'predictions.npz') as pred:
        for local in np.flatnonzero(hit.any(axis=1)):
            start=local*4;end=start+4
            u=fine['controls'][:,primary_pair,start,0];ur=fine['controls'][:,36,start,0]
            different=np.flatnonzero(u!=ur)
            contact_cases.append(dict(development_group_id=int(ids[local]),relative_state=relative[local].tolist(),
                fine_reference_value=float(state_file['fine_value'][local]),coarse_reference_value=float(state_file['coarse_value'][local]),
                pose_hits=hit[local].tolist(),initial_4c_predictions=pred['4C'][-1,ids[local]].tolist(),
                initial_3d_long_predictions=pred['3D_Long'][-1,ids[local]].tolist(),
                first_contact_times=fine['first_sampled_collision_time'][primary_pair,start:end].tolist(),
                sampled_minimum_distances=fine['minimum_distance_upper'][primary_pair,start:end].tolist(),
                first_different_evader_action_time_from_reference_rollout=float(different[0]*.005) if len(different) else None,
                first_actions_canonical=dict(learned_4C=int(u[0]),reference=int(ur[0])),
                reference_evader_sampled_minimum_distances=fine['minimum_distance_upper'][36,start:end].tolist()))
    ev.dump(out/'primary_contact_cases.json',dict(label='Post-evaluation diagnosis from saved trajectories and existing predictions; no new queries',cases=contact_cases))
    lines += ['',
        'The remaining 4C failure is development group 603: relative state (0.43141, -0.23433, 0.89643). Its coarse/fine reference values are +0.04497/+0.03690 m. However, 4C initially predicts unsafe in all four poses (-0.07919 to -0.04049 m), and 3D_Long also predicts unsafe (-0.03911 m). This is not a case of either model initially declaring the state safe and then colliding.', '',
        'In its canonical pose, 4C chooses +3 rad/s initially while the reference evader chooses -3 rad/s. With the reference pursuer, the learned rollout reaches contact at about 0.39375 s and a sampled minimum distance of 0.20127 m. The reference-evader rollout stays above 0.28724 m. The failure is shared across all four poses and by the 3D model, so it is not explained solely by 6D pose inconsistency or this time step. That does not isolate a causal training defect; a targeted first-action/gradient analysis is the next useful diagnostic. See [saved case details](primary_contact_cases.json).','']
    lines += ['',
        '![Predetermined separation traces](predetermined_examples.png)','',
        'The example plots show update-time distances for the first four selected groups and canonical poses; no example was selected for success or failure. Contact metrics also check within-step arc samples and retain geometric uncertainty bounds.','',
        'Controls are sample-and-hold, with decreasing time remaining and exact constant-turn arc integration. Nine exact arc samples per interval give sampled minimum distance; a relative-speed bound gives a lower estimate within 0.00046875 m at dt=.005 and 0.0009375 m at dt=.01. Ambiguous contact cases are flagged instead of being silently counted as safe. These bounds apply to fixed sampled policies, not an ideal continuously updated feedback law.','',
        'The all-state table includes initial overlaps. Mathematical trajectories continue after contact; their contact flag remains absorbing. Full-horizon switch counts can include post-contact behavior and should not be interpreted as drone behavior after a crash. Differences between poses and time steps are reported rather than smoothed away.','',
        'Raw controls for every rollout were replayed without model queries. Minimum-distance bounds, contact times, flags, final states, example paths and switch counts reproduced bit for bit, and all pair/subset contact counts were checked against raw arrays. The reference interpolator passed an analytic time/space/periodic-gradient fixture. Protected checkpoints and old final-state bytes remain unchanged.','',
        'See [methodology](METHODOLOGY.md), [fixed protocol](protocol.json), [all role/policy metrics](policy_pair_metrics.csv), [finite-policy worst outcomes](finite_policy_worst.csv), [time-step sensitivity](time_step_sensitivity.csv), and [execution manifest](manifest.json).','']
    (out/'README.md').write_text('\n'.join(lines),encoding='utf-8')
    ev.dump(out/'replay_checks.json',dict(status='passed',control_update_trajectories_replayed=replayed,
        pair_subset_contact_rows_checked=len(rows),reference_interpolation_fixture=interpolation_check,
        no_model_queries=True,parameter_updates=0))
    ev.dump(out/'output_manifest.json',dict(status='verified closed-loop development outputs',
        files={str(p.relative_to(out)):ev.sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='output_manifest.json'},
        report_source_sha256=ev.sha(Path(__file__))))
    print(json.dumps(dict(primary_comparison=selected,initially_separated_groups=int(subsets['initially_separated'].sum())//4,
                         reference_safe_groups=groups,replayed=replayed),indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--reuse-replay',action='store_true')
    report(parser.parse_args().reuse_replay)

"""Tiny disposable optimizer fixtures; never launches Experiment 4 training."""
import contextlib
import hashlib
import io
import json
import tempfile
from pathlib import Path

import torch
from network import JointSiren
from train import TrainingState, extend, run, source_hashes

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def equal(a, b):
    if isinstance(a, torch.Tensor):
        assert torch.equal(a, b)
    elif isinstance(a, dict):
        assert a.keys() == b.keys()
        for key in a:
            equal(a[key], b[key])
    elif isinstance(a, (list, tuple)):
        assert len(a) == len(b)
        for x, y in zip(a, b):
            equal(x, y)
    else:
        assert a == b


def compare(a, b):
    assert a.step == b.step and a.weight == b.weight
    equal(a.model.state_dict(), b.model.state_dict())
    equal(a.optimizer.state_dict(), b.optimizer.state_dict())
    equal(a.sampler.state_dict(), b.sampler.state_dict())


def rejects(fn):
    try:
        fn()
    except (ValueError, FileExistsError):
        return
    raise AssertionError('Expected rejection')


def run_checks():
    protected = list(ROOT.glob('**/checkpoint*.pt'))+[ROOT/'evaluation/reserved_final_states/states.npz']
    before = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
    updates = 0
    results = {}
    with tempfile.TemporaryDirectory(dir=ROOT.parents[1]/'work', prefix='joint6d_trainer_') as tmp:
        tmp = Path(tmp)
        for label in ('4A', '4B'):
            c = json.loads((HERE/f'configs/{label}.json').read_text())
            # Small fixtures use different seeds, widths, counts and budgets.
            c.update(width=8, sine_layers=2, samples=32, terminal_samples=4,
                     pretrain_steps=2 if label == '4A' else 0, curriculum_steps=3,
                     initialization_seed=991750, terminal_seed=991751, physics_seed=991752,
                     log_every=1, save_every=1)
            uninterrupted = TrainingState(c)
            initial = {k:v.clone() for k,v in uninterrupted.model.state_dict().items()}
            while uninterrupted.step < uninterrupted.total:
                uninterrupted.advance(); updates += 1
            assert any(not torch.equal(v, initial[k]) for k,v in uninterrupted.model.state_dict().items())
            # Check both terminal-phase and calibrated physics-phase resume.
            splits = (1, 3) if label == '4A' else (1,)
            for split in splits:
                partial = TrainingState(c)
                for _ in range(split):
                    partial.advance(); updates += 1
                path = tmp/f'{label}_{split}.pt'
                partial.save(path)
                rng = torch.get_rng_state().clone()
                resumed = TrainingState.load(path, c)
                assert torch.equal(rng, torch.get_rng_state())
                while resumed.step < resumed.total:
                    resumed.advance(); updates += 1
                compare(uninterrupted, resumed)
                rejects(lambda: TrainingState.load(path, dict(c, lr=.002)))
            if label == '4B':
                parent = tmp/'completed_b.pt'; uninterrupted.save(parent)
                cc = dict(c, run_id='4C', full_horizon_steps=2)
                extended = extend(parent, cc)
                compare(uninterrupted, extended)
                row = extended.advance(); updates += 1
                assert row['phase'] == 'full_horizon' and row['tmax'] == c['horizon']
                path = tmp/'partial_c.pt'; extended.save(path)
                resumed = TrainingState.load(path, cc)
                extended.advance(); resumed.advance(); updates += 2
                compare(extended, resumed)
                assert resumed.step == 5 and resumed.parent['step'] == 3
                rejects(lambda: extend(parent, dict(cc, domain=3.)))
                # Incomplete 4B cannot be promoted to an extension.
                partial = TrainingState(c); partial.save(tmp/'incomplete.pt')
                rejects(lambda: extend(tmp/'incomplete.pt', cc))
            results[label] = dict(bitwise_resume=True, total_fixture_steps=uninterrupted.total,
                                  calibrated_terminal_weight=uninterrupted.weight)
        # File/output safeguards and the actual wrapper also get exercised.
        out = tmp/'wrapper'
        with contextlib.redirect_stdout(io.StringIO()):
            first = run(c, out, stop_after=1, execution='disposable fixture')
            updates += 1
            rejects(lambda: run(c, out))
            finished = run(c, out, resume=True, execution='disposable fixture')
            updates += 2
        compare(uninterrupted, finished)
        assert len((out/'history.csv').read_text().splitlines()) == 4
        torch.save({'schema': 'joint6d-components-v1'}, tmp/'wrong.pt')
        rejects(lambda: TrainingState.load(tmp/'wrong.pt'))
        rejects(lambda: TrainingState(dict(c, pretrain_steps=1)))
    assert before == {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
    result = dict(status='passed', experimental_training_started=False,
        disposable_optimizer_fixture_updates=updates, fixtures_deleted=True,
        fixture_shape='7 inputs, 2 hidden layers of width 8; batches of 32',
        fixture_seeds=[991750,991751,991752], variants=results,
        full_horizon_extension_and_resume=True, output_overwrite_rejected=True,
        incorrect_config_schema_and_incomplete_parent_rejected=True,
        protected_inputs_unchanged=True, final_states_used=False,
        sources=source_hashes(), check_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        configs={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'configs').glob('*.json')})
    (HERE/'training_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    run_checks()

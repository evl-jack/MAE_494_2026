"""Explicitly gated CPU trainer for joint Air3D. Importing never trains."""
import argparse
import copy
import csv
import hashlib
import json
import math
import os
import platform
import shutil
import time
from pathlib import Path

import torch
from network import JointSiren, PairedSampler, validate, residual
from joint6d import target

HERE = Path(__file__).resolve().parent
SCHEMA = 'joint6d-training-v1'


def source_hashes():
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [HERE/'train.py', HERE/'network.py', HERE.parent/'joint6d.py']}


def validate_training(c):
    validate(c)
    for key in ('samples', 'terminal_samples', 'curriculum_steps', 'threads', 'log_every', 'save_every'):
        if type(c[key]) is not int or c[key] <= 0:
            raise ValueError(f'{key} must be a positive integer')
    for key in ('pretrain_steps', 'full_horizon_steps'):
        if type(c[key]) is not int or c[key] < 0:
            raise ValueError(f'{key} must be a nonnegative integer')
    if not 0 < c['terminal_samples'] < c['samples']:
        raise ValueError('Require 0 < terminal_samples < samples')
    for key in ('lr', 'terminal_weight_factor'):
        if not math.isfinite(c[key]) or c[key] <= 0:
            raise ValueError(f'{key} must be positive and finite')
    if c['formulation'] == 'terminal_obstacle_square' and c['pretrain_steps'] != 0:
        raise ValueError('Exact output must skip terminal-only pretraining')
    if c['device'] != 'cpu' or c['threads'] != 2:
        raise ValueError('This protocol uses CPU and two threads')
    for key in ('initialization_seed', 'terminal_seed', 'physics_seed'):
        if type(c[key]) is not int or not 0 <= c[key] < 2**63:
            raise ValueError(f'{key} must be a nonnegative seed below 2**63')


class TrainingState:
    def __init__(self, c):
        validate_training(c)
        self.c = copy.deepcopy(c)
        torch.set_num_threads(c['threads'])
        torch.use_deterministic_algorithms(True)
        self.model = JointSiren(c, seed=c['initialization_seed'])
        self.sampler = PairedSampler(c, c['terminal_seed'], c['physics_seed'])
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=c['lr'])
        self.step = 0
        self.weight = 0. if c['formulation'] == 'terminal_obstacle_square' else None
        self.elapsed = 0.
        self.parent = None
        self.history = []
        self.last_metrics = None

    @property
    def total(self):
        return self.c['pretrain_steps']+self.c['curriculum_steps']+self.c['full_horizon_steps']

    def advance(self):
        if self.step >= self.total:
            raise ValueError('Run is already complete')
        started = time.perf_counter()
        c = self.c
        pre = self.step < c['pretrain_steps']
        physics_step = self.step-c['pretrain_steps']+1
        phase = 'terminal' if pre else ('curriculum' if physics_step <= c['curriculum_steps'] else 'full_horizon')
        tmax = 0. if pre else c['horizon']*min(physics_step/c['curriculum_steps'], 1.)
        nt = c['samples'] if pre else c['terminal_samples']
        q = self.sampler.sample(c['samples'], tmax, nt, stream='terminal' if pre else 'physics')
        if pre:
            boundary = (self.model(q)-target(q[:, 1:], c)).abs().mean()
            physics = torch.zeros(())
            loss = boundary
        else:
            r, v, _ = residual(self.model, q, create_graph=True)
            physics = r.abs().mean()  # Includes zero-time rows, as in the 3D baseline.
            boundary = (v[-nt:]-target(q[-nt:, 1:], c)).abs().mean()
            if self.weight is None:
                self.weight = float((physics.detach()/boundary.detach().clamp_min(1e-8)).clamp(1e-3, 1e4))*c['terminal_weight_factor']
            loss = physics+self.weight*boundary
        self.optimizer.zero_grad(set_to_none=True)
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite loss; last saved checkpoint remains available')
        loss.backward()
        if not all(p.grad is not None and torch.isfinite(p.grad).all() for p in self.model.parameters()):
            raise FloatingPointError('Nonfinite parameter gradient')
        self.optimizer.step()
        self.step += 1
        self.elapsed += time.perf_counter()-started
        row = dict(step=self.step, phase=phase, tmax=tmax,
                   terminal_mae=float(boundary.detach()), vi_mae=float(physics.detach()),
                   terminal_weight=self.weight, loss=float(loss.detach()), elapsed_seconds=self.elapsed)
        self.last_metrics = row
        if self.step == 1 or self.step % c['log_every'] == 0 or self.step in (c['pretrain_steps'], c['pretrain_steps']+1, self.total):
            self.history.append(row)
        return row

    def save(self, path):
        path = Path(path)
        ck = dict(schema=SCHEMA, sources=source_hashes(), config=self.c,
                  model=self.model.state_dict(), optimizer=self.optimizer.state_dict(),
                  sampler=self.sampler.state_dict(), torch_rng=torch.get_rng_state(),
                  step=self.step, terminal_weight=self.weight, elapsed_seconds=self.elapsed,
                  parent=self.parent, history=self.history, last_metrics=self.last_metrics,
                  environment=dict(python=platform.python_version(), torch=torch.__version__.__str__(),
                                   threads=torch.get_num_threads(), device='cpu'))
        tmp = path.with_suffix('.tmp')
        torch.save(ck, tmp)
        os.replace(tmp, path)

    @classmethod
    def load(cls, path, expected_config=None):
        ck = torch.load(path, map_location='cpu', weights_only=True)
        if ck.get('schema') != SCHEMA or ck.get('sources') != source_hashes():
            raise ValueError('Incompatible training checkpoint schema or source hashes')
        if expected_config is not None and ck['config'] != expected_config:
            raise ValueError('Resume requires identical configuration')
        state = cls(ck['config'])
        scales = state.model.scales.clone()
        state.model.load_state_dict(ck['model'], strict=True)
        if not torch.equal(state.model.scales, scales):
            raise ValueError('Checkpoint normalization conflicts with physical configuration')
        state.optimizer.load_state_dict(ck['optimizer'])
        state.sampler.load_state_dict(ck['sampler'])
        state.step = ck['step']
        state.weight = ck['terminal_weight']
        state.elapsed = ck['elapsed_seconds']
        state.parent = ck['parent']
        state.history = ck['history']
        state.last_metrics = ck['last_metrics']
        if type(state.step) is not int or not 0 <= state.step <= state.total:
            raise ValueError('Invalid checkpoint progress')
        if state.c['formulation'] == 'terminal_obstacle_square' and state.weight != 0.:
            raise ValueError('Exact output requires zero terminal penalty')
        if state.step > state.c['pretrain_steps'] and (state.weight is None or not math.isfinite(state.weight)):
            raise ValueError('Checkpoint lacks finite fixed terminal weight')
        torch.set_rng_state(ck['torch_rng'])
        return state


def extend(parent_path, c):
    state = TrainingState.load(parent_path)
    ignored = {'run_id', 'full_horizon_steps'}
    if ({k:v for k,v in state.c.items() if k not in ignored} !=
            {k:v for k,v in c.items() if k not in ignored}):
        raise ValueError('Extension may only change run_id and full_horizon_steps')
    if (state.c['run_id'] != '4B' or c['run_id'] != '4C' or state.c['full_horizon_steps'] != 0
            or state.step != state.total or c['full_horizon_steps'] <= 0):
        raise ValueError('4C requires a completed 4B curriculum')
    validate_training(c)
    state.parent = dict(path=str(Path(parent_path).resolve()), sha256=hashlib.sha256(Path(parent_path).read_bytes()).hexdigest(),
                        step=state.step, elapsed_seconds=state.elapsed)
    state.c = copy.deepcopy(c)
    state.model.c = copy.deepcopy(c)
    state.sampler.c = copy.deepcopy(c)
    return state


def run(c, out, resume=False, parent=None, stop_after=None, execution='command line'):
    validate_training(c)
    if resume and parent:
        raise ValueError('Choose resume or extension, not both')
    out = Path(out)
    if stop_after is not None and (stop_after <= 0 or stop_after > c['pretrain_steps']+c['curriculum_steps']+c['full_horizon_steps']):
        raise ValueError('Invalid absolute stop-after step')
    # Resume only from the output directory itself; fresh runs never overwrite files.
    if resume:
        state = TrainingState.load(out/'checkpoint.pt', c)
    else:
        if out.exists() and any(out.iterdir()):
            raise FileExistsError('Choose an empty output folder or explicitly resume')
        if (c['run_id'] == '4C') != bool(parent):
            raise ValueError('4C requires --extend-from; other runs start fresh')
        state = extend(parent, c) if parent else TrainingState(c)
        out.mkdir(parents=True, exist_ok=True)
        (out/'config.json').write_text(json.dumps(c, indent=2)+'\n')
        (out/'execution.json').write_text(json.dumps(dict(execution=execution, sources=source_hashes()), indent=2)+'\n')
        (out/'sources').mkdir()
        for src in [HERE/'train.py', HERE/'network.py', HERE.parent/'joint6d.py']:
            shutil.copy2(src, out/'sources'/src.name)
        state.save(out/'checkpoint.pt')
    end = state.total if stop_after is None else stop_after
    if end < state.step:
        raise ValueError('stop-after precedes saved progress')
    print(f"{c['run_id']} | CPU, two threads | {state.step}..{end} updates | {out}", flush=True)
    def save():
        state.save(out/'checkpoint.pt')
        if state.history:
            with (out/'history.csv').open('w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=state.history[0].keys())
                writer.writeheader(); writer.writerows(state.history)
    while state.step < end:
        row = state.advance()
        if state.step % c['log_every'] == 0 or state.step == end:
            print(json.dumps(row), flush=True)
        if state.step % c['save_every'] == 0 or state.step == end:
            save()
    return state


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--train', action='store_true')
    parser.add_argument('--config', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--extend-from')
    parser.add_argument('--stop-after', type=int)
    parser.add_argument('--execution', default='command line')
    args = parser.parse_args()
    if not args.train:
        parser.error('Training remains paused. --train is required to start it.')
    run(json.loads(Path(args.config).read_text()), args.out, args.resume,
        args.extend_from, args.stop_after, args.execution)

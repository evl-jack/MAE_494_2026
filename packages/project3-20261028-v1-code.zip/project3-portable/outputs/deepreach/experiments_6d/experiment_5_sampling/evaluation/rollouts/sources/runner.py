"""Explicitly gated Experiment 5 trainer. No training on import."""
import argparse
import copy
import csv
import hashlib
import json
import os
import shutil
import time
from pathlib import Path

import torch
from sampler import ComparisonSampler,native_scores
from network import JointSiren,residual
from joint6d import target
from train import TrainingState

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SCHEMA='joint6d-experiment5-training-v1'


def source_hashes():
    paths=[HERE/'runner.py',HERE/'sampler.py',HERE.parent/'network.py',HERE.parent/'train.py',ROOT/'joint6d.py']
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


class ExperimentState:
    def __init__(self,parent,mode,sampling_settings,total_updates,parent_identity):
        if type(total_updates) is not int or total_updates<=0:raise ValueError('Invalid update budget')
        if parent.c['formulation']!='terminal_obstacle_square':raise ValueError('This comparison requires exact output')
        self.model=parent.model;self.optimizer=parent.optimizer
        self.c=copy.deepcopy(parent.c);self.mode=mode;self.total=total_updates
        self.parent=copy.deepcopy(parent_identity)
        self.sampler=ComparisonSampler(self.c,mode,parent.sampler.state_dict(),sampling_settings)
        self.step=0;self.update_seconds=0.;self.run_wall_seconds=0.;self.history=[];self.last_metrics=None

    @classmethod
    def from_protocol(cls,p,mode):
        path=ROOT/p['parent']['path']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=p['parent']['sha256']:
            raise ValueError('Parent checkpoint hash differs from frozen plan')
        parent=TrainingState.load(path)
        if parent.c!=p['parent_config']:raise ValueError('Parent configuration differs')
        if parent.c['run_id']!='4C' or parent.step!=22000 or parent.step!=parent.total:
            raise ValueError('Expected completed 4C parent at 22,000 updates')
        if parent.c['samples']!=p['sampling']['samples'] or parent.c['terminal_samples']!=p['sampling']['terminal_samples']:
            raise ValueError('Parent batch sizes differ from sampling comparison')
        identity=dict(path=str(path.resolve()),sha256=p['parent']['sha256'],step=parent.step,
                      inherited_update_seconds=parent.elapsed)
        return cls(parent,mode,p['sampling'],p['additional_updates'],identity)

    def advance(self):
        if self.step>=self.total:raise ValueError('Run is complete')
        if self.sampler.step!=self.step:raise ValueError('Sampler progress differs from completed updates')
        q,sampling=self.sampler.next_batch(lambda pool:native_scores(self.model,pool))
        clock=time.perf_counter()
        r,v,_=residual(self.model,q,create_graph=True)
        loss=r.abs().mean()
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
        self.optimizer.zero_grad(set_to_none=True);loss.backward()
        if not all(p.grad is not None and torch.isfinite(p.grad).all() for p in self.model.parameters()):
            raise FloatingPointError('Nonfinite parameter gradient')
        self.optimizer.step();self.step+=1
        self.update_seconds+=time.perf_counter()-clock
        nt=self.sampler.s['terminal_samples']
        boundary=float((v[-nt:]-target(q[-nt:,1:],self.c)).abs().max().detach())
        row=dict(additional_step=self.step,cumulative_physics_step=self.parent['step']+self.step,
            mode=self.mode,sampled_vi_mae=float(loss.detach()),terminal_max_abs=boundary,
            update_seconds=self.update_seconds,sampling_seconds=self.sampler.sampling_seconds,
            candidate_scoring_seconds=self.sampler.scoring_seconds,selection_seconds=self.sampler.selection_seconds,
            scored_candidates=self.sampler.pool_evaluations,bank_refreshes=self.sampler.refreshes,
            bank_age=sampling['bank_age'])
        self.last_metrics=row
        if self.step==1 or self.step%100==0 or self.step==self.total:self.history.append(row)
        return row

    def save(self,path,protocol_sha):
        path=Path(path)
        ck=dict(schema=SCHEMA,sources=source_hashes(),protocol_sha256=protocol_sha,config=self.c,
            mode=self.mode,total_updates=self.total,parent=self.parent,model=self.model.state_dict(),
            optimizer=self.optimizer.state_dict(),sampler=self.sampler.state_dict(),step=self.step,
            update_seconds=self.update_seconds,run_wall_seconds=self.run_wall_seconds,
            history=self.history,last_metrics=self.last_metrics,torch_rng=torch.get_rng_state())
        tmp=path.with_suffix('.tmp');torch.save(ck,tmp);os.replace(tmp,path)

    @classmethod
    def load(cls,path,protocol_sha=None,mode=None):
        ck=torch.load(path,map_location='cpu',weights_only=True)
        if ck.get('schema')!=SCHEMA or ck.get('sources')!=source_hashes():
            raise ValueError('Incompatible experiment checkpoint or source version')
        if protocol_sha is not None and ck['protocol_sha256']!=protocol_sha:
            raise ValueError('Frozen protocol differs')
        if mode is not None and ck['mode']!=mode:raise ValueError('Cannot resume a different sampling arm')
        self=cls.__new__(cls)
        self.c=copy.deepcopy(ck['config']);self.mode=ck['mode'];self.total=ck['total_updates']
        self.parent=copy.deepcopy(ck['parent'])
        self.model=JointSiren(self.c);expected_scales=self.model.scales.clone()
        self.model.load_state_dict(ck['model'],strict=True)
        if not torch.equal(self.model.scales,expected_scales):raise ValueError('Invalid normalization')
        self.optimizer=torch.optim.Adam(self.model.parameters(),lr=self.c['lr'])
        self.optimizer.load_state_dict(ck['optimizer'])
        self.sampler=ComparisonSampler(self.c,self.mode,ck['sampler']['base'],ck['sampler']['settings'])
        self.sampler.load_state_dict(ck['sampler'])
        for key in ['step','update_seconds','run_wall_seconds','history','last_metrics']:setattr(self,key,ck[key])
        if type(self.step) is not int or not 0<=self.step<=self.total or self.step!=self.sampler.step:
            raise ValueError('Invalid completed-update progress')
        if any(g['lr']!=self.c['lr'] for g in self.optimizer.param_groups):raise ValueError('Optimizer learning rate differs')
        torch.set_rng_state(ck['torch_rng'])
        return self


def run(mode,out,resume=False,stop_after=None,execution='command line'):
    started=time.perf_counter();torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    protocol_path=HERE/'protocol.json';p=json.loads(protocol_path.read_text())
    if p['status']!='frozen; training not started when prepared' or p['source_hashes']!=source_hashes():
        raise ValueError('Frozen source plan differs; inspect before training')
    if mode not in ['uniform','mixed']:raise ValueError('Unknown sampling arm')
    sha=hashlib.sha256(protocol_path.read_bytes()).hexdigest();out=Path(out)
    if resume:
        if (out/'completion.json').exists():raise FileExistsError('Completed run is immutable')
        state=ExperimentState.load(out/'checkpoint.pt',sha,mode)
    else:
        if out.exists() and any(out.iterdir()):raise FileExistsError('Fresh output must be empty; use explicit resume')
        state=ExperimentState.from_protocol(p,mode)
        out.mkdir(parents=True,exist_ok=True);(out/'sources').mkdir()
        shutil.copy2(protocol_path,out/'protocol.json')
        for src in [HERE/'runner.py',HERE/'sampler.py',HERE.parent/'network.py',HERE.parent/'train.py',ROOT/'joint6d.py']:
            shutil.copy2(src,out/'sources'/src.name)
        (out/'execution.json').write_text(json.dumps(dict(execution=execution,source_hashes=source_hashes()),indent=2)+'\n')
    if state.total!=p['additional_updates'] or state.sampler.s!=p['sampling']:
        raise ValueError('Saved run budget or sampler settings differ from frozen protocol')
    if state.c!=p['parent_config']:raise ValueError('Saved physical/model configuration differs')
    if state.parent['sha256']!=p['parent']['sha256']:raise ValueError('Saved parent differs')
    end=state.total if stop_after is None else stop_after
    if type(end) is not int or not state.step<=end<=state.total:raise ValueError('Invalid absolute stop-after update')
    prior_wall=state.run_wall_seconds
    def save():
        state.run_wall_seconds=prior_wall+time.perf_counter()-started
        state.save(out/'checkpoint.pt',sha)
        history=list(state.history)
        if state.last_metrics and (not history or history[-1]['additional_step']!=state.step):history.append(state.last_metrics)
        if history:
            with (out/'history.csv').open('w',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=history[0].keys());writer.writeheader();writer.writerows(history)
    if not resume:save()
    print(f'Experiment 5 {mode}: {state.step}..{end} additional updates, CPU two threads.',flush=True)
    while state.step<end:
        row=state.advance()
        if state.step%100==0 or state.step==end:print(json.dumps(row),flush=True)
        if state.step%p['checkpoint_every']==0 or state.step==end:save()
    if state.step==state.total:
        total_wall=prior_wall+time.perf_counter()-started
        summary=dict(status='completed',mode=mode,additional_updates=state.step,
            cumulative_physics_updates=state.parent['step']+state.step,
            train_point_evaluations=state.step*state.sampler.s['samples'],scored_candidates=state.sampler.pool_evaluations,
            bank_refreshes=state.sampler.refreshes,update_seconds=state.update_seconds,
            candidate_scoring_seconds=state.sampler.scoring_seconds,sampling_seconds=state.sampler.sampling_seconds,
            selection_seconds=state.sampler.selection_seconds,run_wall_seconds=total_wall,
            timing_scope='run() entry through final checkpoint/history save; excludes Python import and debugger startup',
            parent=state.parent,checkpoint_sha256=hashlib.sha256((out/'checkpoint.pt').read_bytes()).hexdigest(),execution=execution)
        (out/'completion.json').write_text(json.dumps(summary,indent=2)+'\n')
    return state


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--train',action='store_true')
    ap.add_argument('--mode',choices=['uniform','mixed'],required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--resume',action='store_true');ap.add_argument('--stop-after',type=int)
    ap.add_argument('--execution',default='command line');a=ap.parse_args()
    if not a.train:ap.error('Training remains paused; --train is required')
    run(a.mode,a.out,a.resume,a.stop_after,a.execution)

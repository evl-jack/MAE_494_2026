"""Paired full-domain uniform and residual-bank collocation samplers."""
import copy
import sys
import time
from pathlib import Path
import torch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from network import PairedSampler,residual,scales

SCHEMA='joint6d-experiment5-sampler-v1'


def settings():
    return dict(samples=2048,terminal_samples=256,hard_samples=448,
        candidate_count=8192,bank_size=1024,refresh_every=50,
        candidate_seed=991763,selection_seed=991764)


def validate(s):
    for key in ['samples','terminal_samples','hard_samples','candidate_count','bank_size','refresh_every']:
        if type(s[key]) is not int or s[key]<=0:raise ValueError(f'{key} must be a positive integer')
    if not s['terminal_samples']<s['samples']:raise ValueError('Need nonterminal rows')
    if s['hard_samples']>min(s['samples']-s['terminal_samples'],s['bank_size']):
        raise ValueError('Hard points must fit the nonterminal rows and bank')
    if s['bank_size']>s['candidate_count']:raise ValueError('Bank must fit candidate pool')
    for key in ['candidate_seed','selection_seed']:
        if type(s[key]) is not int or not 0<=s[key]<2**63:raise ValueError('Invalid sampler seed')


def native_scores(model,q):
    """Input derivatives are required; no parameter-gradient accumulation."""
    result=[]
    with torch.enable_grad():
        for batch in q.split(1024):
            r,_,_=residual(model,batch,create_graph=False)
            result.append(r.detach().abs().cpu())
    return torch.cat(result)


class ComparisonSampler:
    def __init__(self,c,mode,base_state,s=None):
        self.c=copy.deepcopy(c);self.s=copy.deepcopy(settings() if s is None else s)
        validate(self.s)
        if mode not in ['uniform','mixed']:raise ValueError('Expected uniform or mixed mode')
        self.mode=mode
        self.base=PairedSampler(c);self.base.load_state_dict(base_state)
        self.candidates=PairedSampler(c,terminal_seed=self.s['candidate_seed'],physics_seed=self.s['candidate_seed'])
        self.selection=torch.Generator(device='cpu').manual_seed(self.s['selection_seed'])
        self.step=0;self.bank=None;self.bank_scores=None;self.last_refresh=-1
        self.pool_evaluations=0;self.refreshes=0
        self.scoring_seconds=0.;self.selection_seconds=0.;self.sampling_seconds=0.

    def next_batch(self,score=None):
        begin=time.perf_counter();s=self.s
        q=self.base.sample(s['samples'],self.c['horizon'],s['terminal_samples'])
        refreshed=False
        if self.mode=='mixed':
            if self.step%s['refresh_every']==0:
                if score is None:raise ValueError('Mixed mode requires a residual scorer')
                pool=self.candidates.sample(s['candidate_count'],self.c['horizon'],0)
                clock=time.perf_counter();scores=score(pool).detach().cpu()
                self.scoring_seconds+=time.perf_counter()-clock
                if scores.shape!=(s['candidate_count'],) or not torch.isfinite(scores).all() or (scores<0).any():
                    raise ValueError('Scorer must return finite nonnegative scalar residuals')
                clock=time.perf_counter()
                order=torch.argsort(scores,descending=True,stable=True)[:s['bank_size']]
                self.bank=pool[order].clone();self.bank_scores=scores[order].clone()
                self.selection_seconds+=time.perf_counter()-clock
                self.pool_evaluations+=s['candidate_count'];self.refreshes+=1
                self.last_refresh=self.step;refreshed=True
            clock=time.perf_counter()
            chosen=torch.randperm(s['bank_size'],generator=self.selection)[:s['hard_samples']]
            q[:s['hard_samples']]=self.bank[chosen]
            self.selection_seconds+=time.perf_counter()-clock
        metadata=dict(batch_index=self.step,bank_refreshed=refreshed,
            hard_rows=s['hard_samples'] if self.mode=='mixed' else 0,
            refreshes=self.refreshes,pool_evaluations=self.pool_evaluations,
            bank_age=0 if self.mode=='uniform' else self.step-self.last_refresh)
        self.step+=1;self.sampling_seconds+=time.perf_counter()-begin
        return q,metadata

    def state_dict(self):
        return dict(schema=SCHEMA,config=copy.deepcopy(self.c),settings=copy.deepcopy(self.s),mode=self.mode,
            base=self.base.state_dict(),candidates=self.candidates.state_dict(),selection=self.selection.get_state().clone(),
            step=self.step,bank=None if self.bank is None else self.bank.clone(),
            bank_scores=None if self.bank_scores is None else self.bank_scores.clone(),last_refresh=self.last_refresh,
            pool_evaluations=self.pool_evaluations,refreshes=self.refreshes,
            scoring_seconds=self.scoring_seconds,selection_seconds=self.selection_seconds,sampling_seconds=self.sampling_seconds)

    def load_state_dict(self,state):
        if (state.get('schema')!=SCHEMA or state.get('config')!=self.c or state.get('settings')!=self.s or state.get('mode')!=self.mode):
            raise ValueError('Sampler schema/configuration/mode mismatch')
        step=state['step']
        if type(step) is not int or step<0:raise ValueError('Invalid sampler progress')
        refreshes=0 if self.mode=='uniform' or step==0 else (step-1)//self.s['refresh_every']+1
        if state['refreshes']!=refreshes or state['pool_evaluations']!=refreshes*self.s['candidate_count']:
            raise ValueError('Sampler counters conflict with progress')
        bank=state['bank'];scores=state['bank_scores']
        if refreshes:
            if (bank is None or bank.shape!=(self.s['bank_size'],7) or bank.dtype!=torch.float32
                    or not torch.isfinite(bank).all() or scores is None or scores.shape!=(self.s['bank_size'],)
                    or not torch.isfinite(scores).all() or (scores<0).any()):
                raise ValueError('Invalid residual bank')
            if state['last_refresh']!=(step-1)//self.s['refresh_every']*self.s['refresh_every']:
                raise ValueError('Invalid bank refresh step')
            bounds=torch.tensor(scales(self.c))
            if (bank[:,0]<0).any() or (bank[:,0]>self.c['horizon']).any() or (bank[:,1:].abs()>bounds[1:]).any():
                raise ValueError('Bank lies outside configured training domain')
        elif bank is not None or scores is not None or state['last_refresh']!=-1:
            raise ValueError('Unexpected bank in uninitialized/uniform sampler')
        self.base.load_state_dict(state['base']);self.candidates.load_state_dict(state['candidates'])
        self.selection.set_state(state['selection'])
        for key in ['step','last_refresh','pool_evaluations','refreshes','scoring_seconds','selection_seconds','sampling_seconds']:
            setattr(self,key,state[key])
        self.bank=None if bank is None else bank.clone()
        self.bank_scores=None if scores is None else scores.clone()

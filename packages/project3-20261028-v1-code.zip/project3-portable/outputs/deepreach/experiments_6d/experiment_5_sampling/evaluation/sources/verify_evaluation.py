"""Recompute reported metrics and replay saved controls without training."""
import json
import numpy as np
import torch
import evaluate_comparison as driver

driver.configure()
ev, ro, out = driver.ev, driver.ro, driver.OUT


def compare(actual, expected):
    for key, value in expected.items():
        if isinstance(value, (float, int)) and value is not None:
            assert np.isclose(actual[key], value, rtol=1e-10, atol=1e-12), (key, actual[key], value)
        else:
            assert actual[key] == value, key


def verify():
    driver.guards()
    p=json.loads((out/'protocol.json').read_text())
    assert p['source_hashes']=={f.name:ev.sha(f) for f in driver.SOURCES}
    assert all(ev.sha(ev.ROOT/name)==h for name,h in p['protected_inputs'].items())
    with np.load(out/'development_states.npz') as f:
        relative=f['relative'];joint=f['joint']
    assert relative.shape==(6000,3) and joint.shape==(6000,4,6)
    assert np.max(abs(ev.relative_state(torch.tensor(joint),wrap=True).numpy()-relative[:,None,:]))<1e-12
    with np.load(out/'predictions.npz') as f:
        times=f['times'];predictions={name:f[name] for name in driver.MODELS}
    with np.load(out/'reference_values.npz') as f:
        fine=f['fine'];coarse=f['coarse']
    metrics=json.loads((out/'metrics.json').read_text());count=0
    for name,pred in predictions.items():
        for i,t in enumerate(times):
            saved=next(r for r in metrics if r['model']==name and r['time']==t)
            compare(saved,ev.metric_row(name,t,pred[i],np.repeat(fine[i,:,None],4,axis=1)));count+=1
    gradient_rows=json.loads((out/'gradients.json').read_text())
    sign_rows=json.loads((out/'switching_signs.json').read_text())
    with np.load(out/'reference_gradients.npz') as f:
        for i,t in enumerate(f['times']):
            for name in driver.MODELS:
                with np.load(out/f'gradients_{name}_{t:.2f}.npz') as saved:
                    g=saved['state_gradients'].reshape(-1,6)
                row,controls,_,_=ev.gradient_metrics(name,float(t),joint,np.column_stack([np.zeros(len(g),dtype=g.dtype),g]),
                    f['coarse'][i],f['fine'][i],driver.PLAN['parent_config'],p['switching_margins'])
                compare(next(r for r in gradient_rows if r['model']==name and r['time']==t),row)
                for control in controls:
                    compare(next(r for r in sign_rows if all(r[k]==control[k] for k in ['model','time','actor','margin','subset'])),control)
    physics=json.loads((out/'physics_audit.json').read_text())
    with np.load(out/'uniform_physics_audit.npz') as f:
        for row in physics:
            mask=np.ones(len(f['q']),dtype=bool) if row['subset']=='all' else f['q'][:,0]>=.4
            values=abs(f[row['model']][mask])
            compare(row,dict(count=int(mask.sum()),mean_abs_residual=float(values.mean()),
                p99_abs_residual=float(np.quantile(values,.99)),max_abs_residual=float(values.max())))
    # Independent recomputation of the fixed paired group-bootstrap intervals.
    group_errors={name:abs(v[-1]-fine[-1,:,None]).mean(axis=1) for name,v in predictions.items()}
    rng=np.random.default_rng(p['bootstrap']['seed'])
    ix=[rng.integers(0,len(relative),size=(50,len(relative))) for _ in range(40)]
    for row in json.loads((out/'grouped_bootstrap.json').read_text()):
        a=group_errors[row['old']];b=group_errors[row['new']]
        changes=np.concatenate([100*(a[j].mean(axis=1)-b[j].mean(axis=1))/a[j].mean(axis=1) for j in ix])
        assert np.allclose(np.quantile(changes,[.025,.975]),row['relative_improvement_percent_95_interval'],rtol=1e-12,atol=1e-12)
    with np.load(ro.OUT/'initial_states.npz') as f:
        initial=f['joint'].reshape(-1,6)
        subsets={key:f[key] for key in ['all','initially_separated','reference_safe_margin_0.01']}
        ids=f['group_ids']
    expected_ids=np.random.default_rng(driver.PLAN['future_development']['rollout_subset_seed']).choice(6000,200,replace=False)
    assert np.array_equal(ids,expected_ids) and np.array_equal(initial,joint[ids].reshape(-1,6))
    expected_safe=(np.linalg.norm(relative[ids,:2],axis=1)>.25)&(fine[-1,ids]>.01)&(coarse[-1,ids]>.01)
    assert np.array_equal(subsets['reference_safe_margin_0.01'],np.repeat(expected_safe,4))
    rows=json.loads((ro.OUT/'policy_pair_metrics.json').read_text())
    replays=[];control_updates=0
    for dt in ro.DT:
        with np.load(ro.OUT/f'rollouts_dt_{dt:.3f}.npz') as f:
            z=np.repeat(initial[None,:,:],49,axis=0)
            upper=np.linalg.norm(z[:,:,:2]-z[:,:,3:5],axis=-1);lower=upper.copy()
            first=np.where(upper<=.25,0.,np.inf)
            for step,controls in enumerate(f['controls']):
                u,d=controls[:,:,0],controls[:,:,1]
                assert np.isin(controls,[-3,0,3]).all()
                m,lo,hit=ro.step_minimum(z,u,d,dt)
                upper=np.minimum(upper,m);lower=np.minimum(lower,lo);first=np.minimum(first,step*dt+hit)
                z=ro.advance(z,u,d,dt);control_updates+=u.size
            assert np.array_equal(z,f['final_states'])
            assert np.array_equal(upper,f['minimum_distance_upper'])
            assert np.array_equal(lower,f['minimum_distance_lower'])
            assert np.array_equal(first,f['first_sampled_collision_time'])
            assert np.array_equal(upper<=.25,f['definite_collision'])
            for row in rows:
                if row['dt']!=dt:continue
                k=driver.POLICIES.index(row['evader'])*7+driver.POLICIES.index(row['pursuer']);mask=subsets[row['subset']]
                assert row['definite_collision_count']==int((upper[k,mask]<=.25).sum())
                assert row['possible_collision_count']==int((lower[k,mask]<=.25).sum())
                assert np.isclose(row['mean_minimum_separation'],upper[k,mask].mean(),atol=1e-14)
            replays.append(dict(dt=dt,final_states_and_distance_bounds_bitwise_equal=True))
    result=dict(status='passed',value_metric_rows_recomputed=count,gradient_rows_recomputed=len(gradient_rows),
        switching_rows_recomputed=len(sign_rows),physics_rows_recomputed=len(physics),
        bootstrap_intervals_recomputed=True,rollout_subset_and_safe_mask_verified=True,
        rollout_metric_rows_checked=len(rows),saved_control_updates_replayed=control_updates,replays=replays,
        protected_inputs_unchanged=True,training=False,parameter_updates=0)
    ev.dump(out/'saved_array_verification.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':verify()

"""Sampler checks and disposable tiny optimizer fixtures, never Experiment 5 training."""
import copy
import hashlib
import json
import tempfile
from pathlib import Path
import torch
from sampler import ComparisonSampler,settings,native_scores
from runner import ExperimentState,source_hashes,ROOT
from network import JointSiren,PairedSampler,scales
from train import TrainingState

HERE=Path(__file__).resolve().parent


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def equal(a,b):
    if isinstance(a,torch.Tensor):assert torch.equal(a,b)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for key in a:equal(a[key],b[key])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b):equal(x,y)
    else:assert a==b


def algorithm_state(sampler):
    return {k:v for k,v in sampler.state_dict().items() if not k.endswith('_seconds')}


def reject(fn):
    try:fn()
    except (ValueError,RuntimeError,FileExistsError):return
    raise AssertionError('Expected invalid input rejection')


def compare(a,b):
    assert a.step==b.step
    equal(a.model.state_dict(),b.model.state_dict())
    equal(a.optimizer.state_dict(),b.optimizer.state_dict())
    equal(algorithm_state(a.sampler),algorithm_state(b.sampler))


def run_checks():
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    protected={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('checkpoint*.pt')}
    final=ROOT/'evaluation/reserved_final_states/states.npz';protected[str(final.relative_to(ROOT))]=sha(final)
    c=json.loads((HERE.parent/'configs/4C.json').read_text())
    small=dict(c,width=8,sine_layers=2,samples=32,terminal_samples=4,
               curriculum_steps=3,full_horizon_steps=0,run_id='4B')
    s=dict(settings(),samples=32,terminal_samples=4,hard_samples=7,
           candidate_count=64,bank_size=16,refresh_every=2,candidate_seed=991772,selection_seed=991773)
    base=PairedSampler(small,991770,991771).state_dict()
    uniform=ComparisonSampler(small,'uniform',base,s);mixed=ComparisonSampler(small,'mixed',base,s)
    captured=[]
    def score(pool):
        captured.append(pool.clone())
        return pool[:,1].square()+pool[:,2].square()
    def forbidden(pool):raise AssertionError('Uniform arm must never score candidates')
    for i in range(6):
        u,um=uniform.next_batch(forbidden)
        torch.rand(17)  # Global random activity cannot shift either sampler stream.
        r,rm=mixed.next_batch(score)
        assert torch.equal(u[7:],r[7:]) and (r[-4:,0]==0).all()
        assert torch.unique(r[:7],dim=0).shape[0]==7
        assert rm['bank_refreshed']==(i%2==0) and rm['bank_age']==i%2
        assert mixed.pool_evaluations==64*(i//2+1)
        assert (r[:,0]>=0).all() and (r[:,0]<=small['horizon']).all()
        assert (r[:,1:].abs()<=torch.tensor(scales(small)[1:])).all()
        if i%2==0:
            pool=captured[-1];order=torch.argsort(score_value:=pool[:,1].square()+pool[:,2].square(),descending=True,stable=True)[:16]
            assert torch.equal(mixed.bank,pool[order]) and torch.equal(mixed.bank_scores,score_value[order])
    assert len(captured)==3 and uniform.pool_evaluations==0
    # Stable ties must choose candidates by original pool index.
    tie=ComparisonSampler(small,'mixed',base,s);tiepool=[]
    def ties(pool):tiepool.append(pool.clone());return torch.ones(len(pool))
    tie.next_batch(ties);assert torch.equal(tie.bank,tiepool[0][:16])
    state=mixed.state_dict();restored=ComparisonSampler(small,'mixed',base,s);restored.load_state_dict(state)
    for _ in range(4):
        a,am=mixed.next_batch(score);b,bm=restored.next_batch(score)
        assert torch.equal(a,b) and am==bm
    equal(algorithm_state(mixed),algorithm_state(restored))
    reject(lambda:ComparisonSampler(small,'bad',base,s))
    reject(lambda:ComparisonSampler(small,'mixed',base,dict(s,hard_samples=17)))
    bad=copy.deepcopy(state);bad['pool_evaluations']+=1
    reject(lambda:ComparisonSampler(small,'mixed',base,s).load_state_dict(bad))
    reject(lambda:ComparisonSampler(small,'mixed',base,s).next_batch(lambda p:-torch.ones(len(p))))
    # Native-size preflight with the actual trained model: score only, no optimizer.
    parent_path=HERE.parent/'runs/4C/checkpoint.pt'
    ck=torch.load(parent_path,map_location='cpu',weights_only=True)
    model=JointSiren(ck['config']);model.load_state_dict(ck['model'])
    weights={k:v.clone() for k,v in model.state_dict().items()}
    fu=ComparisonSampler(ck['config'],'uniform',ck['sampler'])
    fr=ComparisonSampler(ck['config'],'mixed',ck['sampler']);actual=[]
    def real_score(pool):
        scores=native_scores(model,pool);actual.append((pool.clone(),scores.clone()));return scores
    qu,_=fu.next_batch(forbidden);qr,_=fr.next_batch(real_score)
    assert torch.equal(qu[448:],qr[448:]) and (qr[-256:,0]==0).all()
    pool,scores=actual[0];top=torch.argsort(scores,descending=True,stable=True)[:1024]
    assert torch.equal(fr.bank,pool[top]) and torch.equal(fr.bank_scores,scores[top])
    assert all(torch.equal(v,model.state_dict()[k]) for k,v in weights.items())
    assert all(p.grad is None for p in model.parameters())
    # Warm a separate tiny parent, then test Adam/sampler continuation and resume.
    updates=0;temporary_root=ROOT.parents[1]/'work'
    with tempfile.TemporaryDirectory(dir=temporary_root,prefix='experiment5_check_') as tmp:
        tmp=Path(tmp);parent=TrainingState(small)
        for _ in range(3):parent.advance();updates+=1
        parent.save(tmp/'parent.pt');initial_optimizer=copy.deepcopy(parent.optimizer.state_dict())
        identity=dict(path='disposable fixture only',sha256=sha(tmp/'parent.pt'),step=3,inherited_update_seconds=parent.elapsed)
        for mode in ['uniform','mixed']:
            full=ExperimentState(TrainingState.load(tmp/'parent.pt'),mode,s,6,identity)
            equal(full.optimizer.state_dict(),initial_optimizer)
            initial={k:v.clone() for k,v in full.model.state_dict().items()}
            for _ in range(6):full.advance();updates+=1
            assert any(not torch.equal(v,full.model.state_dict()[k]) for k,v in initial.items())
            partial=ExperimentState(TrainingState.load(tmp/'parent.pt'),mode,s,6,identity)
            for _ in range(3):partial.advance();updates+=1
            path=tmp/(mode+'.pt');partial.save(path,'fixture-only')
            resumed=ExperimentState.load(path,'fixture-only',mode)
            for _ in range(3):resumed.advance();updates+=1
            compare(full,resumed)
            assert full.sampler.pool_evaluations==(192 if mode=='mixed' else 0)
            reject(lambda:ExperimentState.load(path,'different-protocol',mode))
            reject(lambda:ExperimentState.load(path,'fixture-only','mixed' if mode=='uniform' else 'uniform'))
            torch.save({'schema':'joint6d-components-v1'},tmp/'wrong.pt')
            reject(lambda:ExperimentState.load(tmp/'wrong.pt'))
    assert all(sha(ROOT/n)==h for n,h in protected.items())
    result=dict(status='passed',experimental_training_started=False,
        disposable_optimizer_updates=updates,fixtures_deleted=True,
        paired_uniform_suffix_and_terminal_rows=True,independent_candidate_selection_streams=True,
        top_residual_selection_and_stable_ties=True,bank_bounds_and_no_duplicate_selection=True,
        sampler_replay_across_refreshes=True,bitwise_model_adam_sampler_resume_both_modes=True,
        inherited_adam_state_preserved=True,invalid_settings_scores_schema_protocol_and_mode_rejected=True,
        actual_parent_dry_check=dict(optimizer_created=False,parameter_updates=0,
            candidates_scored=8192,bank_size=1024,hard_rows=448,unchanged_common_rows=1600,
            scoring_seconds=fr.scoring_seconds,parent_sha256=sha(parent_path),weights_unchanged=True),
        protected_inputs_unchanged=True,old_final_states_queried=False,source_hashes=source_hashes(),
        check_source_sha256=sha(Path(__file__)))
    (HERE/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':run_checks()

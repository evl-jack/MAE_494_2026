"""Configure the unchanged 6D benchmarks for fixed Experiment 5 endpoints.

Preparation freezes seeds and files before creating states or reference labels.
All model use is read-only. This driver never creates an optimizer or trains.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
SECTION = HERE.parent
sys.path.insert(0, str(SECTION))
import evaluate as ev
import rollouts as ro
from network import JointSiren, PairedSampler, residual

OUT = HERE / 'evaluation'
PLAN = json.loads((HERE / 'protocol.json').read_text())
MODELS = {'4C': SECTION / 'runs/4C/checkpoint.pt',
          '5U': HERE / 'runs/5U/checkpoint.pt', '5R': HERE / 'runs/5R/checkpoint.pt'}
POLICIES = ['4C', '5U', '5R', 'reference', 'straight', 'left', 'right']
SOURCES = [Path(__file__), SECTION/'evaluate.py', SECTION/'rollouts.py',
           SECTION/'network.py', SECTION/'train.py', HERE/'runner.py', HERE/'sampler.py',
           ev.ROOT/'joint6d.py', ev.ROOT/'reference.py', ev.ROOT/'deepreach.py', ev.ROOT/'validate.py']


def configure():
    # Existing benchmark functions resolve their output/model configuration here.
    # No old benchmark source or old output folder is modified.
    ev.OUT = OUT
    ev.MODELS = MODELS
    ev.SOURCES = SOURCES
    ro.OUT = OUT/'rollouts'
    ro.POLICIES = POLICIES
    ro.SOURCES = SOURCES
    ro.load_models = load_models


def load_models():
    result = {}
    for name, path in MODELS.items():
        ck = torch.load(path, map_location='cpu', weights_only=True)
        model = JointSiren(ck['config'])
        model.load_state_dict(ck['model'], strict=True)
        result[name] = model.eval()
    return result


def actor_check():
    class Analytic(torch.nn.Module):
        def forward(self, q):
            return q[:, 6]-q[:, 3]
    class Reference:
        def gradient(self, tau, r):
            return np.tile([0., 0., 1.], (len(r), 1))
    z = np.zeros((49, 2, 6)); z[:, :, 0] = .5
    u, d = ro.controls(z, .5, {name: Analytic() for name in MODELS}, Reference())
    expected = [3., 3., 3., -3., 0., 3., -3.]
    assert np.array_equal(u, np.repeat(expected, 7)[:, None]*np.ones((1, 2)))
    assert np.array_equal(d, np.tile(expected, 7)[:, None]*np.ones((1, 2)))
    return 'all 49 ordered actor assignments passed analytic checks'


def guards():
    for manifest in ['preparation_manifest.json', 'completed_training_manifest.json']:
        data = json.loads((HERE/manifest).read_text())
        for name, digest in data.get('frozen_files', data.get('files')).items():
            assert ev.sha(HERE/name) == digest, name
    for arm, path in MODELS.items():
        digest = PLAN['parent']['sha256'] if arm == '4C' else json.loads((path.parent/'completion.json').read_text())['checkpoint_sha256']
        assert ev.sha(path) == digest, arm


def prepare():
    guards()
    if OUT.exists():
        raise FileExistsError('Preserve existing Experiment 5 evaluation')
    checks = ro.mechanics_checks()
    checks['policy_actor_accounting'] = actor_check()
    p = json.loads((SECTION/'development_evaluation/protocol.json').read_text())
    future = PLAN['future_development']
    p.update(date='2026-10-28', relative_seed=future['relative_seed'], pose_seed=future['pose_seed'],
        primary='Final-horizon grouped value MAE: 5R versus 5U; parent comparison also reported.',
        secondary=['All 21 horizons, classification errors and value tails',
                   'Pose, heading alias, physical and temporal checks',
                   'Approximate reference gradients and stable switching signs at .25/.5 s',
                   'Common uniform physics residual audit; saved finer local maps as secondary diagnostic'],
        models={k:dict(path=str(v.relative_to(ev.ROOT)),sha256=ev.sha(v)) for k,v in MODELS.items()},
        source_hashes={f.name:ev.sha(f) for f in SOURCES},
        protected_inputs={str(f.relative_to(ev.ROOT)):ev.sha(f) for f in ev.ROOT.rglob('checkpoint*.pt')},
        experiment5_protocol_sha256=ev.sha(HERE/'protocol.json'),
        physics_audit=dict(seed=future['physics_audit_seed'],points=8192,forced_terminal_rows=0,
                           distribution='uniform full joint box and full horizon; shared by all models'),
        local_diagnostic='Saved local queries and 161/193 reference maps; evaluation only, no new reference solve.',
        rollouts='Separate frozen 7x7 policy matrix with 200 fresh groups and dt .01/.005; see rollouts/protocol.json')
    p['bootstrap'].update(seed=future['group_bootstrap_seed'],pairs=[['5U','5R'],['4C','5U'],['4C','5R']])
    for f in [ev.ROOT/'evaluation/reserved_final_states/states.npz',
              SECTION/'local_physics_audit/local_queries.npz',
              SECTION/'local_reference_refinement/fixed_queries.npz']:
        p['protected_inputs'][str(f.relative_to(ev.ROOT))] = ev.sha(f)
    OUT.mkdir(); (OUT/'sources').mkdir()
    ev.dump(OUT/'protocol.json', p)
    for f in SOURCES: shutil.copy2(f, OUT/'sources'/f.name)
    rp = json.loads((SECTION/'closed_loop_evaluation/protocol.json').read_text())
    ids = np.random.default_rng(future['rollout_subset_seed']).choice(6000, 200, replace=False)
    rp.update(purpose='Experiment 5 closed-loop development comparison; finite policies, not a safety certificate',
        subset_seed=future['rollout_subset_seed'],relative_group_ids=ids.tolist(),policies=POLICIES,
        ordered_pair_count=49, tests='Full 7x7 ordered policy matrix at each dt; finite-policy worst outcomes reported.',
        primary='Report parent/5U/5R evaders against reference pursuer at dt=.005 on reference-safe subset.',
        checkpoint_paths={k:str(v.relative_to(ev.ROOT)) for k,v in MODELS.items()},
        source_hashes=p['source_hashes'],protected_inputs=p['protected_inputs'],mechanics_checks=checks,
        state='Fresh Experiment 5 development groups only; reserved future final set remains unused.',
        learned_controls='Joint u=3 sign(V_heading_e), d=-3 sign(V_heading_p).')
    ro.OUT.mkdir(); (ro.OUT/'sources').mkdir()
    ev.dump(ro.OUT/'protocol.json', rp)
    for f in SOURCES: shutil.copy2(f, ro.OUT/'sources'/f.name)
    print('Evaluation protocols frozen; states and labels not yet generated.', flush=True)


def audits():
    p = json.loads((OUT/'protocol.json').read_text())
    assert p['source_hashes'] == {f.name:ev.sha(f) for f in SOURCES}
    if (OUT/'physics_audit.json').exists():
        raise FileExistsError('Preserve completed audits')
    torch.set_num_threads(2)
    models = load_models(); c = models['4C'].c
    q = PairedSampler(c, physics_seed=p['physics_audit']['seed']).sample(8192, .5, 0)
    with np.load(SECTION/'local_physics_audit/local_queries.npz') as f:
        local = {k:f[k] for k in f.files}
    saved = {'q':q.numpy()}; rows=[]; local_rows=[]; initial_rows=[]
    with np.load(SECTION/'local_reference_refinement/fixed_queries.npz') as f:
        initial = f['initial_poses']
    for name, model in models.items():
        before = {k:v.clone() for k,v in model.state_dict().items()}
        terms=[]
        for batch in q.split(1024):
            r,_,_ = residual(model, batch, create_graph=False)
            terms.append(r.detach().numpy())
        r = np.concatenate(terms); saved[name] = r
        for subset,mask in [('all',np.ones(len(q),dtype=bool)),('late_tau_ge_0.4',q[:,0].numpy()>=.4)]:
            values=abs(r[mask]);rows.append(dict(model=name,subset=subset,count=int(mask.sum()),
                mean_abs_residual=float(values.mean()),p99_abs_residual=float(np.quantile(values,.99)),
                max_abs_residual=float(values.max())))
        v,g=ev.model_grad(model,local['q6'])
        coeff=g[:,6]; co=local['coarse_coefficient']; fine=local['fine_coefficient']
        stable=(np.sign(co)==np.sign(fine))&(abs(co)>.01)&(abs(fine)>.01)
        local_rows.append(dict(model=name,known_region=True,points=len(v),stable_count=int(stable.sum()),
            stable_turn_sign_agreement=float(np.mean(np.sign(coeff[stable])==np.sign(fine[stable]))),
            value_mae_vs_193=float(abs(v-local['fine_value']).mean())))
        np.savez_compressed(OUT/f'known_local_{name}.npz',value=v,evader_coefficient=coeff)
        iv,ig=ev.model_grad(model,np.column_stack([np.full(4,.5),initial]))
        initial_rows.append(dict(model=name,values=iv.tolist(),evader_coefficients=ig[:,6].tolist(),
                                 initial_evader_turns=(3*np.sign(ig[:,6])).tolist()))
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in before.items())
        assert all(param.grad is None for param in model.parameters())
    np.savez_compressed(OUT/'uniform_physics_audit.npz',**saved)
    ev.dump(OUT/'physics_audit.json',rows);ev.write_csv(OUT/'physics_audit.csv',rows)
    ev.dump(OUT/'known_local_metrics.json',dict(local=local_rows,initial=initial_rows,
        scope='Secondary known-case diagnostic. Refined reference remains approximate; no new rollout here.'))
    guards()
    print('Common physics audit and known-region read-only checks completed.',flush=True)


if __name__ == '__main__':
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['prepare','values','audits','rollouts'])
    args=ap.parse_args();configure()
    if args.phase=='prepare':prepare()
    elif args.phase=='values':ev.evaluate()
    elif args.phase=='audits':audits()
    else:ro.evaluate()

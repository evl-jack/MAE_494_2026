"""Read-only verification of completed Experiment 5 endpoints; never trains."""
import csv
import hashlib
import json
import math
from pathlib import Path

import torch
from runner import ExperimentState, ROOT

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def equal(a, b):
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and torch.equal(a, b)
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def verify():
    protocol = json.loads((HERE / 'protocol.json').read_text())
    frozen = json.loads((HERE / 'preparation_manifest.json').read_text())
    for name, digest in frozen['frozen_files'].items():
        assert sha(HERE / name) == digest, name
    parent_path = ROOT / protocol['parent']['path']
    assert sha(parent_path) == protocol['parent']['sha256']
    parent = torch.load(parent_path, map_location='cpu', weights_only=True)
    results, states = {}, {}
    for arm, mode in protocol['arms'].items():
        folder = HERE / 'runs' / arm
        summary = json.loads((folder / 'completion.json').read_text())
        assert summary['status'] == 'completed' and summary['mode'] == mode
        assert summary['additional_updates'] == 2000
        assert summary['cumulative_physics_updates'] == 24000
        assert summary['train_point_evaluations'] == 4096000
        assert summary['checkpoint_sha256'] == sha(folder / 'checkpoint.pt')
        assert summary['parent']['sha256'] == protocol['parent']['sha256']
        assert summary['scored_candidates'] == (327680 if mode == 'mixed' else 0)
        assert summary['bank_refreshes'] == (40 if mode == 'mixed' else 0)
        assert summary['execution'] == 'VS Code Run and Debug; main project interpreter and output'
        assert sha(folder / 'protocol.json') == sha(HERE / 'protocol.json')
        for name, digest in protocol['source_hashes'].items():
            assert sha(folder / 'sources' / name) == digest, name
        state = ExperimentState.load(folder / 'checkpoint.pt', sha(HERE / 'protocol.json'), mode)
        assert state.step == state.total == state.sampler.step == 2000
        assert all(torch.isfinite(v).all() for v in state.model.state_dict().values())
        for key, item in state.optimizer.state_dict()['state'].items():
            assert float(item['step']) == float(parent['optimizer']['state'][key]['step']) + 2000
            assert all(torch.isfinite(v).all() for v in item.values() if isinstance(v, torch.Tensor))
        with (folder / 'history.csv').open(newline='') as f:
            rows = list(csv.DictReader(f))
        assert [int(row['additional_step']) for row in rows] == [1] + list(range(100, 2001, 100))
        assert all(float(row['terminal_max_abs']) == 0 for row in rows)
        assert all(math.isfinite(float(v)) for row in rows for k, v in row.items() if k != 'mode')
        assert not equal(state.model.state_dict(), parent['model'])
        results[arm] = summary
        states[arm] = state
    assert equal(states['5U'].sampler.base.state_dict(), states['5R'].sampler.base.state_dict())
    assert not equal(states['5U'].model.state_dict(), states['5R'].model.state_dict())
    return dict(status='passed', frozen_preparation_unchanged=True, parent_checkpoint_unchanged=True,
                both_completed_fixed_budgets=True, inherited_adam_steps_advanced_exactly=True,
                paired_base_sampler_end_states_identical=True, endpoints_differ=True,
                logged_terminal_error_zero=True, all_weights_optimizer_and_logs_finite=True,
                runs=results, accuracy_evaluation='pending; training losses use different distributions')


if __name__ == '__main__':
    result = verify()
    (HERE / 'training_verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print('Completed-run checks passed; no training or accuracy evaluation performed.')

"""Locate Experiment 3A outliers; diagnostic inference/reference solve only."""
import argparse
import json
import time
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from deepreach import load_checkpoint, value_grad, hamiltonian, target
from diagnostics import ROOT, dump, sha, write_csv
from reference import solve, interpolate
from validate import predict, error


def run(folder):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
    sweep=ROOT/'lookahead_21points_20261027/heldout_values.npz'
    candidate=ROOT/'experiments/experiment_3_a/candidate_values.npz'
    checkpoint=ROOT/'runs/experiment_3_a_constraints/checkpoint.pt'
    fine_cache=ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz'
    protected=[sweep,candidate,checkpoint,fine_cache,ROOT/'runs/experiment_2_a_loss_20261022/checkpoint.pt']
    before={str(p.relative_to(ROOT)):sha(p) for p in protected}
    with np.load(sweep) as f:
        states=f['states'].copy(); times=f['times'].copy(); truth=f['reference'].copy(); a=f['a'].copy()
    with np.load(candidate) as f:
        np.testing.assert_array_equal(f['times'],times)
        values=f['predictions'].copy()
    torch.set_num_threads(2)
    model,ck=load_checkpoint(checkpoint); model.eval(); c=ck['config']
    final,reference=values[-1],truth[-1]
    e=final-reference; ae=abs(e); radius=np.linalg.norm(states[:,:2],axis=1)
    order=np.argsort(ae)[::-1]; n=len(states); count=int(np.ceil(.01*n)); top=order[:count]
    is_top=np.zeros(n,dtype=bool); is_top[top]=True
    np.testing.assert_allclose(predict(model,np.column_stack([np.full(n,.5),states])),final,rtol=0,atol=0)
    print('Checking equivalent headings, reflection symmetry and residuals',flush=True)
    mirrored=states.copy(); mirrored[:,1:]*=-1
    mirror_values=predict(model,np.column_stack([np.full(n,.5),mirrored]))
    eligible=abs(states[:,2])>=.8*np.pi
    alias_states=states[eligible].copy(); alias_states[:,2]-=np.sign(alias_states[:,2])*2*np.pi
    assert np.max(abs(alias_states[:,2]))<=c['angle_factor']*np.pi+1e-12
    alias_values=predict(model,np.column_stack([np.full(len(alias_states),.5),alias_states]))
    all_alias=np.full(n,np.nan); all_alias[eligible]=alias_values
    q=torch.tensor(np.column_stack([np.full(n,.5),states]),dtype=torch.float32)
    v,dv=value_grad(model,q)
    free=dv[:,0]-hamiltonian(q[:,1:],dv[:,1:],c)
    obstacle=v-target(q[:,1:],c)
    vi=torch.maximum(free,obstacle)
    deriv=dv.detach().numpy(); vi=vi.detach().numpy(); free=free.detach().numpy()
    np.savez_compressed(folder/'point_diagnostics.npz',states=states,derivatives=deriv,vi=vi,
                        free_residual=free,mirror_values=mirror_values,alias_indices=np.flatnonzero(eligible),alias_values=alias_values)
    with np.load(fine_cache) as f:
        fine=dict(x=f['x'],theta=f['theta'],values={.5:f['values'][-1]})
    fine_values=interpolate(fine,.5,states)
    mirror_reference=interpolate(fine,.5,mirrored)
    alias_reference=interpolate(fine,.5,alias_states)
    symmetry_reference_max=float(np.max(abs(fine_values-mirror_reference)))
    alias_reference_max=float(np.max(abs(fine_values[eligible]-alias_reference)))
    assert max(symmetry_reference_max,alias_reference_max)<1e-12
    # One local refinement comparison quantifies reference sensitivity at the
    # same worst states. Grid differences are not certified error bounds.
    signature=dict(solver=sha(ROOT/'reference.py'),fine=sha(fine_cache),sweep=sha(sweep),
                   config={k:c[k] for k in ['domain','radius','speed','turn','horizon']})
    metadata=folder/'reference_check.json'; coarse_file=folder/'coarse_query_values.npz'
    old=json.loads(metadata.read_text()) if metadata.exists() else None
    if old and old.get('signature')==signature and coarse_file.exists():
        with np.load(coarse_file) as f: coarse_values=f['values'].copy()
        seconds=old['construction_seconds']
    else:
        print('Solving one 97x97x72 grid for local outlier reference sensitivity; no training',flush=True)
        started=time.perf_counter(); coarse=solve(c,97,72,[0.,.25,.5])
        seconds=time.perf_counter()-started
        coarse_values=interpolate(coarse,.5,states); del coarse
        np.savez_compressed(coarse_file,values=coarse_values)
    ref_check=dict(signature=signature,construction_seconds=seconds,
        all_states_coarse_vs_fine=error(coarse_values,fine_values),
        top_one_percent_coarse_vs_fine=error(coarse_values[top],fine_values[top]),
        dense_vs_original_fine=error(reference,fine_values),
        reference_reflection_max=symmetry_reference_max,reference_alias_max=alias_reference_max,
        note='97x97x72 versus 129x129x96 at the selected validation states; empirical sensitivity, not an error bound.')
    dump(metadata,ref_check)
    rows=[]
    for rank,i in enumerate(top,1):
        rows.append(dict(rank=rank,state_index=int(i),x=float(states[i,0]),y=float(states[i,1]),
            heading_rad=float(states[i,2]),heading_deg=float(np.degrees(states[i,2])),separation=float(radius[i]),
            predicted=float(final[i]),reference=float(reference[i]),signed_error=float(e[i]),
            a_signed_error=float(a[-1,i]-reference[i]),mirror_prediction=float(mirror_values[i]),
            alias_prediction=float(all_alias[i]) if eligible[i] else '',vi_residual=float(vi[i]),
            free_residual=float(free[i]),time_derivative=float(deriv[i,0]),
            below_physical_minimum=bool(final[i]<-c['radius']-1e-4),
            coarse_reference=float(coarse_values[i]),original_fine_reference=float(fine_values[i])))
    write_csv(folder/'worst_240_states.csv',rows)
    groups=[]
    for name,mask in [('all',np.ones(n,dtype=bool)),('top_1_percent',is_top),('remaining_99_percent',~is_top),
          ('inside_collision',radius<=c['radius']),('initially_separated',radius>c['radius']),
          ('below_physical_minimum',final<-c['radius']-1e-4),
          ('false_unsafe',(final<=0)&(reference>0)),('pursuer_ahead',states[:,0]>0),
          ('pursuer_behind',states[:,0]<=0),('opposing_headings',abs(states[:,2])>3*np.pi/4)]:
        groups.append(dict(group=name,count=int(mask.sum()),mae=float(ae[mask].mean()),
            squared_error_share=float(np.sum(e[mask]**2)/np.sum(e**2)),
            vi_mae=float(np.mean(abs(vi[mask]))),mean_separation=float(radius[mask].mean())))
    write_csv(folder/'groups.csv',groups); dump(folder/'groups.json',groups)
    per_time=[]
    for k,t in enumerate(times):
        err=values[k]-truth[k]; selected=np.argsort(abs(err))[-count:]
        per_time.append(dict(tau=float(t),mae=float(np.mean(abs(err))),
            p99_absolute_error=float(np.quantile(abs(err),.99)),
            top_one_percent_squared_error_share=float(np.sum(err[selected]**2)/np.sum(err**2)),
            fixed_final_outlier_cohort_mae=float(np.mean(abs(err[top]))),
            below_physical_minimum_count=int(np.sum(values[k]<-c['radius']-1e-4))))
    write_csv(folder/'by_time.csv',per_time)
    clipped=np.maximum(final,-c['radius'])
    increment=values[-1]-values[-2]; positive=increment[increment>1e-5]
    summary=dict(outlier_definition='240 states with largest absolute value error at tau=.5; selected on validation.',
        count=n,top_count=count,absolute_error_quantiles={str(p):float(np.quantile(ae,p)) for p in [.5,.9,.95,.99,1]},
        top_squared_error_share=float(np.sum(e[top]**2)/np.sum(e**2)),
        top_pursuer_ahead_count=int(np.sum(states[top,0]>0)),
        top_opposing_heading_count=int(np.sum(abs(states[top,2])>3*np.pi/4)),
        top_negative_error_count=int(np.sum(e[top]<0)),
        top_separation_min=float(radius[top].min()),top_separation_max=float(radius[top].max()),
        alias_pair_count=int(eligible.sum()),alias_gap_mae=float(np.mean(abs(alias_values-final[eligible]))),
        alias_gap_p95=float(np.quantile(abs(alias_values-final[eligible]),.95)),
        reflection_gap_mae=float(np.mean(abs(mirror_values-final))),
        clipping_diagnostic=dict(original=error(final,reference),clipped=error(clipped,reference),
            mae_reduction_percent=float(100*(1-np.mean(abs(clipped-reference))/np.mean(ae))),
            note='Offline analytic-bound clipping only; saved model is unchanged. It does not change sign classifications.'),
        upward_increment=dict(count=int(len(positive)),median_m=float(np.median(positive)),
                              p95_m=float(np.quantile(positive,.95)),max_m=float(positive.max())))
    dump(folder/'summary.json',summary)
    fig,axes=plt.subplots(2,3,figsize=(15,8.5),layout='constrained')
    im=axes[0,0].scatter(states[:,0],states[:,1],c=ae,s=3,cmap='magma',vmin=0,vmax=.2,rasterized=True)
    axes[0,0].scatter(states[top,0],states[top,1],s=10,facecolors='none',edgecolors='cyan',linewidths=.5)
    axes[0,0].add_patch(plt.Circle((0,0),c['radius'],fill=False,color='lime'))
    axes[0,0].set(xlabel='Relative x [m]',ylabel='Relative y [m]',title='Final error; cyan = worst 1%, green = collision disk')
    fig.colorbar(im,ax=axes[0,0],label='Absolute value error [m]')
    axes[0,1].scatter(states[:,0],np.degrees(states[:,2]),s=1,color='lightgray',rasterized=True)
    axes[0,1].scatter(states[top,0],np.degrees(states[top,2]),s=9,c=states[top,1],cmap='coolwarm')
    axes[0,1].set(xlabel='Relative x [m]',ylabel='Relative heading [degrees]',title='Worst 1%: x and heading (color = y)')
    axes[0,2].plot(100*np.arange(1,n+1)/n,100*np.cumsum(e[order]**2)/np.sum(e**2))
    axes[0,2].set(xlabel='States ranked from largest error [%]',ylabel='Cumulative squared error [%]',
                  title='Error concentration',xscale='log'); axes[0,2].grid(alpha=.25)
    i=int(top[0])
    for val,label in [(truth,'Reference'),(a,'Experiment 2A'),(values,'Experiment 3A')]:
        axes[1,0].plot(times,val[:,i],label=label)
    axes[1,0].axhline(0,color='gray',linestyle=':')
    axes[1,0].set(xlabel='Look-ahead τ [s]',ylabel='Value [m]',title=f'Worst state #{i}: same state, varying horizon')
    axes[1,0].legend(fontsize=8)
    axes[1,1].scatter(reference,final,s=2,color='lightgray',rasterized=True)
    axes[1,1].scatter(reference[top],final[top],s=7,color='crimson')
    lim=[min(reference.min(),final.min()),max(reference.max(),final.max())]
    axes[1,1].plot(lim,lim,'k--');axes[1,1].axhline(-c['radius'],linestyle=':',color='blue')
    axes[1,1].set(xlabel='Reference value [m]',ylabel='PINN value [m]',title='Worst errors are below the diagonal')
    axes[1,2].bar(['MAE','RMSE'],[np.mean(ae),np.sqrt(np.mean(e**2))],label='Original',width=.6)
    axes[1,2].bar(['MAE','RMSE'],[np.mean(abs(clipped-reference)),np.sqrt(np.mean((clipped-reference)**2))],
                  label='Clipped to -R (diagnostic)',width=.3)
    axes[1,2].set(ylabel='Error [m]',title='Lower-bound clipping leaves most error');axes[1,2].legend(fontsize=8)
    fig.suptitle('Experiment 3A outliers at .5 s: descriptive validation analysis; no training')
    fig.savefig(folder/'outlier_breakdown.png',dpi=170);plt.close(fig)
    after={str(p.relative_to(ROOT)):sha(p) for p in protected}
    assert before==after
    dump(folder/'manifest.json',dict(training=False,model_unchanged=True,protected_inputs=after,
         sources={s:sha(ROOT/s) for s in ['analyze_outliers.py','deepreach.py','reference.py','validate.py']},
         checks=dict(saved_predictions_reproduced_exactly=True,reference_invariances_verified=True,
                     all_protected_inputs_unchanged=True),state_seed=20261019,lookahead=.5,
         derivative_note='Value derivatives and equation residuals only; no controller rollout or training.'))
    print('Completed outlier analysis: '+str(folder),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',default=str(ROOT/'experiments/experiment_3_a/outliers'))
    args=parser.parse_args();run(args.out)

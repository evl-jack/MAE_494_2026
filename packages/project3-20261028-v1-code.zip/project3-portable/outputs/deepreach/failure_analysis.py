"""Describe Air3D value and equation failures without training or control claims."""
import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from deepreach import load_checkpoint, value_grad, hamiltonian, target
from diagnostics import ROOT, RUNS, dump, sha, write_csv


def stats(prediction, truth, mask):
    a, b = prediction[mask], truth[mask]
    if not len(a):
        return dict(count=0)
    e = a-b
    unsafe = b <= 0
    return dict(count=int(len(a)), mae=float(np.mean(abs(e))), bias=float(e.mean()),
                rmse=float(np.sqrt(np.mean(e*e))), reference_unsafe=int(unsafe.sum()),
                false_safe=int(np.sum((a>0)&unsafe)),
                false_safe_rate=float(np.mean(a[unsafe]>0)) if unsafe.any() else None)


def run(folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(2)
    source = ROOT/'lookahead_21points_20261027/heldout_values.npz'
    cache = ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz'
    protected = [source, cache]+[ROOT/'runs'/d/'checkpoint.pt' for _,_,d in RUNS]
    before = {str(p.relative_to(ROOT)):sha(p) for p in protected}
    with np.load(source) as saved:
        states, times, truth = saved['states'].copy(), saved['times'].copy(), saved['reference'].copy()
        predictions = {slug:saved[slug].copy() for _,slug,_ in RUNS}
    radius = np.linalg.norm(states[:,:2], axis=1)
    heading = states[:,2]
    temporal, grouped, equations, seams, exposures, exact_checks = [], [], [], [], [], []
    raw = dict(states=states[:6000], times=times)
    for label, slug, directory in RUNS:
        print('Analyzing '+label, flush=True)
        model, ck = load_checkpoint(ROOT/'runs'/directory/'checkpoint.pt')
        model.eval()
        c = ck['config']
        e0 = predictions[slug][0]-truth[0]
        rng = np.random.default_rng(20261028)
        domain_states = rng.uniform([-c['domain'],-c['domain'],-c['angle_factor']*np.pi],
                                    [c['domain'],c['domain'],c['angle_factor']*np.pi], (6000,3))
        for k, tau in enumerate(times):
            pred, reference = predictions[slug][k], truth[k]
            e = pred-reference
            delta = e-e0
            mse = float(np.mean(e*e))
            decomposition = float(np.mean(e0*e0)+2*np.mean(e0*delta)+np.mean(delta*delta))
            np.testing.assert_allclose(mse,decomposition,rtol=1e-12,atol=1e-15)
            temporal.append(dict(model=label,slug=slug,tau=float(tau),mse=mse,
                terminal_mse=float(np.mean(e0*e0)),cross_term=float(2*np.mean(e0*delta)),
                error_change_mse=float(np.mean(delta*delta)),bias=float(e.mean()),
                positive_error_fraction=float(np.mean(e>0)),bias_squared_share_of_mse=float(e.mean()**2/mse),
                temporal_increase_fraction=float(np.mean(pred>predictions[slug][max(0,k-1)]+1e-5)) if k else 0.))
            inside=radius<=c['radius']
            exact_checks.append(dict(model=label,slug=slug,tau=float(tau),
                initially_collided_count=int(inside.sum()),
                initially_collided_predicted_safe=int(np.sum(inside&(pred>0))),
                initially_collided_false_safe_rate=float(np.mean(pred[inside]>0)),
                obstacle_violation_fraction=float(np.mean(pred>radius-c['radius']+1e-4)),
                reference_initially_collided_positive_count=int(np.sum(inside&(reference>0))),
                reference_time_increase_fraction=float(np.mean(reference>truth[max(0,k-1)]+1e-10)) if k else 0.))
            bins = [('separation_m',radius,[0,.25,.4,.6,1.]),
                    ('heading_rad',heading,np.linspace(-np.pi,np.pi,9)),
                    ('reference_value_m',reference,[-np.inf,-.1,-.05,-.025,0,.025,.05,.1,np.inf])]
            for axis, variable, edges in bins:
                for lo,hi in zip(edges[:-1],edges[1:]):
                    mask = (variable>lo)&(variable<=hi)
                    grouped.append(dict(model=label,slug=slug,tau=float(tau),axis=axis,
                         lower=str(float(lo)),upper=str(float(hi)),**stats(pred,reference,mask)))
            for region, sample_states in [('interior',states[:6000]),('training_box',domain_states)]:
                q = torch.tensor(np.column_stack([np.full(len(sample_states),tau),sample_states]),dtype=torch.float32)
                v,dv = value_grad(model,q)
                free = dv[:,0]-hamiltonian(q[:,1:],dv[:,1:],c)
                obstacle = v-target(q[:,1:],c)
                vi = torch.maximum(free,obstacle)
                arrays = [v.detach().numpy(),dv.detach().numpy(),free.detach().numpy(),
                          obstacle.detach().numpy(),vi.detach().numpy()]
                va,der,fr,ob,re = arrays
                equations.append(dict(model=label,slug=slug,tau=float(tau),region=region,count=len(q),
                    vi_mae=float(np.mean(abs(re))),vi_p95=float(np.quantile(abs(re),.95)),
                    free_pde_mae=float(np.mean(abs(fr))),obstacle_positive_mean=float(np.maximum(ob,0).mean()),
                    obstacle_violation_fraction=float(np.mean(ob>1e-4)),
                    time_derivative_positive_fraction=float(np.mean(der[:,0]>1e-4))))
                if region=='interior':
                    raw[f'{slug}_{k}_value']=va
                    raw[f'{slug}_{k}_derivatives']=der
                    raw[f'{slug}_{k}_vi']=re
                    raw[f'{slug}_{k}_free']=fr
                    raw[f'{slug}_{k}_obstacle']=ob
            # Same physical heading at -pi and +pi should give the same value.
            seam_values=[]
            for angle in [-np.pi,np.pi]:
                q = torch.tensor(np.column_stack([np.full(6000,tau),states[:6000,:2],np.full(6000,angle)]),dtype=torch.float32)
                with torch.no_grad():
                    seam_values.append(model(q).numpy())
            seam = seam_values[1]-seam_values[0]
            seams.append(dict(model=label,slug=slug,tau=float(tau),value_gap_mae=float(np.mean(abs(seam))),
                              value_gap_p95=float(np.quantile(abs(seam),.95))))
        for threshold in [.4,.475]:
            a=threshold/c['horizon']
            fraction=1-a+a*np.log(a)
            hold=c.get('full_horizon_steps',0)
            expected=(c['samples']-c['terminal_samples'])*(c['curriculum_steps']*fraction+hold*(1-a))
            exposures.append(dict(model=label,slug=slug,threshold=threshold,
                curriculum_expected_nonterminal_fraction=float(fraction),
                hold_expected_nonterminal_fraction=float(1-a),expected_nonterminal_draws=float(expected),
                note='Continuous-ramp approximation to expected sampling, not a log of actual draws.'))
    for name,rows in [('time_decomposition',temporal),('error_groups',grouped),('equation_checks',equations),
                      ('heading_seam',seams),('curriculum_exposure',exposures),('exact_properties',exact_checks)]:
        keys=list(dict.fromkeys(key for row in rows for key in row))
        with (folder/(name+'.csv')).open('w',newline='',encoding='utf-8') as stream:
            writer=csv.DictWriter(stream,fieldnames=keys); writer.writeheader(); writer.writerows(rows)
        dump(folder/(name+'.json'),rows)
    np.savez_compressed(folder/'equation_samples.npz',**raw)
    fig,axes=plt.subplots(2,3,figsize=(15,8),layout='constrained')
    for label,slug,_ in RUNS:
        trows=[r for r in temporal if r['slug']==slug]
        eq=[r for r in equations if r['slug']==slug and r['region']=='interior']
        sm=[r for r in seams if r['slug']==slug]
        axes[0,0].plot(times,[r['bias'] for r in trows],label=label)
        axes[0,1].plot(times,[r['vi_mae'] for r in eq])
        axes[0,2].plot(times,[r['value_gap_mae'] for r in sm])
        for j,axis in enumerate(['separation_m','heading_rad','reference_value_m']):
            gr=[r for r in grouped if r['slug']==slug and r['axis']==axis and r['tau']==.5 and r['count']]
            axes[1,j].plot(range(len(gr)),[100*r['false_safe_rate'] if j==2 and r.get('false_safe_rate') is not None else (np.nan if j==2 else r['mae']) for r in gr],'o-')
            axes[1,j].set_xticks(range(len(gr)),[f'({float(r["lower"]):.2g}, {float(r["upper"]):.2g}]' for r in gr],rotation=40,ha='right')
    axes[0,0].legend(fontsize=8)
    for ax,title in zip(axes.flat,['Signed value bias [m]','HJI VI residual MAE [m/s]*','Periodic heading value gap MAE [m]',
                                'Final MAE by separation [m]','Final MAE by heading [rad]','Final false-safe rate by reference V [%]']):
        ax.set_title(title); ax.grid(alpha=.25)
    # The training VI combines a differential term with an obstacle value term;
    # avoid assigning it a single physical unit.
    axes[0,1].set_title('HJI VI residual MAE [training convention]')
    axes[1,0].set_ylabel('Value MAE [m]')
    axes[1,1].set_ylabel('Value MAE [m]')
    for ax in axes[0]: ax.set_xlabel('Look-ahead τ [s]')
    fig.suptitle('Where error occurs: four unchanged networks; validation diagnostics')
    fig.savefig(folder/'failure_breakdown.png',dpi=170); plt.close(fig)
    after={str(p.relative_to(ROOT)):sha(p) for p in protected}
    if after!=before: raise ValueError('Protected inputs changed')
    dump(folder/'manifest.json',dict(training=False,protected_inputs=after,
         sources={name:sha(ROOT/name) for name in ['failure_analysis.py','deepreach.py','diagnostics.py']},
         value_states=24000,equation_states_per_region=6000,times=times.tolist(),threads=2,
         checks=dict(error_decomposition_identity=True,checkpoints_and_reference_unchanged=True)))
    print('Completed '+str(folder),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',default=str(ROOT/'failure_analysis_20261027'))
    args=parser.parse_args()
    run(args.out)

"""Evaluate all fixed 3E endpoints after training; never trains."""
import csv
import json
import shutil
import time
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from deepreach import load_checkpoint
from diagnostics import ROOT, dump, sha, write_csv
from validate import predict, classification, error, mechanical_checks
from probe_step_directions import physics
from capacity_budget import FOLDER, linear_macs


def run():
    clock=time.perf_counter();torch.set_num_threads(2)
    manifest=json.loads((FOLDER/'training_manifest.json').read_text());assert manifest['status']=='completed'
    protected=dict(manifest['protected_inputs'])
    for endpoint in manifest['endpoints']:protected[endpoint['checkpoint']]=endpoint['sha256']
    audit_path=ROOT/'experiments/experiment_3_d_refinement/evaluation_physics_queries.npz'
    protected[str(audit_path.relative_to(ROOT))]=sha(audit_path)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    with np.load(ROOT/'lookahead_21points_20261027/heldout_values.npz') as f:
        states=f['states'].copy();times=f['times'].copy();refs=f['reference'].copy()
    with np.load(audit_path) as f:audit=f['queries'].copy()
    with (ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv').open() as stream:
        top=np.array([int(r['state_index']) for r in csv.DictReader(stream)])
    choices=[('3A_64_10000',ROOT/'runs/experiment_3_a_constraints/checkpoint.pt'),
             ('Adam200_64_10200',ROOT/'experiments/experiment_3_d_refinement/adam/checkpoint_200.pt')]
    for endpoint in manifest['endpoints']:
        if endpoint['run']=='long64' and endpoint['step'] in [10200,10800]:continue
        choices.append((endpoint['run']+'_'+str(endpoint['step']),ROOT/endpoint['checkpoint']))
    rows=[];final=[];checks=[];values={}
    for name,path in choices:
        print('Evaluating capacity/budget endpoint '+name,flush=True)
        model,ck=load_checkpoint(path);model.eval();c=ck['config']
        original={k:v.clone() for k,v in model.state_dict().items()};parameters={k:p.detach() for k,p in model.named_parameters()}
        audit_vi=physics(model,parameters,audit,c)
        predictions=[];terminal_error=None;max_obstacle=-1e30
        for j,t in enumerate(times):
            q=np.column_stack([np.full(len(states),t),states]);pred=predict(model,q)
            assert np.isfinite(pred).all();predictions.append(pred);delta=pred-refs[j]
            analytic=np.hypot(states[:,0],states[:,1])-c['radius']
            max_obstacle=max(max_obstacle,float(np.max(pred-analytic)))
            if t==0:terminal_error=float(np.max(abs(pred-analytic)))
            rows.append(dict(model=name,time=float(t),**error(pred,refs[j]),**classification(pred,refs[j]),
                relative_l2=float(np.linalg.norm(delta)/np.linalg.norm(refs[j])),bias=float(delta.mean()),
                fixed_outlier_mae=float(abs(delta[top]).mean()),own_worst_240_mae=float(np.sort(abs(delta))[-240:].mean()),
                p95_abs=float(np.quantile(abs(delta),.95)),p99_abs=float(np.quantile(abs(delta),.99)),
                ahead_mae=float(abs(delta[states[:,0]>0]).mean()),behind_mae=float(abs(delta[states[:,0]<=0]).mean()),
                below_minus_radius_fraction=float(np.mean(pred<-.2501)),interior_vi_mae=physics(model,parameters,q,c),
                time_increase_from_previous_fraction=0. if j==0 else float(np.mean(pred>predictions[j-1]+1e-4))))
        pp=np.stack(predictions);values[name]=pp
        if name=='3A_64_10000':
            with np.load(ROOT/'experiments/experiment_3_a/candidate_values.npz') as f:
                np.testing.assert_allclose(pp,f['predictions'],rtol=1e-5,atol=2e-6)
        q=np.column_stack([np.full(len(states),.5),states]);q[:,3]=np.pi;plus=predict(model,q)
        q[:,3]=-np.pi;minus=predict(model,q)
        frow=dict(rows[-1],width=c['width'],parameters=sum(p.numel() for p in model.parameters()),
            total_steps=ck['step'],training_sample_points=ck['step']*c['samples'],linear_mac_proxy=ck['step']*c['samples']*linear_macs(c['width']),
            cumulative_training_seconds=ck['elapsed_seconds'],additional_training_seconds=ck.get('additional_training_seconds',ck['elapsed_seconds']),
            audit_physics_loss=audit_vi,heading_seam_mae=float(abs(plus-minus).mean()),
            mean_nonzero_horizon_mae=float(np.mean([r['mae'] for r in rows[-20:]])))
        final.append(frow)
        mechanical=mechanical_checks(model,c)
        assert terminal_error<2e-7 and max_obstacle<2e-7
        assert all(torch.equal(value,model.state_dict()[k]) for k,value in original.items())
        assert all(p.grad is None for p in model.parameters())
        checks.append(dict(model=name,terminal_max_abs=terminal_error,max_obstacle_violation=max(0.,max_obstacle),
            derivatives_and_hamiltonian=mechanical,weights_unchanged=True,no_parameter_gradients=True))
    write_csv(FOLDER/'comparison.csv',rows);write_csv(FOLDER/'final_comparison.csv',final)
    dump(FOLDER/'final_comparison.json',final);dump(FOLDER/'equation_checks.json',checks)
    np.savez_compressed(FOLDER/'endpoint_values.npz',times=times,**values)
    fig,axes=plt.subplots(2,2,figsize=(13,8.5),layout='constrained')
    for name,_ in choices:
        rr=[r for r in rows if r['model']==name]
        axes[0,0].plot(times,[r['mae'] for r in rr],label=name)
        axes[0,1].plot(times,[100*r['false_unsafe_fraction_of_reference_safe'] for r in rr])
        axes[1,0].plot(times,[r['fixed_outlier_mae'] for r in rr])
        axes[1,1].plot(times,[r['interior_vi_mae'] for r in rr])
    for ax in axes.flat:ax.set_xlabel('Look-ahead horizon [s]');ax.grid(alpha=.2)
    axes[0,0].set(title='Value accuracy',ylabel='MAE [m]');axes[0,0].legend(fontsize=7)
    axes[0,1].set(title='Conservative classification',ylabel='False-unsafe / reference-safe [%]')
    axes[1,0].set(title='Fixed original worst-240 states',ylabel='Cohort MAE [m]')
    axes[1,1].set(title='Physics on the comparison states',ylabel='Mean absolute VI residual')
    fig.suptitle('Experiment 3E: duration versus width; reused development references')
    fig.savefig(FOLDER/'comparison.png',dpi=170);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for name in ['long64','wide96']:
        with (ROOT/f'runs/experiment_3_e_{name}/history.csv').open() as stream:history=list(csv.DictReader(stream))
        axes[0].plot([int(r['step']) for r in history],[float(r['pde_mae']) for r in history],label=name)
    axes[0].set(yscale='log',xlabel='Total physics-gradient steps',ylabel='Logged construction loss',title='Different curricula/hold exposure stated in protocol');axes[0].legend()
    for r in final:
        axes[1].scatter(r['linear_mac_proxy']/1e12,r['mae'],s=30)
        right=r['linear_mac_proxy']/1e12>.35
        axes[1].annotate(r['model'],(r['linear_mac_proxy']/1e12,r['mae']),fontsize=7,
            xytext=(-6 if right else 4,4),ha='right' if right else 'left',textcoords='offset points')
    axes[1].set(xlabel='Nominal linear MAC work [trillions]',ylabel='Final-time MAE [m]',title='Work proxy, not measured FLOPs or time')
    fig.savefig(FOLDER/'budget_and_history.png',dpi=170);plt.close(fig)
    assert all(sha(ROOT/p)==h for p,h in protected.items())
    base=final[0];best_old=final[1]
    summary={r['model']:dict(mae_improvement_vs_3A_percent=100*(base['mae']-r['mae'])/base['mae'],
        mae_improvement_vs_Adam200_percent=100*(best_old['mae']-r['mae'])/best_old['mae'],
        nonzero_horizons_better_than_Adam200=sum(row['mae']<next(x['mae'] for x in rows if x['model']==best_old['model'] and x['time']==row['time']) for row in rows if row['model']==r['model'] and row['time']>0),
        maximum_false_safe_fraction_nonzero=max(row['false_safe_fraction_of_reference_unsafe'] for row in rows if row['model']==r['model'] and row['time']>0)) for r in final}
    dump(FOLDER/'evaluation_manifest.json',dict(status='completed',training=False,protected_inputs=protected,
        reserved_final_states_used=False,reference_usage='Existing development comparisons only, after all fixed endpoints completed.',
        sources={n:sha(ROOT/n) for n in ['compare_capacity_budget.py','deepreach.py','capacity_budget.py','validate.py']},
        summary=summary,elapsed_seconds=time.perf_counter()-clock))
    shutil.copy2(ROOT/'compare_capacity_budget.py',FOLDER/'sources/compare_capacity_budget.py')
    dump(FOLDER/'progress.json',dict(status='completed',training='completed',evaluation='completed'))
    print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':run()

# Final evaluation states — reservation consumed

These 24,000 states (seed 991731) are now used for the fixed [final evaluation](../final_evaluation_20261028/README.md). They are no longer an untouched test set and must not be reused as new final evidence after further tuning. The original states.npz bytes are unchanged; the original reservation metadata is archived with the final protocol. No development diagnosis used them before this evaluation.

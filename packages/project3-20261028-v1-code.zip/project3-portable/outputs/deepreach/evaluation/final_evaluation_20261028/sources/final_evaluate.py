"""One fixed final evaluation. No training, optimizer or model selection.

Prepare freezes source/model hashes before the reserved data are opened.
Evaluation consumes the reservation permanently. Resume repeats only the same
protocol after interruption; completed final records cannot be overwritten.
"""
import argparse
import json
import os
import shutil
import time
from datetime import datetime, timezone
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from deepreach import load_checkpoint, residual
from diagnostics import ROOT, dump, sha, write_csv
from reference import solve, interpolate
from validate import predict, error, classification, comparison_region

OUT=ROOT/'evaluation/final_evaluation_20261028'
RESERVED=ROOT/'evaluation/reserved_final_states'
STATE_SHA='f902bb08c7fe93d7a6275048e9cc41ddf2f4819be2f9a600597ae1d5666280c6'
SOURCE_NAMES=['final_evaluate.py','reference.py','deepreach.py','validate.py','diagnostics.py']
MODEL_PATHS={'3A': 'runs/experiment_3_a_constraints/checkpoint.pt',
    'Adam200':'experiments/experiment_3_d_refinement/adam/checkpoint_200.pt',
    'Long22000':'runs/experiment_3_e_long64/checkpoint_22000.pt'}


def atomic_npz(path,**arrays):
    temporary=path.with_suffix('.tmp')
    with temporary.open('wb') as stream:np.savez_compressed(stream,**arrays)
    os.replace(temporary,path)


def sources():return {name:sha(ROOT/name) for name in SOURCE_NAMES}


def prepare():
    if OUT.exists():raise FileExistsError('Final-evaluation folder exists; do not replace its protocol.')
    assert sha(RESERVED/'states.npz')==STATE_SHA
    reservation=json.loads((RESERVED/'manifest.json').read_text())
    assert reservation['status'].startswith('reserved;') and reservation['sha256']==STATE_SHA
    prior=json.loads((ROOT/'experiments/experiment_3_e_capacity_budget/evaluation_manifest.json').read_text())
    dense=json.loads((ROOT/'lookahead_21points_20261027/manifest.json').read_text())
    assert sha(ROOT/'reference.py')==dense['source_sha256']['reference.py']
    models={};c=None
    for name,relative in MODEL_PATHS.items():
        path=ROOT/relative;assert sha(path)==prior['protected_inputs'][str(path.relative_to(ROOT))]
        model,ck=load_checkpoint(path)
        if c is None:c=ck['config']
        for key in ['radius','speed','turn','domain','horizon','comparison_half_width','formulation','constraint_scale']:
            assert ck['config'][key]==c[key]
        models[name]=dict(path=relative,sha256=sha(path),step=ck['step'],width=ck['config']['width'])
    interior,dependency_radius=comparison_region(c)
    OUT.mkdir(parents=True);(OUT/'sources').mkdir()
    shutil.copy2(RESERVED/'manifest.json',OUT/'reservation_before_use.json')
    shutil.copy2(RESERVED/'README.md',OUT/'reservation_readme_before_use.md')
    protected={str(p.relative_to(ROOT)):sha(p) for p in list((ROOT/'runs').glob('**/checkpoint*.pt'))}
    for relative in list(MODEL_PATHS.values())+['evaluation/reserved_final_states/states.npz',
        'lookahead_21points_20261027/heldout_values.npz','runs/air3d_cpu_20261022/validation/reference_fine.npz',
        'experiments/experiment_3_e_capacity_budget/final_comparison.json']:
        protected[relative]=sha(ROOT/relative)
    protocol=dict(status='frozen before opening reserved states',date='2026-10-28',base_repository_commit='37e3e86',
        models=models,states=dict(path='evaluation/reserved_final_states/states.npz',sha256=STATE_SHA,count=24000,seed=991731),
        times=np.linspace(0,.5,21).tolist(),reference=dict(grid=[129,129,96],domain=2.,heading='periodic',
            solver='Unchanged first-order local Lax-Friedrichs obstacle solver',cfl=.8,
            output_times='Direct snapshots at all 21 times; spatial/heading interpolation only, no temporal interpolation.',
            comparison_half_width=interior,dependency_radius_bound=dependency_radius,
            consistency_checks='Original three fine snapshots within .001 m; recomputed old dense reference at first 64 development states within 1e-10 m.'),
        primary='Final-time value MAE of Long22000 versus Adam200; report all fixed models regardless of outcome.',
        secondary=['21-time MAE/RMSE/relative L2','unsafe-set IoU','both classification errors','p95/p99/max absolute error','each-model worst 240 MAE',
            'ahead/behind MAE','physical bound and horizon monotonicity diagnostics','comparison-state VI residual','analytic terminal/obstacle checks'],
        paired_uncertainty=dict(method='State-paired percentile bootstrap, final-time MAE and relative MAE improvement.',
            draws=2000,seed=991743,level=.95,pairs=['3A versus Long22000','Adam200 versus Long22000'],
            scope='Sampling uncertainty conditional on fixed trained models and approximate reference; not training-seed, solver or real-world safety uncertainty.'),
        prohibited='No training, tuning, additional model selection, optimizer updates, adaptive grid/time changes or new candidate models.',
        classification='V <= 0 is unsafe; reference labels are approximate numerical values.',
        temporal_increase_tolerance_m=.0001,below_minus_radius_tolerance_m=.0001,
        threads=2,device='cpu',source_sha256=sources(),protected_inputs=protected)
    dump(OUT/'protocol.json',protocol)
    for name in SOURCE_NAMES:shutil.copy2(ROOT/name,OUT/'sources'/name)
    print('Prepared fixed final protocol. Reserved inputs remain unconsumed: '+str(OUT/'protocol.json'),flush=True)


def physics_loss(model,q,c):
    total=0.
    for i in range(0,len(q),1024):
        r,_,_=residual(model,torch.tensor(q[i:i+1024],dtype=torch.float32),c,False)
        total+=float(r.abs().sum().detach())
    return total/len(q)


def paired_intervals(reference,predictions):
    errors={k:abs(v[-1].astype(float)-reference[-1]) for k,v in predictions.items()}
    rng=np.random.default_rng(991743);boot={k:[] for k in ['3A','Adam200']};diff={k:[] for k in boot}
    for _ in range(40):
        indices=rng.integers(0,len(reference[-1]),size=(50,len(reference[-1])))
        new=errors['Long22000'][indices].mean(axis=1)
        for name in boot:
            old=errors[name][indices].mean(axis=1)
            boot[name].extend(100*(old-new)/old);diff[name].extend(old-new)
    result={}
    for name in boot:
        result[name+'_versus_Long22000']=dict(
            observed_absolute_mae_reduction=float(errors[name].mean()-errors['Long22000'].mean()),
            absolute_mae_reduction_95_percentile_interval=np.quantile(diff[name],[.025,.975]).tolist(),
            observed_relative_mae_improvement_percent=float(100*(errors[name].mean()-errors['Long22000'].mean())/errors[name].mean()),
            relative_mae_improvement_percent_95_percentile_interval=np.quantile(boot[name],[.025,.975]).tolist())
    return result


def evaluate(resume=False,execution='managed process with existing project interpreter'):
    start=time.perf_counter();torch.set_num_threads(2)
    protocol=json.loads((OUT/'protocol.json').read_text());assert protocol['source_sha256']==sources()
    assert set(protocol['models'])==set(MODEL_PATHS)
    assert sha(RESERVED/'states.npz')==STATE_SHA
    assert all(sha(ROOT/p)==h for p,h in protocol['protected_inputs'].items())
    if (OUT/'manifest.json').exists():raise FileExistsError('Completed final evaluation is immutable; inspect saved results.')
    if (OUT/'status.json').exists() and not resume:raise FileExistsError('Final evaluation started; explicit --resume required for identical-protocol recovery.')
    # Consume the reservation before reading its states or generating labels.
    previous=json.loads((OUT/'reservation_before_use.json').read_text())
    consumed={k:v for k,v in previous.items() if k not in ['status','used_for_current_diagnostics']}
    consumed.update(status='consumed by fixed final evaluation; no longer an untouched test set',
        used_for_development_before_final_evaluation=False,used_for_final_evaluation=True,
        final_evaluation='evaluation/final_evaluation_20261028',protocol_sha256=sha(OUT/'protocol.json'))
    dump(RESERVED/'manifest.json',consumed)
    (RESERVED/'README.md').write_text('# Final evaluation states — reservation consumed\n\n'
        'These 24,000 states (seed 991731) are now used for the fixed [final evaluation](../final_evaluation_20261028/README.md). '
        'They are no longer an untouched test set and must not be reused as new final evidence after further tuning. '
        'The original states.npz bytes are unchanged; the original reservation metadata is archived with the final protocol. '
        'No development diagnosis used them before this evaluation.\n',encoding='utf-8')
    dump(OUT/'status.json',dict(status='generating fixed final reference',training=False,execution=execution))
    with np.load(RESERVED/'states.npz') as f:states=f['states'].copy()
    assert states.shape==(24000,3) and np.isfinite(states).all()
    assert np.all(abs(states[:,:2])<=.6) and np.all(abs(states[:,2])<=np.pi)
    times=np.array(protocol['times']);_,ck=load_checkpoint(ROOT/protocol['models']['3A']['path']);c=ck['config']
    reference_path=OUT/'reference_values.npz'
    if reference_path.exists():
        saved=json.loads((OUT/'reference_check.json').read_text());assert sha(reference_path)==saved['queried_reference_sha256']
        with np.load(reference_path) as f:reference=f['reference'].copy();np.testing.assert_array_equal(times,f['times'])
    else:
        print('Building fixed 129x129x96 reference at 21 horizons for final states; no training.',flush=True)
        clock=time.perf_counter();ref=solve(c,129,96,times);seconds=time.perf_counter()-clock
        shared=[]
        with np.load(ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz') as old:
            np.testing.assert_array_equal(ref['x'],old['x']);np.testing.assert_array_equal(ref['theta'],old['theta'])
            for t,v in zip(old['times'],old['values']):shared.append(dict(time=float(t),max_abs=float(abs(ref['values'][float(t)]-v).max())))
        assert max(r['max_abs'] for r in shared)<.001
        with np.load(ROOT/'lookahead_21points_20261027/heldout_values.npz') as dev:
            np.testing.assert_array_equal(times,dev['times'])
            check=np.stack([interpolate(ref,float(t),dev['states'][:64]) for t in times])
            dense_error=float(abs(check-dev['reference'][:,:64]).max());assert dense_error<1e-10
        reference=np.stack([interpolate(ref,float(t),states) for t in times]);assert np.isfinite(reference).all()
        atomic_npz(reference_path,times=times,reference=reference)
        dump(OUT/'reference_check.json',dict(grid=[129,129,96],build_seconds=seconds,steps=ref['steps'],
            dtmax=ref['dtmax'],dx=ref['dx'],dtheta=ref['dtheta'],original_fine_shared=shared,
            original_dense_prefix_max_abs=dense_error,queried_reference_sha256=sha(reference_path),
            no_temporal_interpolation=True,reference_is_approximate=True))
        del ref
        print(f'Reference completed in {seconds:.2f} seconds; old dense reference consistency passed.',flush=True)
    predictions={};rows=[];checks=[];worst=[]
    for name,entry in protocol['models'].items():
        print('Final fixed-model evaluation: '+name,flush=True)
        dump(OUT/'status.json',dict(status='evaluating fixed models',model=name,training=False,execution=execution))
        model,ck=load_checkpoint(ROOT/entry['path']);model.eval();c=ck['config']
        original={k:v.clone() for k,v in model.state_dict().items()};pp=[];max_obstacle=-1e30;terminal_error=None
        for j,t in enumerate(times):
            q=np.column_stack([np.full(len(states),t),states]);pred=predict(model,q);assert np.isfinite(pred).all();pp.append(pred)
            e=pred-reference[j];analytic=np.hypot(states[:,0],states[:,1])-c['radius']
            max_obstacle=max(max_obstacle,float(np.max(pred-analytic)))
            if t==0:terminal_error=float(abs(pred-analytic).max())
            cls=classification(pred,reference[j]);truth=reference[j]<=0;unsafe=pred<=0
            rows.append(dict(model=name,time=float(t),**error(pred,reference[j]),**cls,
                false_safe_count=int(np.sum(~unsafe&truth)),false_unsafe_count=int(np.sum(unsafe&~truth)),
                relative_l2=float(np.linalg.norm(e)/np.linalg.norm(reference[j])),bias=float(e.mean()),
                p95_abs=float(np.quantile(abs(e),.95)),p99_abs=float(np.quantile(abs(e),.99)),
                own_worst_240_mae=float(np.sort(abs(e))[-240:].mean()),ahead_mae=float(abs(e[states[:,0]>0]).mean()),
                behind_mae=float(abs(e[states[:,0]<=0]).mean()),below_minus_radius_fraction=float(np.mean(pred<-.2501)),
                interior_vi_mae=physics_loss(model,q,c),
                time_increase_from_previous_fraction=0. if j==0 else float(np.mean(pred>pp[j-1]+1e-4))))
        predictions[name]=np.stack(pp)
        ids=np.argsort(abs(predictions[name][-1]-reference[-1]))[-240:][::-1]
        for rank,i in enumerate(ids,1):worst.append(dict(model=name,rank=rank,state_index=int(i),x=float(states[i,0]),
            y=float(states[i,1]),heading=float(states[i,2]),reference=float(reference[-1,i]),
            prediction=float(predictions[name][-1,i]),absolute_error=float(abs(predictions[name][-1,i]-reference[-1,i]))))
        assert terminal_error<2e-7 and max_obstacle<2e-7
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in original.items())
        assert all(p.grad is None for p in model.parameters())
        checks.append(dict(model=name,terminal_max_abs=terminal_error,maximum_obstacle_violation=max(0.,max_obstacle),
            weights_unchanged=True,no_parameter_gradients=True))
    write_csv(OUT/'metrics.csv',rows);dump(OUT/'metrics.json',rows)
    final=[r for r in rows if r['time']==.5];write_csv(OUT/'final_metrics.csv',final);dump(OUT/'final_metrics.json',final)
    write_csv(OUT/'worst_240_each_model.csv',worst);dump(OUT/'equation_checks.json',checks)
    atomic_npz(OUT/'model_predictions.npz',times=times,**predictions)
    intervals=paired_intervals(reference,predictions);dump(OUT/'paired_confidence_intervals.json',intervals)
    development=json.loads((ROOT/'experiments/experiment_3_e_capacity_budget/final_comparison.json').read_text())
    mapping={'3A':'3A_64_10000','Adam200':'Adam200_64_10200','Long22000':'long64_22000'}
    gaps=[]
    for r in final:
        dev=next(d for d in development if d['model']==mapping[r['model']])
        gaps.append(dict(model=r['model'],development_mae=dev['mae'],final_mae=r['mae'],
            final_minus_development_mae=r['mae']-dev['mae'],development_iou=dev['iou'],final_iou=r['iou']))
    write_csv(OUT/'development_vs_final.csv',gaps)
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    for name in protocol['models']:
        rr=[r for r in rows if r['model']==name]
        axes[0,0].plot(times,[r['mae'] for r in rr],label=name)
        axes[0,1].plot(times,[r['iou'] for r in rr])
        axes[1,0].plot(times,[100*r['false_unsafe_fraction_of_reference_safe'] for r in rr])
        axes[1,1].plot(times,[r['p99_abs'] for r in rr])
    for ax in axes.flat:ax.set_xlabel('Look-ahead horizon [s]');ax.grid(alpha=.2)
    axes[0,0].set(title='Value accuracy on final states',ylabel='MAE [m]');axes[0,0].legend()
    axes[0,1].set(title='Unsafe-set agreement',ylabel='IoU')
    axes[1,0].set(title='Conservative classifications',ylabel='False-unsafe / reference-safe [%]')
    axes[1,1].set(title='Tail error',ylabel='99th-percentile absolute error [m]')
    fig.suptitle('Fixed final evaluation: 24,000 previously unused states; no tuning')
    fig.savefig(OUT/'final_comparison.png',dpi=170);plt.close(fig)
    assert all(sha(ROOT/p)==h for p,h in protocol['protected_inputs'].items())
    assert protocol['source_sha256']==sources()
    long=[r for r in rows if r['model']=='Long22000' and r['time']>0]
    summary=dict(final_mae_improvement_vs_Adam200_percent=intervals['Adam200_versus_Long22000']['observed_relative_mae_improvement_percent'],
        horizons_long_better_than_Adam200=sum(r['mae']<next(x['mae'] for x in rows if x['model']=='Adam200' and x['time']==r['time']) for r in long),
        nonzero_horizons=20,bootstrap=intervals)
    dump(OUT/'summary.json',summary)
    dump(OUT/'manifest.json',dict(status='completed',training=False,optimizer_created=False,parameter_updates=0,
        fixed_protocol_sha256=sha(OUT/'protocol.json'),models=protocol['models'],reserved_states_sha256=STATE_SHA,
        reservation_consumed=True,no_further_tuning=True,source_sha256=sources(),protected_inputs_unchanged=True,
        output_sha256={n:sha(OUT/n) for n in ['metrics.csv','final_metrics.json','reference_values.npz','model_predictions.npz','paired_confidence_intervals.json']},
        comparisons=len(rows),execution=execution,elapsed_seconds_this_execution=time.perf_counter()-start,completed_utc=datetime.now(timezone.utc).isoformat()))
    consumed['status']='consumed; fixed final evaluation completed';consumed['final_manifest_sha256']=sha(OUT/'manifest.json')
    dump(RESERVED/'manifest.json',consumed)
    dump(OUT/'status.json',dict(status='completed',training=False,reservation_consumed=True))
    print(json.dumps(dict(final_metrics=final,summary=summary),indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--evaluate',action='store_true')
    ap.add_argument('--resume',action='store_true');ap.add_argument('--execution',default='managed process with existing project interpreter')
    args=ap.parse_args()
    if args.prepare:prepare()
    elif args.evaluate:evaluate(args.resume,args.execution)
    else:ap.error('Use --prepare to freeze protocol, then --evaluate to consume the reserved evaluation.')

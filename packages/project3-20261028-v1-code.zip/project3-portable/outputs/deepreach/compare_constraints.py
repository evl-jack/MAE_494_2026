"""Evaluate completed Experiment 3A against saved baseline/A. Never trains."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from deepreach import load_checkpoint, value_grad, hamiltonian, target
from diagnostics import ROOT, dump, sha, write_csv, relative_l2
from validate import predict, error, classification, evaluate


def run(run_dir, folder):
    run_dir=Path(run_dir); folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
    checkpoint=run_dir/'checkpoint.pt'
    model,ck=load_checkpoint(checkpoint); model.eval(); c=ck['config']
    if c['formulation']!='terminal_obstacle_square' or ck['step']!=10000:
        raise ValueError('Expected the completed 10,000-step constrained candidate')
    torch.set_num_threads(2)
    sweep=ROOT/'lookahead_21points_20261027/heldout_values.npz'
    reference=ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz'
    a_checkpoint=ROOT/'runs/experiment_2_a_loss_20261022/checkpoint.pt'
    protected=[checkpoint,sweep,reference,a_checkpoint]
    implementation=json.loads((folder/'implementation_checks.json').read_text())
    for relative,expected in implementation['protected_inputs'].items():
        path=ROOT/relative
        if sha(path)!=expected: raise ValueError('Original checkpoint/reference changed: '+relative)
        if path not in protected: protected.append(path)
    before={str(p):sha(p) for p in protected}
    with np.load(sweep) as data:
        states=data['states'].copy(); times=data['times'].copy(); truth=data['reference'].copy()
        values={s:data[s].copy() for s in ['baseline','a']}
    _,a_ck=load_checkpoint(a_checkpoint)
    for key in ['radius','speed','turn','domain','horizon','comparison_half_width']:
        if c[key]!=a_ck['config'][key]: raise ValueError('Game/config mismatch: '+key)
    values['constraints']=np.stack([predict(model,np.column_stack([np.full(len(states),t),states])) for t in times])
    np.savez_compressed(folder/'candidate_values.npz',times=times,predictions=values['constraints'])
    labels={'baseline':'Experiment 1','a':'Experiment 2A','constraints':'Experiment 3A: constraints'}
    outside=np.linalg.norm(states[:,:2],axis=1)>c['radius']
    ell=np.linalg.norm(states[:,:2],axis=1)-c['radius']
    rows=[]
    for slug,label in labels.items():
        for k,t in enumerate(times):
            pred,ref=values[slug][k],truth[k]
            outside_metrics=classification(pred[outside],ref[outside])
            rows.append(dict(model=label,slug=slug,tau=float(t),relative_l2=relative_l2(pred,ref),
                 bias=float(np.mean(pred-ref)),**error(pred,ref),**classification(pred,ref),
                 outside_collision_false_safe=outside_metrics['false_safe_fraction_of_reference_unsafe'],
                 outside_collision_false_unsafe=outside_metrics['false_unsafe_fraction_of_reference_safe'],
                 outside_collision_reference_unsafe_count=outside_metrics['reference_unsafe_count'],
                 inside_collision_false_safe_count=int(np.sum(pred[~outside]>0)),
                 obstacle_violation_fraction=float(np.mean(pred>ell+1e-4)),
                 below_physical_minimum_fraction=float(np.mean(pred < -c['radius']-1e-4)),
                 minimum_predicted_value=float(pred.min()),
                 increasing_value_fraction=float(np.mean(pred>values[slug][max(0,k-1)]+1e-5)) if k else 0.))
    write_csv(folder/'comparison.csv',rows); dump(folder/'comparison.json',rows)
    candidate=values['constraints']
    # Analytic geometry, independent of the interpolated grid target.
    analytic_terminal=ell
    np.testing.assert_allclose(candidate[0],analytic_terminal,atol=2e-7,rtol=0)
    assert np.all(candidate[:,~outside]<=0)
    assert np.max(candidate-ell[None,:])<2e-7
    equations=[]; equation_arrays={}
    for k,t in enumerate(times):
        q=torch.tensor(np.column_stack([np.full(6000,t),states[:6000]]),dtype=torch.float32)
        v,dv=value_grad(model,q)
        fr=dv[:,0]-hamiltonian(q[:,1:],dv[:,1:],c)
        ob=v-target(q[:,1:],c)
        re=torch.maximum(fr,ob)
        gap=[]
        for heading in [-np.pi,np.pi]:
            qs=q.clone(); qs[:,3]=heading
            with torch.no_grad(): gap.append(model(qs).numpy())
        equations.append(dict(tau=float(t),vi_mae=float(re.detach().abs().mean()),
            vi_p95=float(torch.quantile(re.detach().abs(),.95)),
            positive_time_derivative_fraction=float((dv[:,0]>1e-4).float().mean()),
            heading_seam_mae=float(np.mean(abs(gap[1]-gap[0])))))
        equation_arrays[f'derivatives_{k}']=dv.detach().numpy()
        equation_arrays[f'vi_{k}']=re.detach().numpy()
    write_csv(folder/'equation_checks.csv',equations); dump(folder/'equation_checks.json',equations)
    np.savez_compressed(folder/'equation_samples.npz',states=states[:6000],times=times,**equation_arrays)
    print('21-point comparison complete; running original three-point validation',flush=True)
    original_metrics=evaluate(checkpoint,run_dir/'validation',reference_cache=reference,verbose=False)
    fig,axes=plt.subplots(2,3,figsize=(15,8),layout='constrained')
    fields=['relative_l2','mae','iou','false_safe_fraction_of_reference_unsafe',
            'false_unsafe_fraction_of_reference_safe','outside_collision_false_safe']
    scales=[100,1,1,100,100,100]
    titles=['Relative L2 [%]','Value MAE [m]','Unsafe-region IoU',
            'False-safe / reference-unsafe [%]','False-unsafe / reference-safe [%]',
            'Initially separated: false-safe / reference-unsafe [%]']
    for slug,label in labels.items():
        selected=[r for r in rows if r['slug']==slug]
        for ax,key,scale in zip(axes.flat,fields,scales):
            ax.plot(times,[np.nan if key=='outside_collision_false_safe' and r['outside_collision_reference_unsafe_count']==0
                          else r[key]*scale for r in selected],'o-',markersize=3,label=label)
    for ax,title in zip(axes.flat,titles):
        ax.set_title(title,fontsize=10); ax.set_xlabel('Look-ahead τ [s]'); ax.grid(alpha=.25)
    axes[0,0].legend(fontsize=8)
    fig.suptitle('Experiment 3A versus A: matched 10,000 physics steps; no terminal pretraining for 3A')
    fig.savefig(folder/'comparison.png',dpi=170); plt.close(fig)
    a_final=next(r for r in rows if r['slug']=='a' and r['tau']==.5)
    final=next(r for r in rows if r['slug']=='constraints' and r['tau']==.5)
    old_diagnostics=json.loads((ROOT/'failure_analysis_20261027/equation_checks.json').read_text())
    a_equation=next(r for r in old_diagnostics if r['slug']=='a' and r['tau']==.5 and r['region']=='interior')
    a_seams=json.loads((ROOT/'failure_analysis_20261027/heading_seam.json').read_text())
    a_seam=next(r for r in a_seams if r['slug']=='a' and r['tau']==.5)
    lines=['# Experiment 3A — Measured comparison with Experiment 2A','',
        'Training completed after explicit user authorization. The run was launched through VS Code Run and Debug '
        'in the Homework project, using the existing CPU interpreter and two threads. No reference labels entered training.','',
        f'Completed physics updates: {ck["step"]:,}. Candidate training time: {ck["elapsed_seconds"]:.2f} s. '
        f'A used 2,000 terminal + 10,000 physics updates and {a_ck["elapsed_seconds"]:.2f} s. '
        'The physics schedule/update budget matches; total updates, initialization and wall-clock cost differ. '
        'The comparison is single-seed validation, not an accuracy-matched timing benchmark or an untouched test.','',
        'The same 24,000 states and 21 direct reference snapshots are reused. '
        'No new numerical PDE solve was needed. The three-point legacy validation is also retained under the run folder.','',
        '| Metric at .5 s | Experiment 2A | Experiment 3A |','|---|---|---|']
    for title,key,scale in [('Relative L2 [%]','relative_l2',100),('Value MAE [m]','mae',1),
             ('Value RMSE [m]','rmse',1),('IoU','iou',1),
             ('False-safe / reference-unsafe [%]','false_safe_fraction_of_reference_unsafe',100),
             ('False-unsafe / reference-safe [%]','false_unsafe_fraction_of_reference_safe',100),
             ('Initially separated false-safe / reference-unsafe [%]','outside_collision_false_safe',100),
             ('Initially separated false-unsafe / reference-safe [%]','outside_collision_false_unsafe',100),
             ('Already-collided states predicted safe [count]','inside_collision_false_safe_count',1),
             ('Obstacle violation fraction [%]','obstacle_violation_fraction',100),
             ('Below physical minimum -R [%]','below_physical_minimum_fraction',100),
             ('Value rises from .475 to .5 s [% of states]','increasing_value_fraction',100)]:
        lines.append(f'| {title} | {a_final[key]*scale:.5f} | {final[key]*scale:.5f} |')
    lines += [f'| Interior VI residual MAE (training convention) | {a_equation["vi_mae"]:.5f} | {equations[-1]["vi_mae"]:.5f} |',
              f'| Equivalent-heading value gap MAE [m] | {a_seam["value_gap_mae"]:.5f} | {equations[-1]["heading_seam_mae"]:.5f} |','',
              '![Comparison](comparison.png)','',
              'The exact terminal and obstacle conditions passed after training, and no initially collided validation '
              'state was labeled safe. This is guaranteed by the output construction and is not independent evidence '
              'of better predictions for initially separated states. False-unsafe rate, IoU and value error must also '
              'be considered. The square construction does not enforce the separate lower bound V>=-R; '
              'violations are reported above. Small nonzero terminal error versus the interpolated reference can remain even with an '
              'exact analytic terminal condition. The VI residual is a training-convention diagnostic, not an error bound. '
              'The initially-separated rate is omitted from the plot when its reference-unsafe denominator is zero; '
              'CSV counts are retained (the helper returns zero in that case). Small conditional denominators '
              'at early times can produce large rate swings.','',
              f'Final-horizon MAE changed by {100*(final["mae"]/a_final["mae"]-1):+.2f}% relative to A. '
              'No second seed, combined periodic encoding, revised time sampler, control rollout or 6D test was run.','',
              '## Files','',
              '- comparison.csv/json: all 63 model/time comparisons, denominators and conditional metrics.',
              '- candidate_values.npz: candidate predictions and times; state/reference inputs are identified by hash in manifest.json.',
              '- equation_checks.csv/json and equation_samples.npz: derivatives/residuals on the same 6,000 interior states.',
              '- manifest.json: model/input/source hashes and integrity checks.',
              '- The run folder retains checkpoint.pt, history.csv, config.json, environment.json, source snapshots and three-point validation.',
              '', '[Implementation and hypothesis](README.md)', '']
    (folder/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    after={str(p):sha(p) for p in protected}
    assert before==after
    dump(folder/'manifest.json',dict(status='completed',training_executed_by='VS Code Run and Debug',
         evaluation_does_not_train=True,protected_inputs=after,source_sha256={n:sha(ROOT/n) for n in
         ['compare_constraints.py','deepreach.py','validate.py']},checks=dict(inputs_unchanged=True,
         exact_terminal=True,obstacle=True,already_collided_nonpositive=True,
         legacy_checkpoints_and_reference_unchanged=True),completed_steps=ck['step'],
         training_seconds=ck['elapsed_seconds'],evaluation_states=24000,derivative_states=6000,
         evaluation_times=times.tolist(),three_point_validation=str(run_dir/'validation/metrics.json')))
    print('Completed: '+str(folder/'RESULTS.md'),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',default=str(ROOT/'runs/experiment_3_a_constraints'))
    parser.add_argument('--out',default=str(ROOT/'experiments/experiment_3_a'))
    args=parser.parse_args(); run(args.run,args.out)

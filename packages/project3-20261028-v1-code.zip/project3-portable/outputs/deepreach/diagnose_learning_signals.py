"""3A parameter-learning diagnostics. No optimizer, parameter updates or training.

Reference-error gradients are evaluation-only probes. Hypothetical Adam
directions are computed from copied saved moments and are never applied.
"""
import csv
import copy
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import spearmanr
import torch
from deepreach import load_checkpoint, residual, sample, target, hamiltonian
from diagnostics import ROOT, dump, sha, write_csv


def flat(items):
    return np.concatenate([x.detach().cpu().numpy().ravel().astype(np.float64) for x in items])


def cosine(a,b):
    denominator=np.linalg.norm(a)*np.linalg.norm(b)
    return float(np.dot(a,b)/denominator) if denominator>1e-30 else None


def group_gradient(model,c,queries,reference=None):
    params=tuple(model.parameters());n=len(queries)
    gp=np.zeros(sum(p.numel() for p in params));ge=np.zeros_like(gp) if reference is not None else None
    ge_mae=np.zeros_like(gp) if reference is not None else None
    values=[];residuals=[];branches=[];free=[];raw=[]
    for start in range(0,n,1024):
        q=torch.tensor(queries[start:start+1024],dtype=torch.float32)
        r,v,dv=residual(model,q,c,True)
        loss=r.abs().sum()/n
        gp+=flat(torch.autograd.grad(loss,params,retain_graph=reference is not None))
        if reference is not None:
            y=torch.tensor(reference[start:start+1024],dtype=torch.float32)
            ge+=flat(torch.autograd.grad(.5*(v-y).square().sum()/n,params,retain_graph=True))
            ge_mae+=flat(torch.autograd.grad((v-y).abs().sum()/n,params))
        # Identify the active max branch using the exact implementation result.
        obstacle=v.detach()-target(q[:,1:],c)
        from deepreach import hamiltonian
        f=dv.detach()[:,0]-hamiltonian(q[:,1:],dv.detach()[:,1:],c)
        with torch.no_grad():g=model.raw(q/model.scales)
        values.extend(v.detach().numpy());residuals.extend(r.detach().numpy())
        branches.extend((f>=obstacle).numpy());free.extend(f.numpy());raw.extend(g.numpy())
    arrays=dict(values=np.array(values),residual=np.array(residuals),free=np.array(free),
                pde_branch=np.array(branches),raw_g=np.array(raw))
    result=dict(count=n,physics_loss=float(np.mean(abs(arrays['residual']))),
                physics_gradient_norm=float(np.linalg.norm(gp)),
                pde_branch_fraction=float(arrays['pde_branch'].mean()))
    if reference is not None:
        result.update(reference_half_mse=float(np.mean((arrays['values']-reference)**2)/2),
            reference_gradient_norm=float(np.linalg.norm(ge)),physics_reference_cosine=cosine(gp,ge),
            reference_mae_gradient_norm=float(np.linalg.norm(ge_mae)),physics_reference_mae_cosine=cosine(gp,ge_mae))
    return result,gp,ge,ge_mae,arrays


def adam_direction(gradient,m,v,step,lr,betas,eps):
    b1,b2=betas
    next_m=b1*m+(1-b1)*gradient
    next_v=b2*v+(1-b2)*gradient**2
    return -lr*(next_m/(1-b1**(step+1)))/(np.sqrt(next_v/(1-b2**(step+1)))+eps)


def parameter_direction_check(model,c,queries,reference):
    """Finite differences via functional overrides; no model mutation/update."""
    md=copy.deepcopy(model).double();parameters=dict(md.named_parameters())
    generator=torch.Generator().manual_seed(991734)
    direction={k:torch.randn(p.shape,generator=generator,dtype=torch.float64) for k,p in parameters.items()}
    norm=sum(v.square().sum() for v in direction.values()).sqrt()
    direction={k:v/norm for k,v in direction.items()}
    def losses(overrides):
        q=torch.tensor(queries,dtype=torch.float64,requires_grad=True)
        value=torch.func.functional_call(md,overrides,(q,))
        dv=torch.autograd.grad(value.sum(),q,create_graph=True)[0]
        r=torch.maximum(dv[:,0]-hamiltonian(q[:,1:],dv[:,1:],c),value-target(q[:,1:],c))
        y=torch.tensor(reference,dtype=torch.float64)
        return r.abs().mean(),.5*(value-y).square().mean(),(value-y).abs().mean()
    result={}
    for j,label in enumerate(['physics','reference_half_mse','reference_mae']):
        loss=losses(parameters)[j]
        gradients=torch.autograd.grad(loss,tuple(parameters.values()))
        analytic=float(sum((g*direction[k]).sum() for (k,_),g in zip(parameters.items(),gradients)))
        eps=1e-7
        plus={k:p+eps*direction[k] for k,p in parameters.items()}
        minus={k:p-eps*direction[k] for k,p in parameters.items()}
        numerical=float((losses(plus)[j]-losses(minus)[j]).detach()/(2*eps))
        np.testing.assert_allclose(analytic,numerical,rtol=1e-4,atol=1e-6)
        result[label]=dict(autodiff=analytic,finite_difference=numerical,absolute_error=abs(analytic-numerical))
    return result


def reserve_states(c):
    folder=ROOT/'evaluation/reserved_final_states';folder.mkdir(parents=True,exist_ok=True)
    path=folder/'states.npz'
    if not path.exists():
        rng=np.random.default_rng(991731)
        states=rng.uniform([-.6,-.6,-np.pi],[.6,.6,np.pi],(24000,3))
        with path.open('xb') as stream:np.savez_compressed(stream,states=states)
        dump(folder/'manifest.json',dict(status='reserved; no predictions or reference labels generated',
            seed=991731,states=24000,state_order=['x','y','psi'],bounds=[[-.6,.6],[-.6,.6],[-np.pi,np.pi]],
            horizon=c['horizon'],sha256=sha(path),used_for_current_diagnostics=False))
        (folder/'README.md').write_text('# Reserved final evaluation states\n\n'
            '24,000 fresh interior Air3D states, seed 991731. No model predictions or reference labels '
            'were generated when reserving these inputs. They are not used in the 3A learning-signal '
            'diagnostics. Keep them outside development comparisons until a method and evaluation '
            'protocol have been selected; report that eventual evaluation separately. These inputs '
            'do not by themselves provide a safety certificate.\n',encoding='utf-8')
    return dict(path=str(path.relative_to(ROOT)),sha256=sha(path),used=False)


def run():
    folder=ROOT/'experiments/experiment_3_a/learning_signals';folder.mkdir(parents=True,exist_ok=True)
    checkpoint=ROOT/'runs/experiment_3_a_constraints/checkpoint.pt'
    sweep=ROOT/'lookahead_21points_20261027/heldout_values.npz'
    cohort=ROOT/'experiments/experiment_3_a/outliers/worst_240_states.csv'
    fine=ROOT/'runs/air3d_cpu_20261022/validation/reference_fine.npz'
    protected=[checkpoint,sweep,cohort,fine]+list((ROOT/'runs').glob('*/checkpoint.pt'))
    before={str(p.relative_to(ROOT)):sha(p) for p in protected}
    torch.set_num_threads(2);model,ck=load_checkpoint(checkpoint);model.eval();c=ck['config']
    weights={k:v.clone() for k,v in model.state_dict().items()}
    reserved=reserve_states(c)
    with np.load(sweep) as f:states=f['states'].copy();reference=f['reference'][-1].copy()
    queries=np.column_stack([np.full(len(states),.5),states])
    with cohort.open() as stream:top=np.array([int(r['state_index']) for r in csv.DictReader(stream)])
    parameter_check=parameter_direction_check(model,c,queries[top[:8]],reference[top[:8]])
    is_top=np.zeros(len(states),dtype=bool);is_top[top]=True
    groups={'all_final':np.arange(len(states)),'outliers_240':top,'remaining':np.flatnonzero(~is_top),
            'ahead':np.flatnonzero(states[:,0]>0),'behind':np.flatnonzero(states[:,0]<=0)}
    stats=[];physics={};oracle={};oracle_mae={};all_arrays=None;layer_rows=[]
    named=list(model.named_parameters());offsets=np.cumsum([0]+[p.numel() for _,p in named])
    for name,ids in groups.items():
        print('Parameter gradients: '+name,flush=True)
        result,gp,ge,gmae,arrays=group_gradient(model,c,queries[ids],reference[ids])
        stats.append(dict(group=name,**result));physics[name]=gp;oracle[name]=ge
        oracle_mae[name]=gmae
        if name=='all_final':all_arrays=arrays
        for j,(layer,_) in enumerate(named):
            sl=slice(offsets[j],offsets[j+1])
            layer_rows.append(dict(group=name,parameter=layer,physics_norm=float(np.linalg.norm(gp[sl])),
                 reference_norm=float(np.linalg.norm(ge[sl])),cosine=cosine(gp[sl],ge[sl])))
    np.testing.assert_allclose(physics['all_final'],.01*physics['outliers_240']+.99*physics['remaining'],rtol=2e-4,atol=1e-6)
    write_csv(folder/'group_gradients.csv',stats);dump(folder/'group_gradients.json',stats)
    write_csv(folder/'layer_gradients.csv',layer_rows)
    ae=abs(all_arrays['values']-reference);ar=abs(all_arrays['residual']);g=all_arrays['raw_g']
    sensitivity=2*c['constraint_scale']*abs(g) # tau/T=1 for this final-time probe.
    point_masks={'all':np.ones(len(states),dtype=bool),'outliers_240':is_top,'remaining':~is_top,
                 'large_error_low_residual':(ae>=.05)&(ar<=.01)}
    point_summary={}
    for name,mask in point_masks.items():
        point_summary[name]=dict(count=int(mask.sum()),mae=float(ae[mask].mean()) if mask.any() else None,
            raw_abs_median=float(np.median(abs(g[mask]))) if mask.any() else None,
            raw_abs_below_0_05_fraction=float(np.mean(abs(g[mask])<.05)) if mask.any() else None,
            output_sensitivity_median=float(np.median(sensitivity[mask])) if mask.any() else None,
            pde_branch_fraction=float(np.mean(all_arrays['pde_branch'][mask])) if mask.any() else None)
    point_summary['spearman_absolute_error_residual']=float(spearmanr(ae,ar).statistic)
    dump(folder/'point_summary.json',point_summary)
    np.savez_compressed(folder/'final_point_fields.npz',states=states,reference=reference,**all_arrays,
                        output_sensitivity=sensitivity)
    # Per-state norms distinguish small output sensitivity from a small PDE
    # parameter gradient. The PDE also depends on input derivatives of g.
    rng=np.random.default_rng(991732)
    controls=rng.choice(groups['remaining'],240,replace=False)
    point_rows=[];params=tuple(model.parameters())
    for tag,ids in [('outlier',top),('random_remaining_control',controls)]:
        print('Per-state learning signals: '+tag,flush=True)
        for i in ids:
            q=torch.tensor(queries[i:i+1],dtype=torch.float32)
            r,v,_=residual(model,q,c,True)
            gp=flat(torch.autograd.grad(r.abs().sum(),params,retain_graph=True))
            y=torch.tensor(reference[i:i+1],dtype=torch.float32)
            ge=flat(torch.autograd.grad(.5*(v-y).square().sum(),params,retain_graph=True))
            gv=flat(torch.autograd.grad(v.sum(),params))
            raw=model.raw(q/model.scales)
            gg=flat(torch.autograd.grad(raw.sum(),params))
            np.testing.assert_allclose(gv,-2*c['constraint_scale']*float(raw.detach())*gg,rtol=2e-4,atol=2e-5)
            point_rows.append(dict(group=tag,state_index=int(i),abs_error=float(ae[i]),abs_residual=float(ar[i]),
                raw_g=float(g[i]),output_sensitivity=float(sensitivity[i]),physics_gradient_norm=float(np.linalg.norm(gp)),
                value_gradient_norm=float(np.linalg.norm(gv)),raw_gradient_norm=float(np.linalg.norm(gg)),
                physics_reference_cosine=cosine(gp,ge)))
    write_csv(folder/'per_state_gradients.csv',point_rows)
    # Read frozen Adam moments; never create an optimizer or write parameters.
    pg=ck['optimizer']['param_groups'][0]
    assert len(ck['optimizer']['param_groups'])==1 and not pg['amsgrad'] and not pg['maximize'] and pg['weight_decay']==0
    moments=[ck['optimizer']['state'][pid] for pid in pg['params']]
    m=flat([x['exp_avg'] for x in moments]);second=flat([x['exp_avg_sq'] for x in moments])
    steps=[int(x['step']) for x in moments];assert len(set(steps))==1
    # Independent first-update scalar check, without an optimizer fixture.
    np.testing.assert_allclose(adam_direction(np.array([2.]),np.zeros(1),np.zeros(1),0,.001,(.9,.999),1e-8),
                               [-.001*2/(2+1e-8)],rtol=1e-12)
    batch_rows=[];batch_gradients=[];directions=[];terminal_gradients=[];nonterminal_gradients=[]
    torch.manual_seed(991733)
    for batch in range(8):
        print('Frozen-state Adam / diagnostic batch '+str(batch+1),flush=True)
        q=sample(c,2048,.5,256,'cpu').numpy()
        full,gp,_,_,_=group_gradient(model,c,q)
        term,gt,_,_,_=group_gradient(model,c,q[-256:])
        non,gn,_,_,_=group_gradient(model,c,q[:-256])
        np.testing.assert_allclose(gp,.125*gt+.875*gn,rtol=3e-4,atol=1e-6)
        direction=adam_direction(gp,m,second,steps[0],pg['lr'],pg['betas'],pg['eps'])
        row=dict(batch=batch,physics_loss=full['physics_loss'],physics_gradient_norm=float(np.linalg.norm(gp)),
            terminal_physics_loss=term['physics_loss'],nonterminal_physics_loss=non['physics_loss'],
            terminal_nonterminal_gradient_cosine=cosine(gt,gn),
            weighted_terminal_gradient_norm=float(np.linalg.norm(.125*gt)),
            weighted_nonterminal_gradient_norm=float(np.linalg.norm(.875*gn)),
            physics_outlier_gradient_cosine=cosine(gp,physics['outliers_240']),
            adam_training_loss_first_order=float(np.dot(gp,direction)))
        for name in ['all_final','outliers_240','remaining']:
            row['physics_reference_cosine_'+name]=cosine(gp,oracle[name])
            row['adam_descent_reference_cosine_'+name]=cosine(-direction,oracle[name])
            row['adam_reference_half_mse_first_order_'+name]=float(np.dot(oracle[name],direction))
            row['physics_reference_mae_cosine_'+name]=cosine(gp,oracle_mae[name])
            row['adam_descent_reference_mae_cosine_'+name]=cosine(-direction,oracle_mae[name])
            row['adam_reference_mae_first_order_'+name]=float(np.dot(oracle_mae[name],direction))
        batch_rows.append(row);batch_gradients.append(gp);directions.append(direction)
        terminal_gradients.append(gt);nonterminal_gradients.append(gn)
    write_csv(folder/'batch_directions.csv',batch_rows);dump(folder/'batch_directions.json',batch_rows)
    vectors={**{'physics_'+k:v for k,v in physics.items()},**{'reference_'+k:v for k,v in oracle.items()},
             **{'reference_mae_'+k:v for k,v in oracle_mae.items()},
             'batch_physics':np.stack(batch_gradients),'frozen_adam_directions':np.stack(directions),
             'batch_terminal_physics':np.stack(terminal_gradients),'batch_nonterminal_physics':np.stack(nonterminal_gradients)}
    np.savez_compressed(folder/'parameter_vectors.npz',**vectors)
    names=list(groups);matrix=np.array([[cosine(physics[a],physics[b]) for b in names] for a in names])
    batch_matrix=np.array([[cosine(a,b) for b in batch_gradients] for a in batch_gradients])
    off=batch_matrix[~np.eye(8,dtype=bool)]
    summary=dict(optimizer_steps=0,parameter_updates=0,reference_gradients_used_for_updates=False,
        parameter_directional_derivative_check=parameter_check,
        training_batches=8,training_batch_size=2048,terminal_points=256,
        physics_group_names=names,physics_gradient_cosines=matrix.tolist(),
        diagnostic_batch_pair_cosine_median=float(np.median(off)),diagnostic_batch_pair_cosine_min=float(off.min()),
        hypothetical_adam_reduces_reference_outlier_half_mse_batches=int(sum(r['adam_reference_half_mse_first_order_outliers_240']<0 for r in batch_rows)),
        hypothetical_adam_reduces_all_final_reference_half_mse_batches=int(sum(r['adam_reference_half_mse_first_order_all_final']<0 for r in batch_rows)),
        hypothetical_adam_reduces_reference_outlier_mae_batches=int(sum(r['adam_reference_mae_first_order_outliers_240']<0 for r in batch_rows)),
        hypothetical_adam_reduces_all_final_reference_mae_batches=int(sum(r['adam_reference_mae_first_order_all_final']<0 for r in batch_rows)),
        outlier_weighted_physics_norm=float(np.linalg.norm(.01*physics['outliers_240'])),
        remaining_weighted_physics_norm=float(np.linalg.norm(.99*physics['remaining'])),
        reserved_final_states=reserved,threshold_note='Low residual <=.01 in training convention; large value error >=.05 m. Descriptive thresholds, not bounds.')
    dump(folder/'summary.json',summary)
    fig,axes=plt.subplots(2,3,figsize=(16,8.5),layout='constrained')
    axes[0,0].scatter(np.maximum(ar,1e-8),np.maximum(ae,1e-8),s=2,alpha=.3,rasterized=True)
    axes[0,0].scatter(np.maximum(ar[top],1e-8),ae[top],s=7,color='crimson')
    axes[0,0].set(xscale='log',yscale='log',xlabel='Absolute VI residual [training convention]',ylabel='Absolute value error [m]',title='Residual versus reference error at .5 s')
    for tag,color in [('outlier','crimson'),('random_remaining_control','steelblue')]:
        rr=[r for r in point_rows if r['group']==tag]
        axes[0,1].hist([np.log10(max(r['output_sensitivity'],1e-12)) for r in rr],bins=25,alpha=.5,label=tag,color=color)
        axes[0,2].scatter([r['abs_error'] for r in rr],[max(r['physics_gradient_norm'],1e-12) for r in rr],s=7,alpha=.5,label=tag,color=color)
    axes[0,1].set(xlabel='log10 |∂V/∂g| at .5 s',ylabel='States',title='Square-output sensitivity');axes[0,1].legend(fontsize=7)
    axes[0,2].set(yscale='log',xlabel='Absolute value error [m]',ylabel='Per-state physics parameter-gradient norm',title='Do outliers have a learning signal?')
    im=axes[1,0].imshow(matrix,vmin=-1,vmax=1,cmap='coolwarm');axes[1,0].set_xticks(range(len(names)),names,rotation=35,ha='right');axes[1,0].set_yticks(range(len(names)),names)
    axes[1,0].set_title('Mean physics-gradient alignment');fig.colorbar(im,ax=axes[1,0],shrink=.75)
    im=axes[1,1].imshow(batch_matrix,vmin=-1,vmax=1,cmap='coolwarm');axes[1,1].set(title='Fresh diagnostic-batch gradient alignment',xlabel='Batch',ylabel='Batch');fig.colorbar(im,ax=axes[1,1],shrink=.75)
    for name in ['all_final','outliers_240','remaining']:
        axes[1,2].plot(range(1,9),[r['adam_descent_reference_cosine_'+name] for r in batch_rows],'o-',label=name)
    axes[1,2].axhline(0,color='gray',linestyle=':');axes[1,2].set(xlabel='Diagnostic batch',ylabel='cos(-Adam direction, reference-error gradient)',title='Frozen-state Adam: positive locally helps');axes[1,2].legend(fontsize=7)
    fig.suptitle('3A learning signals: no optimizer steps; reference gradients are evaluation-only')
    fig.savefig(folder/'learning_signals.png',dpi=170);plt.close(fig)
    assert all(torch.equal(v,model.state_dict()[k]) for k,v in weights.items())
    assert all(p.grad is None for p in model.parameters())
    after={str(p.relative_to(ROOT)):sha(p) for p in protected};assert before==after
    dump(folder/'manifest.json',dict(status='completed',training=False,optimizer_created=False,parameter_updates=0,
        protected_inputs=after,sources={n:sha(ROOT/n) for n in ['diagnose_learning_signals.py','deepreach.py']},
        checks=dict(parameter_direction_finite_difference=parameter_check,
                    group_gradient_decomposition=True,terminal_nonterminal_gradient_decomposition=True,
                    square_output_parameter_chain_rule=True,adam_scalar_formula=True,weights_unchanged=True,no_accumulated_parameter_gradients=True),
        reference_usage='Evaluation-only half-MSE gradients; no supervised updates.',reserved_final_states=reserved,
        derivative_scope='Parameter learning signals, not control-gradient reliability.',threads=2))
    print('Completed '+str(folder),flush=True)


if __name__=='__main__':run()

"""Portable entry points for the saved Air3D study. No training by default."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CODE = HERE / 'outputs/deepreach'
os.environ.setdefault('MPLCONFIGDIR', str(HERE / 'work/matplotlib'))
sys.path.insert(0, str(CODE))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify(require_all=False):
    manifest = json.loads((HERE/'package_manifest.json').read_text(encoding='utf-8'))
    checked = 0
    missing = []
    for item in manifest['files']:
        path = HERE/item['path']
        if not path.is_file():
            if item['package'] == 'code' or require_all:
                raise FileNotFoundError('Missing package file: '+item['path'])
            missing.append(item['path'])
            continue
        if digest(path) != item['sha256']:
            raise ValueError('Changed file: '+item['path'])
        checked += 1
    print(json.dumps({'status':'passed','files_checked':checked,'optional_result_files_not_installed':len(missing)}, indent=2))

def check():
    import torch
    from deepreach import Siren
    from validate import mechanical_checks
    torch.set_num_threads(2)
    torch.manual_seed(7)
    config = json.loads((CODE/'configs/cpu.json').read_text())
    model = Siren(config).eval()
    before = {k:v.clone() for k,v in model.state_dict().items()}
    result = mechanical_checks(model, config)
    assert all(torch.equal(v,model.state_dict()[k]) for k,v in before.items())
    result.update(status='passed',training=False,optimizer_steps=0,model_weights_unchanged=True,
                  torch_version=torch.__version__,threads=torch.get_num_threads())
    print(json.dumps(result,indent=2))

def predict(args):
    import torch
    torch.set_num_threads(2)
    paths = {'3d-long':CODE/'runs/experiment_3_e_long64/checkpoint_22000.pt',
             '4C':CODE/'experiments_6d/runs/4C/checkpoint.pt',
             '5U':CODE/'experiments_6d/experiment_5_sampling/runs/5U/checkpoint.pt',
             '5R':CODE/'experiments_6d/experiment_5_sampling/runs/5R/checkpoint.pt'}
    path = paths[args.model]
    if not path.exists():
        raise FileNotFoundError('Install the saved-results packages first; see README.md')
    manifest = json.loads((HERE/'package_manifest.json').read_text())
    expected = next(r['sha256'] for r in manifest['files'] if r['path']==path.relative_to(HERE).as_posix())
    if digest(path)!=expected:
        raise ValueError('Checkpoint hash differs from the packaged study')
    if not 0<=args.tau<=.5:
        raise ValueError('This package supports the trained 0 to 0.5 second horizon')
    x,y,heading=args.state
    if args.model=='3d-long':
        from deepreach import load_checkpoint
        model,_=load_checkpoint(path)
        q=torch.tensor([[args.tau,x,y,heading]],dtype=torch.float32)
    else:
        sys.path.insert(0,str(CODE/'experiments_6d'))
        from network import JointSiren
        ck=torch.load(path,map_location='cpu',weights_only=True)
        model=JointSiren(ck['config']); model.load_state_dict(ck['model'])
        q=torch.tensor([[args.tau,x,y,heading,0.,0.,0.]],dtype=torch.float32)
    model.eval()
    with torch.no_grad():
        value=float(model(q).reshape(-1)[0])
    print(json.dumps({'model':args.model,'tau_seconds':args.tau,'relative_state':args.state,
                      'predicted_margin_m':value,'training':False},indent=2))

def archived_checks(which):
    if which=='report':
        script=CODE/'final_report/verify_report.py'
        env=os.environ.copy()
    else:
        script=CODE/'experiments_6d/experiment_5_sampling'/('verify_training.py' if which=='training' else 'verify_evaluation.py')
        env=os.environ.copy()
        env['PYTHONPATH']=os.pathsep.join([str(CODE),str(CODE/'experiments_6d'),str(script.parent)])
    return subprocess.call([sys.executable,str(script)],cwd=HERE,env=env)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest='command',required=True)
    p=commands.add_parser('verify',help='Check installed file hashes; requires no scientific dependencies')
    p.add_argument('--all',action='store_true',help='Require every optional saved-results package')
    commands.add_parser('check',help='Small derivative/Hamiltonian fixture checks; zero optimizer steps')
    p=commands.add_parser('predict',help='Query one packaged trained checkpoint without training')
    p.add_argument('--model',choices=['3d-long','4C','5U','5R'],default='3d-long')
    p.add_argument('--tau',type=float,required=True)
    p.add_argument('--state',nargs=3,type=float,required=True,metavar=('X','Y','HEADING'))
    p=commands.add_parser('verify-results',help='Run archived checks on saved artifacts; needs all packages')
    p.add_argument('--part',choices=['report','training','evaluation','all'],default='all')
    p=commands.add_parser('train-smoke',help='Explicitly run the original 60-step setup configuration')
    p.add_argument('--train',action='store_true',help='Required to authorize optimizer updates')
    p.add_argument('--out',default='work/new_smoke_run')
    args=parser.parse_args()
    if args.command=='verify': verify(args.all)
    elif args.command=='check': check()
    elif args.command=='predict': predict(args)
    elif args.command=='verify-results':
        parts=['report','training','evaluation'] if args.part=='all' else [args.part]
        for part in parts:
            code=archived_checks(part)
            if code:return code
    elif args.command=='train-smoke':
        if not args.train:parser.error('No training started. Add --train only when you intend to update weights.')
        out=Path(args.out)
        if not out.is_absolute():out=HERE/out
        if out.exists() and any(out.iterdir()):raise FileExistsError('Choose a fresh, empty output directory')
        return subprocess.call([sys.executable,str(CODE/'deepreach.py'),'--train','--config',str(CODE/'configs/smoke.json'),'--out',str(out)],cwd=HERE)
    return 0

if __name__=='__main__':
    raise SystemExit(main())

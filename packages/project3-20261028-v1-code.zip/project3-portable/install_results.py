"""Install optional saved-result archives from local ZIPs or GitHub, checking SHA256."""
import argparse
import hashlib
import json
import shutil
from contextlib import nullcontext
import urllib.request
import zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--download',action='store_true',help='Download the three optional archives from the public repository')
    p.add_argument('--archives-dir',type=Path,default=HERE.parent)
    a=p.parse_args()
    items=json.loads((HERE/'downloads.json').read_text())['optional_archives']
    download_dir=HERE/'work/archive-downloads'
    if a.download:download_dir.mkdir(parents=True,exist_ok=True)
    with nullcontext(download_dir) as tmp:
        for item in items:
            path=a.archives_dir/item['name']
            if a.download:
                path=Path(tmp)/item['name']
                print('Downloading '+item['name'],flush=True)
                urllib.request.urlretrieve(item['url'],path)
            if not path.is_file():raise FileNotFoundError(str(path)+'; download all saved-result archives or use --download')
            if hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:raise ValueError('Archive hash mismatch: '+item['name'])
            with zipfile.ZipFile(path) as z:
                for info in z.infolist():
                    part=Path(info.filename)
                    if part.is_absolute() or '..' in part.parts or not part.parts or part.parts[0]!='project3-portable':
                        raise ValueError('Unexpected archive path')
                    dest=HERE.joinpath(*part.parts[1:])
                    if info.is_dir():dest.mkdir(parents=True,exist_ok=True);continue
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    with z.open(info) as src,dest.open('wb') as out:shutil.copyfileobj(src,out)
            print('Installed '+item['name'],flush=True)
    print('Run: python run.py verify --all')

if __name__=='__main__':main()
